#!/usr/bin/env Rscript

main <- function() {

args <- commandArgs(trailingOnly = TRUE)
`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x
value_after <- function(flag, default = NULL) {
  hit <- which(args == flag)
  if (!length(hit)) return(default)
  if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[hit[[1]] + 1L]]
}

positionals <- args[!grepl("^--", args)]
option_values <- unlist(lapply(c("--root", "--title"), function(flag) {
  hit <- which(args == flag)
  if (length(hit) && hit[[1]] < length(args)) hit[[1]] + 1L else integer()
}))
positionals <- args[setdiff(which(!grepl("^--", args)), option_values)]
if (length(positionals) != 1L) {
  stop("Usage: Rscript scripts/run_analysis.R <slug> [--title <display title>] [--root <path>]", call. = FALSE)
}

slug <- positionals[[1]]
if (!grepl("^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$", slug)) {
  stop("Analysis slug must use lowercase letters, numbers, and internal hyphens.", call. = FALSE)
}
root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
title <- value_after("--title", tools::toTitleCase(gsub("-", " ", slug)))

source(file.path(root, "R", "harness_utils.R"))
source(file.path(root, "R", "harness_io.R"))
source(file.path(root, "R", "analysis_store.R"))
analysis_lock <- introstat_acquire_analysis_lock(root)
on.exit(introstat_release_analysis_lock(analysis_lock), add = TRUE)
introstat_migrate_legacy_analyses(root, lock = analysis_lock)
ensure_analysis_display_ids(root)

directory <- file.path(root, "analysis", slug)
source_path <- file.path(directory, "analysis.R")
if (!file.exists(source_path)) stop("Missing analysis source: ", source_path, call. = FALSE)
manifest_path <- file.path(directory, "manifest.yaml")
now <- format(Sys.time(), tz = "UTC", usetz = TRUE)
created_at <- now
existing_manifest <- NULL
if (file.exists(manifest_path)) {
  existing_manifest <- read_manifest(manifest_path)
  existing_created <- existing_manifest$created_at %||% existing_manifest$updated_at
  if (!is.null(existing_created) && length(existing_created) && nzchar(as.character(existing_created))) {
    created_at <- as.character(existing_created)
  }
}

old <- setwd(root)
on.exit(setwd(old), add = TRUE)
env <- new.env(parent = globalenv())
source("R/analysis_header.R", local = env, echo = FALSE)
result <- source(source_path, local = env, echo = FALSE)
object <- result$value
artifact_type <- artifact_type_from_object(object)
validate_artifact(object, artifact_type)
if (!is.null(existing_manifest)) {
  existing_type <- as.character(existing_manifest$artifact_type %||% "")
  if (nzchar(existing_type) && !identical(existing_type, artifact_type)) {
    stop("A rerun must keep the existing artifact type.", call. = FALSE)
  }
}
display_id <- as.character(existing_manifest$display_id %||% next_analysis_display_id(root, artifact_type))
prefix <- introstat_analysis_type_prefix(artifact_type)
if (!grepl(paste0("^", prefix, "[1-9][0-9]*$"), toupper(display_id))) {
  stop("A saved analysis must use a ", prefix, " display ID.", call. = FALSE)
}
title <- if (!is.null(existing_manifest) && is.null(value_after("--title"))) {
  as.character(existing_manifest$title %||% title)
} else title
title <- sub("^[PT][1-9][0-9]*:[[:space:]]*", "", title, ignore.case = TRUE)

analysis_root <- file.path(root, "analysis")
stage <- tempfile(paste0(".", slug, "-stage-"), tmpdir = analysis_root)
backup <- tempfile(paste0(".", slug, "-backup-"), tmpdir = analysis_root)
dir.create(stage)
old_moved <- FALSE
committed <- FALSE
on.exit({
  if (!committed && old_moved && !dir.exists(directory) && dir.exists(backup)) {
    file.rename(backup, directory)
  }
  if (dir.exists(stage)) unlink(stage, recursive = TRUE)
}, add = TRUE)

staged_source <- file.path(stage, "analysis.R")
if (!file.copy(source_path, staged_source, overwrite = TRUE)) {
  stop("Could not stage the analysis source.", call. = FALSE)
}
object_path <- file.path(stage, "object.rds")
saveRDS(object, object_path)
preview_dir <- file.path(stage, "preview")
artifact <- render_artifact(object, artifact_type, preview_dir)
manifest_values <- introstat_build_analysis_manifest(
  slug = slug,
  title = title,
  artifact_type = artifact_type,
  display_id = display_id,
  source_path = staged_source,
  object_path = object_path,
  artifact_relative_path = file.path("preview", basename(artifact)),
  created_at = created_at,
  updated_at = now,
  existing = existing_manifest
)
write_manifest(file.path(stage, "manifest.yaml"), manifest_values)

if (dir.exists(directory)) {
  if (!file.rename(directory, backup)) stop("Could not stage the existing analysis.", call. = FALSE)
  old_moved <- TRUE
}
if (!file.rename(stage, directory)) stop("Could not commit the rendered analysis.", call. = FALSE)
committed <- TRUE
if (dir.exists(backup)) unlink(backup, recursive = TRUE)

artifact <- file.path(directory, "preview", basename(artifact))

visible_title <- artifact_visible_title(manifest_values)
cat("Rendered analysis:", visible_title, "\n")
cat(if (identical(artifact_type, "plot")) "Plot ID:" else "Table ID:", display_id, "\n")

# Keep the review page synchronized with every successful analysis run.
source(file.path(root, "scripts", "render_analysis.R"), local = new.env(parent = globalenv()))
chat_preview <- if (identical(artifact_type, "plot")) {
  artifact
} else {
  file.path(dirname(artifact), "artifact-chat.png")
}
cat("Chat preview:", normalizePath(chat_preview, mustWork = TRUE), "\n")
if (!identical(artifact_type, "plot")) {
  chat_table <- file.path(dirname(artifact), "artifact-chat.md")
}
cat(
  "Analysis page:",
  normalizePath(file.path(root, "generated", "analysis.html"), mustWork = TRUE),
  "\n"
)
if (!identical(artifact_type, "plot")) {
  # Keep the generated Markdown as the final output block so chat can reproduce
  # the validated display cells without copying internal framing text.
  cat("\n")
  cat(readLines(chat_table, warn = FALSE), sep = "\n")
  cat("\n")
}
invisible(list(
  artifact_id = if (is.null(display_id)) slug else display_id,
  artifact_type = artifact_type,
  operation = "rerun"
))
}

main()
