#!/usr/bin/env Rscript

# Report command dispatcher.  Commands expose visible output IDs and section
# titles; report metadata stays private to the report container.
args <- commandArgs(trailingOnly = TRUE)
value_after <- function(flag, default = NULL) {
  hit <- which(args == flag)
  if (!length(hit)) return(default)
  if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[hit[[1]] + 1L]]
}
known_commands <- c("propose", "show", "omit", "include", "move", "rename-section", "move-section", "build", "update", "link", "delete-snapshot", "delete-report")
option_flags <- c("--root", "--report", "--title", "--section", "--before", "--after", "--snapshot")
value_positions <- integer()
for (flag in option_flags) {
  hit <- which(args == flag)
  value_positions <- c(value_positions, hit[hit < length(args)] + 1L)
}
positionals <- args[seq_along(args) %in% which(!grepl("^--", args) & !(seq_along(args) %in% value_positions))]
command_hit <- which(positionals %in% known_commands)
if (!length(command_hit)) stop("Choose a report command: propose, show, omit, include, move, rename-section, move-section, build, update, link, delete-snapshot, or delete-report.", call. = FALSE)
command <- positionals[[command_hit[[1]]]]
command_args <- if (command_hit[[1]] < length(positionals)) positionals[(command_hit[[1]] + 1L):length(positionals)] else character()
root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
source(file.path(root, "R", "harness_io.R"))
source(file.path(root, "R", "analysis_store.R"))
source(file.path(root, "R", "report_store.R"))
source(file.path(root, "R", "report_runtime.R"))

main <- function() {
  report_id <- value_after("--report", "report-1")
  title <- value_after("--title")
  section <- value_after("--section")
  before <- value_after("--before")
  after <- value_after("--after")
  snapshot <- value_after("--snapshot", if (length(command_args)) command_args[[1]] else NULL)
  if (identical(command, "propose")) return(introstat_report_propose(root, report_id, title))
  if (identical(command, "show")) return(introstat_report_show(root, report_id))
  if (identical(command, "omit")) return(introstat_report_omit(root, report_id, command_args[[1]]))
  if (identical(command, "include")) return(introstat_report_include(root, report_id, command_args[[1]]))
  if (identical(command, "move")) {
    if (!is.null(before) || !is.null(after)) {
      direction <- if (!is.null(before)) "before" else "after"
      return(introstat_report_move_relative(root, report_id, command_args[[1]], before %||% after, direction))
    }
    if (is.null(section)) stop("move requires --section, --before, or --after.", call. = FALSE)
    return(introstat_report_move(root, report_id, command_args[[1]], section))
  }
  if (identical(command, "rename-section")) {
    new_title <- title %||% command_args[[2]]
    if (is.null(new_title)) stop("rename-section requires a section and new title.", call. = FALSE)
    return(introstat_report_rename_section(root, report_id, command_args[[1]], new_title))
  }
  if (identical(command, "move-section")) {
    direction <- if (!is.null(before)) "before" else if (!is.null(after)) "after" else stop("move-section requires --before or --after.", call. = FALSE)
    return(introstat_report_move_section(root, report_id, command_args[[1]], before %||% after, direction))
  }
  if (identical(command, "build")) return(introstat_build_report(root, report_id, "build", "--approve" %in% args))
  if (identical(command, "update")) return(introstat_build_report(root, report_id, "update", "--approve" %in% args))
  if (identical(command, "link")) return(introstat_report_link(root, report_id))
  if (identical(command, "delete-snapshot")) return(introstat_delete_report_snapshot(root, report_id, snapshot, confirm = "--confirm" %in% args))
  if (identical(command, "delete-report")) return(introstat_delete_report(root, report_id, confirm = "--confirm" %in% args))
  stop("Unknown report command: ", command, call. = FALSE)
}

main()
