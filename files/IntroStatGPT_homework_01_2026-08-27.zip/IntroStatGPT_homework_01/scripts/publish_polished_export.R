#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
value_after <- function(flag, default = NULL) {
  hit <- which(args == flag)
  if (!length(hit)) return(default)
  if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[hit[[1]] + 1L]]
}

value_flags <- c("--analysis", "--candidate", "--root")
value_indices <- unlist(lapply(value_flags, function(flag) {
  hit <- which(args == flag)
  if (length(hit) && hit[[1]] < length(args)) hit[[1]] + 1L else integer()
}))
positionals <- args[setdiff(which(!grepl("^--", args)), value_indices)]
query <- value_after("--analysis", if (length(positionals)) positionals[[1]] else NULL)
candidate_arg <- value_after("--candidate")
if (is.null(query) || !nzchar(trimws(query)) || is.null(candidate_arg) ||
    !nzchar(trimws(candidate_arg)) || length(positionals) > 1L) {
  stop(
    paste(
      "Usage: Rscript scripts/publish_polished_export.R",
      "--analysis <visible-title> --candidate <path>",
      "[--with-table-helpers] [--overwrite] [--root <path>]"
    ),
    call. = FALSE
  )
}

root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
candidate_path <- normalizePath(candidate_arg, mustWork = TRUE)
source(file.path(root, "R", "harness_io.R"), local = TRUE)
source(file.path(root, "R", "analysis_store.R"), local = TRUE)
`%||%` <- function(x, y) if (is.null(x)) y else x
analysis_lock <- introstat_acquire_analysis_lock(root)
on.exit(introstat_release_analysis_lock(analysis_lock), add = TRUE)
introstat_migrate_legacy_analyses(root, lock = analysis_lock)
with_helpers <- "--with-table-helpers" %in% args
overwrite <- "--overwrite" %in% args

record <- introstat_resolve_saved_analysis(root, query)
object_path <- record$object_path
reference <- readRDS(object_path)
expected_type <- record$artifact_type

validator <- new.env(parent = globalenv())
sys.source(file.path(root, "R", "harness_utils.R"), envir = validator)
validator$validate_artifact(reference, expected_type)

helper_asset <- file.path(
  root, ".agents", "skills", "export-r-script", "assets",
  "reproduction_table_helpers.R"
)
helper_marker <- "# INTROSTAT EXPORT: TABLE HELPERS"
candidate_lines <- readLines(candidate_path, warn = FALSE)
marker_hits <- which(trimws(candidate_lines) == helper_marker)
if (with_helpers) {
  if (!file.exists(helper_asset)) stop("Missing export-only table helper asset.", call. = FALSE)
  if (length(marker_hits) != 1L) {
    stop("A table-helper candidate must contain exactly one helper marker.", call. = FALSE)
  }
} else if (length(marker_hits)) {
  stop("The candidate requests table helpers; add --with-table-helpers.", call. = FALSE)
}

validation_lines <- candidate_lines
if (with_helpers) {
  validation_lines[[marker_hits]] <- paste0(
    "source(", encodeString(normalizePath(helper_asset, mustWork = TRUE), quote = '"'), ")"
  )
}
validation_file <- tempfile("polished-export-validation-", fileext = ".R")
writeLines(validation_lines, validation_file, useBytes = TRUE)
on.exit(if (file.exists(validation_file)) unlink(validation_file), add = TRUE)

old <- setwd(root)
on.exit(setwd(old), add = TRUE)
candidate_env <- new.env(parent = globalenv())
candidate <- tryCatch(
  source(validation_file, local = candidate_env, echo = FALSE, chdir = FALSE)$value,
  error = function(error) {
    stop("Candidate script failed: ", conditionMessage(error), call. = FALSE)
  }
)
candidate_type <- tryCatch(
  validator$artifact_type_from_object(candidate),
  error = function(error) stop("Candidate did not return a supported artifact: ", conditionMessage(error), call. = FALSE)
)
if (!identical(candidate_type, expected_type)) {
  stop("Candidate returned ", candidate_type, "; expected ", expected_type, ".", call. = FALSE)
}
validator$validate_artifact(candidate, expected_type)
comparison <- if (identical(expected_type, "plot")) {
  validator$introstat_require("ggplot2")
  candidate_build <- ggplot2::ggplot_build(candidate)
  reference_build <- ggplot2::ggplot_build(reference)
  plot_parts <- list(
    data = list(candidate_build$data, reference_build$data),
    scales = list(candidate_build$plot$scales, reference_build$plot$scales),
    guides = list(candidate_build$plot$guides, reference_build$plot$guides),
    mapping = list(candidate_build$plot$mapping, reference_build$plot$mapping),
    theme = list(candidate_build$plot$theme, reference_build$plot$theme),
    labels = list(candidate_build$plot$labels, reference_build$plot$labels),
    coordinates = list(candidate_build$plot$coordinates, reference_build$plot$coordinates),
    facets = list(candidate_build$plot$facet, reference_build$plot$facet),
    panels = list(candidate_build$layout$panel_params, reference_build$layout$panel_params)
  )
  differences <- unlist(lapply(names(plot_parts), function(name) {
    result <- all.equal(
      plot_parts[[name]][[1]], plot_parts[[name]][[2]],
      check.environment = FALSE
    )
    if (isTRUE(result)) character() else paste0(name, ": ", as.character(result))
  }), use.names = FALSE)
  if (!length(differences)) TRUE else differences
} else {
  all.equal(candidate, reference, check.environment = FALSE)
}
if (!isTRUE(comparison)) {
  details <- paste(utils::head(as.character(comparison), 3L), collapse = "; ")
  stop("Candidate does not reproduce the saved artifact: ", details, call. = FALSE)
}

exports_root <- file.path(root, "exports")
dir.create(exports_root, recursive = TRUE, showWarnings = FALSE)
origin <- "current saved"

install_file <- function(lines, target) {
  if (file.exists(target) && !overwrite) {
    stop("Polished export already exists; use --overwrite to replace it: ", target, call. = FALSE)
  }
  stage <- tempfile(paste0(".", basename(target), "-"), tmpdir = dirname(target))
  writeLines(lines, stage, useBytes = TRUE)
  if (file.exists(target)) {
    backup <- tempfile(paste0(".", basename(target), "-backup-"), tmpdir = dirname(target))
    if (!file.rename(target, backup)) stop("Could not stage the existing export.", call. = FALSE)
    installed <- file.rename(stage, target)
    if (!installed) file.rename(backup, target)
    if (installed) unlink(backup)
  } else {
    installed <- file.rename(stage, target)
  }
  if (!installed) stop("Could not install the polished export.", call. = FALSE)
  target
}

if (!with_helpers) {
  output <- file.path(exports_root, paste0(record$slug, "_reproduce_polished.R"))
  install_file(candidate_lines, output)
  cat("Published polished export:", normalizePath(output, mustWork = TRUE), "\n")
  cat("Source version:", origin, "analysis\n")
  quit(status = 0L)
}

bundle_name <- paste0(record$slug, "_reproduce_polished")
target_directory <- file.path(exports_root, bundle_name)
target_zip <- file.path(exports_root, paste0(bundle_name, ".zip"))
if ((dir.exists(target_directory) || file.exists(target_zip)) && !overwrite) {
  stop("Polished export bundle already exists; use --overwrite to replace it: ", target_zip, call. = FALSE)
}

published_lines <- candidate_lines
helper_relative <- file.path("exports", bundle_name, "R", "reproduction_table_helpers.R")
published_lines[[marker_hits]] <- paste0(
  "source(", encodeString(gsub("\\\\", "/", helper_relative), quote = '"'), ")"
)

stage_root <- tempfile(paste0(".", bundle_name, "-"), tmpdir = exports_root)
stage_archive <- file.path(stage_root, "archive")
stage_bundle <- file.path(stage_archive, "exports", bundle_name)
dir.create(file.path(stage_bundle, "R"), recursive = TRUE)
writeLines(published_lines, file.path(stage_bundle, "reproduce.R"), useBytes = TRUE)
if (!file.copy(helper_asset, file.path(stage_bundle, "R", "reproduction_table_helpers.R"), overwrite = TRUE)) {
  stop("Could not stage the table helper asset.", call. = FALSE)
}
stage_zip <- file.path(stage_root, paste0(bundle_name, ".zip"))
withCallingHandlers({
  zip_old <- setwd(stage_archive)
  on.exit(setwd(zip_old), add = TRUE)
  utils::zip(stage_zip, files = file.path("exports", bundle_name), flags = "-rq")
}, warning = function(warning) invokeRestart("muffleWarning"))
if (!file.exists(stage_zip)) stop("Could not create the polished export bundle.", call. = FALSE)

backup_directory <- NULL
backup_zip <- NULL
if (dir.exists(target_directory)) {
  backup_directory <- tempfile(paste0(".", bundle_name, "-backup-"), tmpdir = exports_root)
  if (!file.rename(target_directory, backup_directory)) stop("Could not stage the existing bundle directory.", call. = FALSE)
}
if (file.exists(target_zip)) {
  backup_zip <- tempfile(paste0(".", bundle_name, "-backup-"), tmpdir = exports_root)
  if (!file.rename(target_zip, backup_zip)) {
    if (!is.null(backup_directory)) file.rename(backup_directory, target_directory)
    stop("Could not stage the existing bundle archive.", call. = FALSE)
  }
}

directory_installed <- file.rename(stage_bundle, target_directory)
zip_installed <- directory_installed && file.rename(stage_zip, target_zip)
if (!zip_installed) {
  if (dir.exists(target_directory)) unlink(target_directory, recursive = TRUE)
  if (file.exists(target_zip)) unlink(target_zip)
  if (!is.null(backup_directory)) file.rename(backup_directory, target_directory)
  if (!is.null(backup_zip)) file.rename(backup_zip, target_zip)
  stop("Could not install the polished export bundle.", call. = FALSE)
}
if (!is.null(backup_directory)) unlink(backup_directory, recursive = TRUE)
if (!is.null(backup_zip)) unlink(backup_zip)
unlink(stage_root, recursive = TRUE)

cat("Published polished export bundle:", normalizePath(target_zip, mustWork = TRUE), "\n")
cat("Source version:", origin, "analysis\n")
