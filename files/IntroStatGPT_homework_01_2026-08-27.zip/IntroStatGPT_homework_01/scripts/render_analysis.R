#!/usr/bin/env Rscript

# Render the working analysis gallery. The gallery is a view of saved
# analyses; report membership and report freshness belong to report links.
main <- function() {
  source(file.path(getwd(), "R", "harness_io.R"), local = environment())
  root <- introstat_root()
  source(file.path(root, "R", "analysis_store.R"), local = environment())

  `%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x
  field <- function(record, names, default = NULL) {
    for (name in names) {
      value <- record[[name]]
      if (!is.null(value) && length(value)) return(value)
    }
    default
  }
  as_path <- function(value, fallback = NULL) {
    if (is.null(value) || !length(value) || is.na(value[[1]]) || !nzchar(as.character(value[[1]]))) return(fallback)
    value <- as.character(value[[1]])
    if (grepl("^/", value) || grepl("^[A-Za-z]:[/\\\\]", value)) value else file.path(root, value)
  }

  records <- introstat_discover_saved_analysis(root)
  if (is.null(records)) records <- list()
  if (!is.list(records)) stop("Saved-analysis discovery returned an invalid result.", call. = FALSE)

  record_manifest <- function(record) {
    value <- field(record, c("manifest", "metadata"))
    if (is.list(value)) return(value)
    path <- as_path(field(record, c("manifest_path", "manifest")))
    if (!is.null(path) && file.exists(path)) read_manifest(path) else list()
  }
  record_directory <- function(record, manifest) {
    path <- as_path(field(record, c("directory", "analysis_directory", "path")))
    if (!is.null(path) && dir.exists(path)) return(path)
    path <- as_path(field(record, c("manifest_path")))
    if (!is.null(path)) dirname(path) else file.path(root, "analysis", as.character(manifest$slug %||% ""))
  }
  artifact_path <- function(record, manifest, directory) {
    values <- field(record, c("artifacts", "artifact_paths", "rendered_artifacts"), manifest$artifacts)
    values <- as.character(unlist(values, use.names = FALSE))
    if (!length(values)) return(NULL)
    candidate <- values[[1]]
    if (grepl("^/", candidate) || grepl("^[A-Za-z]:[/\\\\]", candidate)) candidate else file.path(directory, candidate)
  }
  visible_title <- function(record, manifest) {
    value <- field(record, c("visible_title", "title"), manifest$title %||% manifest$slug %||% "Untitled analysis")
    as.character(value[[1]])
  }
  artifact_type <- function(record, manifest) {
    value <- field(record, c("type", "artifact_type"), manifest$artifact_type %||% manifest$type %||% "output")
    as.character(value[[1]])
  }

  relative_from_generated <- function(path) {
    if (is.null(path) || !file.exists(path)) return(NULL)
    normalized_root <- normalizePath(root, mustWork = TRUE)
    normalized <- normalizePath(path, mustWork = TRUE)
    relative <- substring(normalized, nchar(normalized_root) + 2L)
    gsub("\\\\", "/", file.path("..", relative))
  }
  cards <- lapply(records, function(record) {
    manifest <- record_manifest(record)
    directory <- record_directory(record, manifest)
    artifact <- artifact_path(record, manifest, directory)
    type <- artifact_type(record, manifest)
    title <- visible_title(record, manifest)
    from_page <- relative_from_generated(artifact)
    body <- if (identical(type, "plot")) {
      htmltools::tags$img(src = from_page, alt = paste("Analysis artifact:", title), title = title)
    } else if (!is.null(from_page)) {
      htmltools::tags$iframe(src = from_page, title = paste("Analysis table:", title), loading = "lazy")
    } else {
      htmltools::tags$p(class = "missing", "The saved output preview is unavailable.")
    }
    htmltools::tags$section(
      class = "card",
      htmltools::tags$div(
        class = "card-head",
        htmltools::tags$div(
          htmltools::tags$h2(htmltools::htmlEscape(title)),
          htmltools::tags$p(class = "kind", gsub("_", " ", type, fixed = TRUE))
        )
      ),
      body
    )
  })
  if (!length(cards)) cards <- list(htmltools::tags$p(class = "empty", "No saved analysis outputs yet."))

  css <- "
    :root{font-family:Inter,system-ui,sans-serif;color:#183044;background:#f3f6f8}
    *{box-sizing:border-box}body{max-width:960px;margin:0 auto;padding:36px 24px 72px}
    header{margin-bottom:28px}h1{font-size:2rem;margin:0 0 8px;color:#123047}header p{margin:0;color:#526979}.plot-help{margin-top:6px;font-size:.88rem}
    .card{background:white;border:1px solid #dce5ea;border-radius:12px;padding:20px;margin:18px 0;box-shadow:0 2px 10px #16384d0d}
    .card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:14px}.card h2{font-size:1.1rem;margin:0}
    .kind{text-transform:capitalize;font-size:.78rem;color:#6a7d89;margin:4px 0 0}
    img{display:block;max-width:100%;height:auto;margin:auto}iframe{width:100%;min-height:310px;border:0;background:#fff}
    .empty,.missing{background:#fff;border:1px solid #dce5ea;border-radius:10px;padding:18px;color:#526979}
  "
  page_version <- sprintf("%.6f-%d", as.numeric(Sys.time()), Sys.getpid())
  refresh_js <- sprintf(
    "(function () {
      const pageVersion = %s;
      function checkForUpdate() {
        if (document.hidden) return;
        const probe = document.createElement('script');
        probe.src = 'analysis-version.js?checked=' + Date.now();
        probe.onload = function () { probe.remove(); if (window.__analysisLatestVersion && window.__analysisLatestVersion !== pageVersion) window.location.reload(); };
        probe.onerror = function () { probe.remove(); };
        document.head.appendChild(probe);
      }
      window.setInterval(checkForUpdate, 1500);
      document.addEventListener('visibilitychange', checkForUpdate);
    })();",
    encodeString(page_version, quote = "\"")
  )
  page <- htmltools::tags$html(
    htmltools::tags$head(
      htmltools::tags$meta(charset = "utf-8"),
      htmltools::tags$meta(name = "viewport", content = "width=device-width,initial-scale=1"),
      htmltools::tags$title("Analysis output"),
      htmltools::tags$style(htmltools::HTML(css)),
      htmltools::tags$script(htmltools::HTML(refresh_js))
    ),
    htmltools::tags$body(
      htmltools::tags$header(
        htmltools::tags$h1("Analysis output"),
        htmltools::tags$p("Requested statistical output only — no source code or interpretation."),
        htmltools::tags$p(class = "plot-help", "Refer to an output by its P or T number when requesting changes.")
      ),
      cards
    )
  )
  generated_dir <- file.path(root, "generated")
  dir.create(generated_dir, showWarnings = FALSE)
  htmltools::save_html(page, file.path(generated_dir, "analysis.html"), background = "white")
  writeLines(
    sprintf("window.__analysisLatestVersion = %s;", encodeString(page_version, quote = "\"")),
    file.path(generated_dir, "analysis-version.js"),
    useBytes = TRUE
  )
  cat("Rendered generated/analysis.html\n")
  invisible(list(operation = "refresh_gallery", artifact_count = length(records)))
}

main()
