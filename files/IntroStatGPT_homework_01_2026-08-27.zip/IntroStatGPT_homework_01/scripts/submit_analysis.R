#!/usr/bin/env Rscript

main <- function() {

args <- commandArgs(trailingOnly = TRUE)
`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x
value_after <- function(flag, default = NULL) {
  hit <- which(args == flag)
  if (!length(hit)) return(default)
  if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[hit[[1]] + 1L]]
}

option_values <- unlist(lapply(c("--root", "--title", "--analysis"), function(flag) {
  hit <- which(args == flag)
  if (length(hit) && hit[[1]] < length(args)) hit[[1]] + 1L else integer()
}))
positionals <- args[setdiff(which(!grepl("^--", args)), option_values)]
analysis_ref <- value_after("--analysis")
if ((is.null(analysis_ref) && length(positionals) != 1L) ||
    (!is.null(analysis_ref) && length(positionals) != 0L)) {
  stop(
    "Usage: Rscript scripts/submit_analysis.R <slug> [--title <display title>] [--root <path>] OR Rscript scripts/submit_analysis.R --analysis <visible-id> [--title <display title>] [--root <path>]",
    call. = FALSE
  )
}

root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
body <- readLines(file("stdin"), warn = FALSE)
if (!length(body) || !any(nzchar(trimws(body)))) {
  stop("Submit a non-empty R expression through standard input.", call. = FALSE)
}

source(file.path(root, "R", "harness_utils.R"))
source(file.path(root, "R", "harness_io.R"))
source(file.path(root, "R", "analysis_store.R"))

analysis_root <- file.path(root, "analysis")
dir.create(analysis_root, showWarnings = FALSE)
analysis_lock <- introstat_acquire_analysis_lock(root)
on.exit(introstat_release_analysis_lock(analysis_lock), add = TRUE)
introstat_migrate_legacy_analyses(root, lock = analysis_lock)
ensure_analysis_display_ids(root)
if (!is.null(analysis_ref)) {
  referenced <- introstat_resolve_saved_analysis(root, analysis_ref)
  slug <- referenced$slug
  title <- value_after("--title", referenced$title)
  replace <- TRUE
} else {
  slug <- tolower(gsub("[^a-z0-9]+", "-", positionals[[1]]))
  slug <- gsub("^-+|-+$", "", slug)
  if (!nzchar(slug)) stop("Could not derive a safe analysis slug.", call. = FALSE)
  title <- value_after("--title", tools::toTitleCase(gsub("-", " ", slug)))
  replace <- "--replace" %in% args
}
directory <- file.path(analysis_root, slug)
if (dir.exists(directory) && !replace) {
  stop(
    "An analysis with this slug already exists. Use a new title and slug for a new computation. Use --replace only for a presentation revision of the same computation.",
    call. = FALSE
  )
}
now <- format(Sys.time(), tz = "UTC", usetz = TRUE)
created_at <- now
existing_manifest <- NULL
existing_manifest_path <- file.path(directory, "manifest.yaml")
if (file.exists(existing_manifest_path)) {
  existing_manifest <- read_manifest(existing_manifest_path)
  existing_created <- existing_manifest$created_at %||% existing_manifest$updated_at
  if (!is.null(existing_created) && length(existing_created) && nzchar(as.character(existing_created))) {
    created_at <- as.character(existing_created)
  }
}
stage <- tempfile(paste0(".", slug, "-stage-"), tmpdir = analysis_root)
backup <- tempfile(paste0(".", slug, "-backup-"), tmpdir = analysis_root)
dir.create(stage)

old_moved <- FALSE
committed <- FALSE
on.exit({
  if (!committed && old_moved && !dir.exists(directory) && dir.exists(backup)) {
    file.rename(backup, directory)
  }
  if (dir.exists(stage)) unlink(stage, recursive = TRUE)
}, add = TRUE)

source_path <- file.path(stage, "analysis.R")
writeLines(c('source("R/analysis_header.R")', "", body), source_path, useBytes = TRUE)

old <- setwd(root)
on.exit(setwd(old), add = TRUE)
env <- new.env(parent = globalenv())
result <- source(source_path, local = env, echo = FALSE)
object <- result$value
artifact_type <- artifact_type_from_object(object)
validate_artifact(object, artifact_type)
if (!is.null(existing_manifest) && replace) {
  existing_type <- as.character(existing_manifest$artifact_type %||% "")
  if (nzchar(existing_type) && !identical(existing_type, artifact_type)) {
    stop("A replacement must keep the existing artifact type.", call. = FALSE)
  }
}
display_id <- as.character(existing_manifest$display_id %||% next_analysis_display_id(root, artifact_type))
prefix <- introstat_analysis_type_prefix(artifact_type)
if (!grepl(paste0("^", prefix, "[1-9][0-9]*$"), toupper(display_id))) {
  stop("A saved analysis must use a ", prefix, " display ID.", call. = FALSE)
}
title <- sub("^[PT][1-9][0-9]*:[[:space:]]*", "", title, ignore.case = TRUE)

object_path <- file.path(stage, "object.rds")
saveRDS(object, object_path)
artifact <- render_artifact(object, artifact_type, file.path(stage, "preview"))
manifest_values <- introstat_build_analysis_manifest(
  slug = slug,
  title = title,
  artifact_type = artifact_type,
  display_id = display_id,
  source_path = source_path,
  object_path = object_path,
  artifact_relative_path = file.path("preview", basename(artifact)),
  created_at = created_at,
  updated_at = now,
  existing = existing_manifest
)
write_manifest(file.path(stage, "manifest.yaml"), manifest_values)

if (dir.exists(directory)) {
  if (!file.rename(directory, backup)) stop("Could not stage the existing analysis.", call. = FALSE)
  old_moved <- TRUE
}
if (!file.rename(stage, directory)) stop("Could not commit the submitted analysis.", call. = FALSE)
committed <- TRUE
if (dir.exists(backup)) unlink(backup, recursive = TRUE)

# Rendering happened in the staging directory; resolve the committed path before
# printing student-facing links.
artifact <- file.path(directory, "preview", basename(artifact))

source(file.path(root, "scripts", "render_analysis.R"), local = new.env(parent = globalenv()))
visible_title <- artifact_visible_title(manifest_values)
updated <- !is.null(existing_manifest)
cat(if (updated) "Updated analysis:" else "Created analysis:", visible_title, "\n")
cat(if (identical(artifact_type, "plot")) "Plot ID:" else "Table ID:", display_id, "\n")
chat_preview <- if (identical(artifact_type, "plot")) {
  artifact
} else {
  file.path(dirname(artifact), "artifact-chat.png")
}
cat(
  "Chat preview:",
  normalizePath(chat_preview, mustWork = TRUE),
  "\n"
)
if (!identical(artifact_type, "plot")) {
  chat_table <- file.path(dirname(artifact), "artifact-chat.md")
}
cat(
  "Analysis page:",
  normalizePath(file.path(root, "generated", "analysis.html"), mustWork = TRUE),
  "\n"
)
if (!identical(artifact_type, "plot")) {
  # Keep the generated Markdown as the final output block so chat can reproduce
  # the validated display cells without copying internal framing text.
  cat("\n")
  cat(readLines(chat_table, warn = FALSE), sep = "\n")
  cat("\n")
}
invisible(list(
  artifact_id = if (is.null(display_id)) slug else display_id,
  artifact_type = artifact_type,
  operation = if (updated) "replace" else "create"
))
}

main()
