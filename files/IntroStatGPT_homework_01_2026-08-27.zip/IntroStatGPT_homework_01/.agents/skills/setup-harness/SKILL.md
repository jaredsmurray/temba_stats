---
name: setup-harness
description: Check whether R and the assignment packages are ready, install only missing R packages with student approval, and validate the complete statistical-analysis harness. Use when a student asks to set up, prepare, initialize, repair, or check the assignment environment, or when analysis fails because an R package is missing.
---

# Set up the assignment

Keep setup conversational. Do not ask the student to type terminal commands or
copy an `install.packages()` expression.

1. Check whether `Rscript` is available. If it is not, tell the student that R
   itself must be installed before the harness can continue. Do not attempt an
   operating-system-wide R installation.
2. Run `Rscript scripts/check_setup.R`.
3. If it succeeds, report that the assignment is ready.
4. If it reports missing packages, do not first run the installer inside the
   ordinary sandbox. Run `Rscript scripts/setup_harness.R` as a
   permission-requiring action and provide a clear approval explanation: it
   will download the named packages from CRAN and write them to the student's
   personal R library. This should produce one approval request before R
   starts. Install only the packages listed in `required_packages.txt`.
5. Rerun `Rscript scripts/check_setup.R` and report either success or the exact
   remaining blocker.

Do not update already installed packages. Do not install suggested packages or
unrelated development tools. Never use administrator privileges. The installer
uses the student's ordinary R user library when necessary.

Do not rely on the assistant to infer the installer side effects from the R script. A
normal sandboxed launch can fail because the personal library is outside the
assignment workspace without ever showing an approval request. Request the
permission on the installer invocation itself. If permission is denied, stop
and say that setup was not changed; do not retry around the denial.

After success, keep the response short: “Setup is complete. The assignment data
and required R packages are ready.”
