# Draft a requested calculation

For one specifically requested numerical scalar, finish with:

```r
make_value_table("<descriptive statistic>", <computed value>)
```

For a requested p-value, select its threshold-based display explicitly:

```r
make_value_table("p-value", <computed p-value>, value_format = "p_value")
```

This displays values below 0.001 as `<0.001` and otherwise uses three decimal
places, matching the canonical regression-table rule. Do not infer p-value
formatting from the statistic's label.

Use a concise label that identifies the statistic, variable, and population or
group when needed. Include a known unit in that label and format the displayed
value in a familiar way when the request, assignment context, or a supplied
variable description establishes both the unit and stored scale. Do not infer a
unit from the value or column name alone.

Use reasonable display precision without delaying the calculation to ask about
optional formatting. A change to its label, unit display, or digits may revise
the same visible table only when the computed scalar and its population remain
unchanged.
