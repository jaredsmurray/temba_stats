# Draft plots

## Construct the requested display

Create every plot as a `ggplot2` object. Use ordinary `ggplot2` defaults for
unspecified implementation details. Do not add a smoother, model, reference
line, transformation, grouping, faceting variable, uncertainty interval, or
diagnostic unless the student requested it.

Use `ggplot2::labs()` with a concise descriptive title and plain-language axis
and legend labels. Titles identify the display rather than state an observed
finding. When a unit is established by the request, assignment context, or a
supplied variable description, include it in the corresponding label and use
familiar tick formatting. Examples include dollars, percentages, dates, and
hours per day. Do not infer a unit from the observed values or a suggestive
column name alone.

Match the formatter to the stored scale. Proportions may use percentage labels;
values already recorded in percentage points should receive a percent suffix
without another multiplication. For a display-only rescaling, such as showing
dollars in thousands, prefer a scale-label transformation that leaves the
stored data and statistical computation unchanged, and state the displayed unit
in the axis label.

## Use a consistent theme

Add the theme to the plot itself rather than changing session-wide theme state:

```r
ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(
    panel.grid.minor = ggplot2::element_blank(),
    plot.title.position = "plot"
  )
```

Keep major grid lines when they aid comparison. Use readable breaks and avoid
scientific notation when it obscures values in the displayed range.

## Match color to the variable

For one unmapped series, use the restrained blue `#0072B2`. For unordered
categories, use this Okabe–Ito qualitative palette in order, placing yellow
last because it has weak contrast for thin marks on white:

```r
c("#0072B2", "#E69F00", "#009E73", "#CC79A7",
  "#D55E00", "#56B4E9", "#000000", "#F0E442")
```

Use `ggplot2::scale_colour_viridis_c()` or
`ggplot2::scale_fill_viridis_c()` for continuous ordered magnitude. Use the
binned or discrete viridis variant only for genuinely ordered values; do not
use viridis for unordered categories because its lightness progression implies
order and gives categories unequal visual weight.

For values diverging around an established midpoint, use a balanced diverging
scale such as blue–white–vermillion. The midpoint must come from the requested
or inherent scale, such as zero for residuals; never invent a substantive
benchmark. When distinctions must remain clear without color, reinforce color
with shape or line type when that does not clutter the display.

## Preserve readable comparisons

- Keep zero as the baseline for bar lengths. Do not force zero onto scatterplot
  axes when it would compress the useful range.
- When zooming a display, prefer `ggplot2::coord_cartesian()` so scale limits do
  not remove observations before a statistical layer is computed.
- Address overplotting with smaller marks or transparency before adding jitter.
  Use jitter only when it suits the variable and does not obscure actual values.
- Preserve a meaningful categorical order. Do not reorder groups by the
  observed outcome merely for visual effect.
- Keep informative legends and remove only genuinely redundant ones. Repair
  long or overlapping labels without hiding categories or observations.
- Do not silently suppress missing-value handling merely to remove a warning.
- Do not introduce dual axes, 3D effects, decorative gradients, or redundant
  annotations.

Labels, tick formatting, colors, dimensions, and layout are presentation
choices. Use reasonable defaults without delaying an otherwise specified plot;
the student can revise them through the same visible plot ID.
