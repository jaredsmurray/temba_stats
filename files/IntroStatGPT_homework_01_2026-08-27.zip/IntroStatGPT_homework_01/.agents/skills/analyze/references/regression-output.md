# Draft regression output

Fit only the model formula and model family the student requested. The finished
expression must be `make_reg_table(lm(...))`, or `make_reg_table()` applied to a
named list of requested `lm` models for a comparison. Never submit a raw model
object as the finished artifact.

Give comparison models short descriptive names. Use `coef_map` when needed to
make an unwieldy term readable while preserving its meaning. Display categorical
terms as `VariableLevel`, and label interactions so both participating terms
remain visible. Do not relabel a term in a way that interprets its estimate or
substantive importance.

Use the canonical regression-table precision and goodness-of-fit defaults unless
the student requests another display. When a predictor or outcome unit is known
from the request, assignment context, or a supplied variable description, make
that unit clear in the model name or coefficient label when it prevents
ambiguity. Do not infer units from values or names alone, and do not rescale or
refit a model merely to improve its display without a student request.

Model names, term labels, digits, and table layout are presentation choices.
They may revise the same visible table only when the fitted models and underlying
values remain unchanged.
