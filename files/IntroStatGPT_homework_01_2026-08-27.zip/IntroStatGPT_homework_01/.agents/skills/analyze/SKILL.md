---
name: analyze
description: Create or revise a requested statistical plot, table, model output, diagnostic, or calculation without interpreting it. Use ordinary base R or established-library defaults within the named operation. Never choose, suggest, or add an analysis the student did not request; ask one focused question only when no usable output is named or an additional statistical object must be selected.
---

# Analyze data without interpretation

Identify the requested output and run it using ordinary defaults within the
named operation. Do not treat routine implementation or presentation settings
as missing statistical choices. A request for descriptive comparisons or
summary statistics is not a request for an inferential test.

Apply defaults only after the statistical operation is named. A library default
must never select the test, interval method, model, or diagnostic itself. For
example, “test whether the groups differ” does not authorize choosing the test.

If the request does not identify a usable output, or if an additional method,
test, model, diagnostic, variable role, estimand, or inferential procedure must
be selected, ask one focused question without listing candidates. If the
student says “pick one,” “you decide,” or equivalent, state briefly that you can
run their choice but cannot choose it. Create no artifact on either turn.

A bare request for “diagnostics” does not name a usable statistical output. Ask
one focused question about the check, display, or calculation the student
wants. Do not name a menu of statistical checks.

## Route the requested output

After the requested operation passes the boundary above, read only the reference
that matches the finished artifact:

- For a plot or graphical diagnostic, read [references/plots.md](references/plots.md).
- For a descriptive, inferential, or other non-regression table, read
  [references/tables.md](references/tables.md).
- For one or more regression models presented as a table, read
  [references/regression-output.md](references/regression-output.md).
- For one specifically requested scalar, read
  [references/calculations.md](references/calculations.md).

When a request combines artifact types, read each applicable reference. These
references provide presentation defaults; they never authorize another
statistical operation, transformation, diagnostic, or inferential procedure.

## Save or revise the artifact

For a requested plot, table, model output, or saved calculation, generate an R
expression whose final value is the requested artifact and submit it once:

```bash
Rscript scripts/submit_analysis.R <slug> --title "<display title>" <<'INTROSTAT_R'
<R expression>
INTROSTAT_R
```

Save a new artifact whenever the statistic, interval method, model, variables,
population, filter, transformation, or diagnostic changes. Reuse an existing
artifact only for presentation changes such as labels, units, numerical
formatting, color, dimensions, or layout, so an earlier computation remains
available for later report selection. A presentation revision must preserve the
artifact's computation and underlying values. Add `--replace` to the submission
command only for such a revision; an unmarked overwrite is rejected.

Reuse the visible artifact's existing slug for revisions. The script supplies
the assignment setup, saves reproducible source, validates the result, and
refreshes the review page. For a plot, embed the absolute `Chat preview` path as
a Markdown image and identify it using the submitted `Plot ID`, such as
`P4: Residuals versus fitted values`. When a request explicitly names a plot ID,
submit the revised expression using `Rscript scripts/submit_analysis.R
--analysis P4`; the script resolves and replaces the existing artifact.
Requested additions such as smoothers or reference lines revise that plot in
place. For a table, identify it using the submitted `Table ID`, such as
`T3: Score summary by group`, and reproduce the final generated Markdown block
exactly; retain the PNG as an optional fallback. A request that names a T
identifier revises that saved table through `--analysis T3`. Then use the
absolute page path in a clickable Markdown link. Follow the interpretation and
report-writing boundaries in `AGENTS.md`; do not add analyses or suggest next
steps the student did not request.
