---
name: compile-report
description: Create, review, update, link, or explicitly delete a persistent Word report built from saved statistical outputs. Use when a student asks about a report or its outline.
---

# Work with a report

Use `scripts/compile_report.R` for every report operation. Match saved outputs by
visible title or P/T number and match reports by visible report title. Keep
internal report identifiers and files out of chat.

For a new report, run `propose`, show the complete outline, and offer two choices:
describe changes or build. The student may include or omit outputs, move or
reorder outputs, and rename or reorder sections. After any structural change,
show the revised outline and wait for explicit approval. Then run `build` with
`--approve`.

If only an included saved output changed and the student explicitly asks to
update the report, run `update`. This creates the next immutable version inside
the same report; prior versions remain available. It does not require approval
of the unchanged outline.

For a link request, run `link`. This operation is read-only: return the latest
compiled version and never rebuild. If the command reports that an included
output changed, link the latest version anyway, say it predates that change,
and offer to update. New or omitted outputs do not produce a warning.

Run `delete-snapshot` or `delete-report` with `--confirm` only after the student
explicitly confirms the visible report version or report to delete. Reports and
their versions otherwise persist.

The Word document contains statistical output and blank writing space. Do not
add source code, interpretation, conclusions, or report prose.
