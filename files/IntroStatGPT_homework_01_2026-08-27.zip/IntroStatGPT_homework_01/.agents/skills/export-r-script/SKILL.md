---
name: export-r-script
description: Export a saved statistical figure or table as polished, runnable, student-facing R code. Use when a student asks to see, save, download, study, learn from, or reproduce the R code for a visible analysis output. Match outputs by visible title, write detailed purpose-first comments by default, and package required table-formatting helpers separately.
---

# Export polished R code

Identify the output by its visible title. If multiple titles match, show only
those titles and ask which output the student means. Export the current saved
analysis represented by that title.

Treat the saved analysis and object as
read-only references. Read the selected analysis plus only the setup needed to
understand it. Author a separate student-facing script in this order:

1. Load required packages with conventional `library()` calls.
2. Read and prepare only the required data.
3. Construct the requested plot or table with clean, idiomatic R.
4. Leave the completed artifact as the final expression.

For a CSV-backed analysis, show the complete workspace-relative loader rather
than assuming that the data already exists in the session. Prefer this readable
form unless the saved analysis requires additional import arguments:

```r
analysis_data <- read_csv(
  "data/analysis-data.csv",
  show_col_types = FALSE
)
```

Load `readr` conventionally. Preserve consequential import arguments such as
`na`, `col_types`, or `locale` when the saved analysis depends on them; do not
invent them. For other supplied file types, use the corresponding ordinary
loader with the exact workspace-relative path.

Reproduce every data-processing step that affects the saved artifact, including
filters, selected variables, recodes, transformations, factor levels, grouping,
and summaries. Keep these steps in analytical order with readable intermediate
names. Do not replace them with embedded computed values merely because the
final plot or table would look the same for the current data.

Use descriptive object names. Do not include a generic `artifact` wrapper,
harness headers, validation or rendering calls, backend identifiers, or
unrelated setup. Avoid blanket `package::function` qualification; retain it
only when it prevents ambiguity.

Write detailed comments by default. Explain the purpose of each analytical
block and consequential choices such as variables, filters, transformations,
model formulas, bins, labels, or display settings. Do not produce a detached
catalog of routine function arguments. Use concise comments only when the
student explicitly requests them.

After the final expression, include commented examples for explicitly printing
and saving the result. End with this guidance, wrapped as needed:

```r
# You can ask ChatGPT or Claude about any line or request a guided walkthrough.
# A regular chat outside the assignment workspace is usually the simplest place
# to discuss this script.
```

For canonical regression or summary tables, place this marker after package
loading:

```r
# INTROSTAT EXPORT: TABLE HELPERS
```

Stage the candidate in a temporary location, then validate and publish it:

```sh
Rscript scripts/publish_polished_export.R \
  --analysis "<visible title>" \
  --candidate "<temporary script>"
```

Add `--with-table-helpers` when the marker is present. Use `--overwrite` only after
an explicit request to replace an existing polished export. The publisher must
complete successfully before reporting an export.

Return a clickable link to the resulting `.R` file or `.zip` bundle and state
which saved analysis it represents. Do not paste the
script into chat unless explicitly requested. Do not interpret the statistical
output.
