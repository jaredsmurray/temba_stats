# Saved output and report versions

Saved analyses are your current working outputs. A report uses the versions you
select when it is built. It is not Codex’s judgment that an analysis is correct.

Identify outputs by their visible titles. The harness keeps each report version
with its rendered figures or tables, canonical R objects, assignment inputs,
runtime details, and reproduction instructions. Working output can continue to
change without changing an earlier report version.

When you explicitly update a report after changing an included output, the new
version stays in the same report. Earlier versions remain available until you
explicitly ask to delete them.

Figures use consistent, readable dimensions. Regression tables use the course
modelsummary-based format and avoid scientific notation. Tables and figures are
numbered separately in a report.
