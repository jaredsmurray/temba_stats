# Reports and exports

Ask Codex to make a report from your saved outputs. Codex suggests an outline
based on the assignment scaffold and your visible output titles. You may include
or omit outputs, rename or reorder sections, and move outputs between sections.
The first build and every structural outline change begin only after you approve
the outline.

Each build creates a new version inside the same named report. Earlier versions
remain available. The Word document contains selected statistical output and
blank space for your writing. It does not include R code or AI-written
interpretation.

If you change an included output and ask for an update, Codex creates a new
version without making you approve the entire outline again. If you only ask for
the report link, Codex gives you the latest existing version and warns you when
an included output has changed; it does not rebuild silently. New or omitted
outputs do not affect that report until you include them.

Reports and their versions stay in the assignment folder until you explicitly
ask Codex to delete them.

To obtain code, ask for the R script reproducing a visible output. Codex creates
a downloadable script with detailed comments explaining each analytical step
and consequential choice. Ask for concise comments if you prefer a shorter
version.

Plots and ordinary tables are delivered as an R script. A table that uses the
course formatting helpers is delivered as a ZIP containing the script and its
helper file. Run either form from the assignment folder so it can read the
assignment data. You can ask Codex about any line or attach the script to a new
task for a guided walkthrough.
