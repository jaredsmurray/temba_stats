# IntroStatGPT for TEMBA Statistics

This folder contains the IntroStatGPT workspace, Homework 1, and the course
datasets. Keep the folder and its contents together.

To begin:

1. Open this extracted folder as a Codex workspace.
2. Start a new task.
3. Send: “Set up this IntroStatGPT workspace and verify that it is ready. Do
   not begin an analysis yet.”

Setup is complete when Codex reports that the setup check passed. The Homework
1 assignment is also included as `ASSIGNMENT.pdf`.
