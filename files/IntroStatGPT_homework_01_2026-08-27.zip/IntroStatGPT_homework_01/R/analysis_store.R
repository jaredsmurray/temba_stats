# Public saved-analysis catalog entry point.  The implementation lives beside
# manifest I/O so submission and catalog validation use one schema contract.
if (!exists("introstat_read_saved_analysis_catalog", mode = "function")) {
  root <- tryCatch(introstat_root(), error = function(error) getwd())
  source(file.path(root, "R", "harness_io.R"))
}

introstat_read_saved_analysis_catalog <- function(root = getwd()) {
  root <- normalizePath(root, mustWork = TRUE)
  analysis_root <- file.path(root, "analysis")
  if (!dir.exists(analysis_root)) return(list())
  paths <- introstat_analysis_manifest_paths(root)
  if (!length(paths)) return(list())
  records <- lapply(paths, function(manifest_path) {
    manifest_path <- normalizePath(manifest_path, mustWork = TRUE)
    if (!introstat_path_contained(manifest_path, analysis_root)) stop("Saved analysis manifest escapes analysis/: ", manifest_path, call. = FALSE)
    directory <- dirname(manifest_path)
    manifest <- read_manifest(manifest_path)
    schema <- suppressWarnings(as.integer(introstat_analysis_scalar(manifest$schema_version, "schema_version")))
    if (is.na(schema) || !identical(schema, introstat_analysis_schema_version)) stop("Unsupported saved analysis manifest schema in ", manifest_path, call. = FALSE)
    key <- introstat_analysis_safe_slug(manifest$key, "key")
    slug <- introstat_analysis_safe_slug(manifest$slug, "slug")
    title <- introstat_analysis_scalar(manifest$title, "title")
    status <- introstat_analysis_scalar(manifest$status, "status")
    if (!identical(status, "analysis")) stop("Saved analysis status must be analysis in ", manifest_path, call. = FALSE)
    artifact_type <- introstat_analysis_scalar(manifest$artifact_type, "artifact_type")
    if (!artifact_type %in% introstat_analysis_artifact_types) stop("Unsupported artifact_type in ", manifest_path, call. = FALSE)
    source_rel <- introstat_manifest_relative_path(manifest$source, directory, "source")
    object_rel <- introstat_manifest_relative_path(manifest$object, directory, "object")
    source_path <- normalizePath(file.path(directory, source_rel), mustWork = TRUE)
    object_path <- normalizePath(file.path(directory, object_rel), mustWork = TRUE)
    if (!introstat_path_contained(source_path, directory) || !introstat_path_contained(object_path, directory)) stop("Saved analysis source and object must remain inside their analysis directory.", call. = FALSE)
    artifacts <- manifest$artifacts
    if (is.null(artifacts) || !length(artifacts)) stop("Saved analysis manifest must list rendered artifacts.", call. = FALSE)
    artifact_rel <- vapply(as.list(artifacts), function(value) introstat_manifest_relative_path(value, directory, "artifact"), character(1))
    artifact_paths <- vapply(artifact_rel, function(value) normalizePath(file.path(directory, value), mustWork = TRUE), character(1))
    if (any(!vapply(artifact_paths, introstat_path_contained, logical(1), parent = directory))) stop("Saved analysis artifact escapes its analysis directory.", call. = FALSE)
    digests <- introstat_manifest_digests(manifest)
    if (!identical(introstat_sha256_file(source_path), digests$analysis_r) || !identical(introstat_sha256_file(object_path), digests$object_rds)) stop("Saved analysis content digest mismatch in ", manifest_path, call. = FALSE)
    display_id <- introstat_analysis_manifest_id(manifest, artifact_type)
    if (!nzchar(display_id)) stop("Saved analysis is missing a display ID: ", manifest_path, call. = FALSE)
    created_at <- introstat_analysis_scalar(manifest$created_at, "created_at")
    updated_at <- introstat_analysis_scalar(manifest$updated_at, "updated_at")
    problem <- introstat_analysis_scalar(manifest$problem, "problem", required = FALSE)
    question <- introstat_analysis_scalar(manifest$question, "question", required = FALSE)
    section_hint <- introstat_analysis_scalar(manifest$section_hint %||% manifest$section_id %||% manifest$section, "section_hint", required = FALSE)
    order <- manifest$order %||% manifest$report_order
    if (!is.null(order) && (length(order) != 1L || is.na(suppressWarnings(as.numeric(order))))) stop("Saved analysis order must be one numeric scalar.", call. = FALSE)
    dimensions <- manifest$dimensions
    if (!is.null(dimensions)) {
      if (!is.list(dimensions)) stop("Saved analysis dimensions must be a mapping.", call. = FALSE)
      for (field in intersect(names(dimensions), c("width", "height"))) introstat_analysis_scalar(dimensions[[field]], paste0("dimensions.", field))
    }
    if (is.null(dimensions) && (!is.null(manifest$width) || !is.null(manifest$height))) dimensions <- list(width = manifest$width, height = manifest$height)
    list(
      key = key, slug = slug, display_id = display_id, title = title,
      visible_title = artifact_visible_title(list(title = title, display_id = display_id)),
      artifact_visible_title = artifact_visible_title(list(title = title, display_id = display_id)),
      status = status, artifact_type = artifact_type,
      source_path = source_path, object_path = object_path, manifest_path = manifest_path,
      source = source_path, object = object_path, manifest = manifest_path,
      analysis_directory = normalizePath(directory, mustWork = TRUE),
      paths = list(source = source_path, object = object_path, manifest = manifest_path),
      artifact_paths = artifact_paths, artifacts = artifact_paths,
      digests = digests, source_digest = digests$analysis_r, object_digest = digests$object_rds,
      created_at = created_at, updated_at = updated_at,
      problem = problem, question = question, section_hint = section_hint,
      explicit_section_hint = section_hint,
      tags = as.character(unlist(manifest$tags %||% character(), use.names = FALSE)),
      order = order, dimensions = dimensions, metadata = manifest
    )
  })
  keys <- vapply(records, `[[`, character(1), "key")
  ids <- vapply(records, `[[`, character(1), "display_id")
  if (anyDuplicated(keys)) stop("Saved analysis keys must be unique.", call. = FALSE)
  if (anyDuplicated(ids)) stop("Saved analysis display IDs must be unique.", call. = FALSE)
  records[order(vapply(records, function(record) paste(record$created_at, record$key, sep = "\u0001"), character(1)), method = "radix")]
}

introstat_resolve_saved_analysis <- function(root = getwd(), query) {
  query <- introstat_analysis_scalar(query, "analysis reference")
  records <- introstat_read_saved_analysis_catalog(root)
  normalized <- tolower(trimws(query))
  matches <- which(vapply(records, function(record) normalized %in% tolower(c(record$display_id, record$title, record$visible_title)), logical(1)))
  if (length(matches) != 1L) {
    available <- if (length(records)) paste(vapply(records, `[[`, character(1), "visible_title"), collapse = "; ") else "none"
    if (!length(matches)) stop("No saved analysis matches ", query, ". Available outputs: ", available, call. = FALSE)
    stop("More than one saved analysis matches ", query, ". Available outputs: ", available, call. = FALSE)
  }
  records[[matches[[1]]]]
}

introstat_read_analysis_catalog <- introstat_read_saved_analysis_catalog
introstat_discover_analysis_catalog <- introstat_read_saved_analysis_catalog
introstat_discover_saved_analysis <- introstat_read_saved_analysis_catalog
read_analysis_catalog <- introstat_read_saved_analysis_catalog
introstat_resolve_analysis <- introstat_resolve_saved_analysis

# Validate one saved output while retaining the same duplicate/path/digest
# checks applied when the complete catalog is discovered.
introstat_validate_saved_analysis <- function(manifest_path, root = NULL) {
  if (is.null(root)) root <- introstat_root(dirname(dirname(manifest_path)))
  root <- normalizePath(root, mustWork = TRUE)
  records <- introstat_read_saved_analysis_catalog(root)
  manifest_path <- normalizePath(manifest_path, mustWork = TRUE)
  matches <- which(vapply(records, function(record) identical(record$manifest_path, manifest_path), logical(1)))
  if (length(matches) != 1L) {
    stop("Saved analysis manifest was not found in the catalog: ", manifest_path, call. = FALSE)
  }
  records[[matches[[1]]]]
}
