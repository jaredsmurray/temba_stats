if (!exists("%||%", mode = "function")) {
  `%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x
}

introstat_root <- function(start = getwd()) {
  current <- normalizePath(start, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "AGENTS.md")) && dir.exists(file.path(current, "R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate the assignment root.", call. = FALSE)
    current <- parent
  }
}

write_manifest <- function(path, values) {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  yaml::write_yaml(values, path)
}

read_manifest <- function(path) {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  yaml::read_yaml(path)
}

introstat_analysis_schema_version <- 2L
introstat_analysis_artifact_types <- c("plot", "table", "regression_table", "summary_table")

introstat_sha256_file <- function(path) {
  path <- normalizePath(path, mustWork = TRUE)
  candidates <- list(
    list(command = Sys.which("sha256sum"), args = character()),
    list(command = Sys.which("shasum"), args = c("-a", "256")),
    list(command = Sys.which("certutil"), args = c("-hashfile"))
  )
  for (candidate in candidates) {
    if (!nzchar(candidate$command)) next
    is_certutil <- identical(tolower(sub("[.]exe$", "", basename(candidate$command))), "certutil")
    args <- if (is_certutil) {
      c(candidate$args, path, "SHA256")
    } else {
      c(candidate$args, path)
    }
    output <- suppressWarnings(system2(candidate$command, args, stdout = TRUE, stderr = TRUE))
    status <- attr(output, "status") %||% 0L
    if (!identical(as.integer(status), 0L)) next
    lines <- trimws(as.character(output))
    if (is_certutil) {
      hit <- grep("^[A-Fa-f0-9 ]{64,}$", lines, value = TRUE)
      if (length(hit)) return(tolower(gsub("[[:space:]]", "", hit[[1]])))
    } else if (length(lines)) {
      hit <- strsplit(lines[[1]], "[[:space:]]+")[[1]][[1]]
      if (grepl("^[A-Fa-f0-9]{64}$", hit)) return(tolower(hit))
    }
  }
  stop("No SHA-256 command is available (sha256sum, shasum, or certutil).", call. = FALSE)
}

introstat_analysis_type_prefix <- function(artifact_type) {
  if (identical(as.character(artifact_type), "plot")) return("P")
  if (as.character(artifact_type) %in% c("table", "regression_table", "summary_table")) return("T")
  stop("Unsupported analysis artifact type: ", artifact_type, call. = FALSE)
}

introstat_analysis_manifest_paths <- function(root) {
  store <- file.path(root, "analysis")
  if (!dir.exists(store)) return(character())
  list.files(
    store,
    pattern = "^manifest\\.ya?ml$",
    recursive = TRUE,
    full.names = TRUE,
    ignore.case = TRUE
  )
}

introstat_analysis_manifest_id <- function(manifest, artifact_type = manifest$artifact_type) {
  value <- toupper(trimws(as.character(manifest$display_id %||% "")))
  if (!nzchar(value)) return("")
  prefix <- introstat_analysis_type_prefix(artifact_type)
  expected <- paste0("^", prefix, "[1-9][0-9]*$")
  if (!grepl(expected, value)) {
    stop("Invalid ", prefix, " display ID: ", value, call. = FALSE)
  }
  value
}

introstat_analysis_sort_key <- function(record) {
  manifest <- record$manifest
  c(
    as.character(manifest$created_at %||% manifest$updated_at %||% ""),
    as.character(manifest$key %||% manifest$slug %||% basename(dirname(record$path))),
    normalizePath(record$path, mustWork = TRUE)
  )
}

introstat_backfill_analysis_display_ids <- function(root) {
  root <- normalizePath(root, mustWork = TRUE)
  paths <- introstat_analysis_manifest_paths(root)
  if (!length(paths)) return(invisible(NULL))
  records <- lapply(paths, function(path) list(path = path, manifest = read_manifest(path)))
  for (record in records) {
    type <- as.character(record$manifest$artifact_type %||% "")
    if (!type %in% introstat_analysis_artifact_types) {
      stop("Unsupported analysis artifact type in ", record$path, ": ", type, call. = FALSE)
    }
  }

  id_groups <- list(
    plot = "plot",
    table = c("table", "regression_table", "summary_table")
  )
  for (group in id_groups) {
    selected <- Filter(function(record) as.character(record$manifest$artifact_type) %in% group, records)
    if (!length(selected)) next
    ids <- vapply(selected, function(record) {
      toupper(trimws(as.character(record$manifest$display_id %||% "")))
    }, character(1))
    prefix <- if (identical(group[[1]], "plot")) "P" else "T"
    valid <- grepl(paste0("^", prefix, "[1-9][0-9]*$"), ids)
    invalid_nonempty <- !valid & nzchar(ids)
    if (any(invalid_nonempty)) {
      stop("Invalid ", prefix, " display ID in saved analysis: ", paste(ids[invalid_nonempty], collapse = ", "), call. = FALSE)
    }
    if (anyDuplicated(ids[valid])) stop(prefix, " display IDs must be unique.", call. = FALSE)
    used <- if (any(valid)) as.integer(sub(paste0("^", prefix), "", ids[valid])) else integer()
    missing <- which(!valid)
    if (!length(missing)) next
    missing_records <- selected[missing]
    keys <- vapply(missing_records, function(record) {
      paste(introstat_analysis_sort_key(record), collapse = "\u0001")
    }, character(1))
    missing_records <- missing_records[order(keys, method = "radix")]
    next_number <- if (length(used)) max(used) + 1L else 1L
    for (record in missing_records) {
      record$manifest$display_id <- paste0(prefix, next_number)
      write_manifest(record$path, record$manifest)
      used <- c(used, next_number)
      next_number <- next_number + 1L
    }
  }
  invisible(NULL)
}

ensure_analysis_display_ids <- function(root) {
  introstat_backfill_analysis_display_ids(root)
}

next_analysis_display_id <- function(root, artifact_type) {
  introstat_backfill_analysis_display_ids(root)
  prefix <- introstat_analysis_type_prefix(artifact_type)
  paths <- introstat_analysis_manifest_paths(root)
  ids <- if (length(paths)) {
    vapply(paths, function(path) toupper(trimws(as.character(read_manifest(path)$display_id %||% ""))), character(1))
  } else character()
  valid <- grepl(paste0("^", prefix, "[1-9][0-9]*$"), ids)
  used <- if (any(valid)) as.integer(sub(paste0("^", prefix), "", ids[valid])) else integer()
  number <- if (length(used)) max(used) + 1L else 1L
  paste0(prefix, number)
}

next_plot_display_id <- function(root) next_analysis_display_id(root, "plot")

introstat_analysis_process_alive <- function(pid) {
  pid <- suppressWarnings(as.integer(pid))
  if (is.na(pid) || pid <= 0L) return(FALSE)
  if (identical(tolower(as.character(Sys.info()[["sysname"]])), "windows")) {
    output <- suppressWarnings(system2("tasklist", c("/FI", paste0("PID eq ", pid), "/FO", "CSV", "/NH"), stdout = TRUE, stderr = TRUE))
    return(!length(grep("no tasks", output, ignore.case = TRUE, fixed = TRUE)))
  }
  status <- suppressWarnings(system2("kill", c("-0", as.character(pid)), stdout = FALSE, stderr = FALSE))
  identical(as.integer(status %||% 0L), 0L)
}

introstat_analysis_lock_owner <- function(lock) {
  owner <- file.path(lock, "owner.txt")
  if (!file.exists(owner)) return(list(pid = NA_integer_))
  lines <- readLines(owner, warn = FALSE)
  hit <- grep("^pid=", lines, value = TRUE)
  list(pid = if (length(hit)) suppressWarnings(as.integer(sub("^pid=", "", hit[[1]]))) else NA_integer_)
}

introstat_recover_analysis_transactions <- function(root) {
  analysis_root <- file.path(normalizePath(root, mustWork = TRUE), "analysis")
  if (!dir.exists(analysis_root)) return(invisible(NULL))
  entries <- list.dirs(analysis_root, recursive = FALSE, full.names = TRUE)
  names <- basename(entries)
  stage <- entries[grepl("^\\.[A-Za-z0-9][A-Za-z0-9._-]*-stage-[A-Za-z0-9._-]+$", names)]
  backup <- entries[grepl("^\\.[A-Za-z0-9][A-Za-z0-9._-]*-backup-[A-Za-z0-9._-]+$", names)]
  slugs <- unique(c(
    sub("^\\.(.*)-stage-[A-Za-z0-9._-]+$", "\\1", basename(stage)),
    sub("^\\.(.*)-backup-[A-Za-z0-9._-]+$", "\\1", basename(backup))
  ))
  for (slug in slugs[nzchar(slugs)]) {
    target <- file.path(analysis_root, slug)
    stage_path <- stage[startsWith(basename(stage), paste0(".", slug, "-stage-"))]
    backup_path <- backup[startsWith(basename(backup), paste0(".", slug, "-backup-"))]
    if (dir.exists(target)) {
      if (length(stage_path)) unlink(stage_path, recursive = TRUE)
      if (length(backup_path)) unlink(backup_path, recursive = TRUE)
    } else if (length(backup_path)) {
      if (!file.rename(backup_path[[1]], target)) stop("Could not recover saved analysis backup: ", backup_path[[1]], call. = FALSE)
      if (length(stage_path)) unlink(stage_path, recursive = TRUE)
    } else if (length(stage_path)) {
      unlink(stage_path, recursive = TRUE)
    }
  }
  manifest_entries <- list.files(analysis_root, pattern = "^manifest\\.ya?ml$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  manifest_stage_entries <- list.files(analysis_root, pattern = "^\\.manifest\\.ya?ml-stage-", recursive = TRUE, full.names = TRUE, all.files = TRUE)
  manifest_backup_entries <- list.files(analysis_root, pattern = "^\\.manifest\\.ya?ml-backup-", recursive = TRUE, full.names = TRUE, all.files = TRUE)
  manifest_dirs <- unique(c(dirname(manifest_entries), dirname(manifest_stage_entries), dirname(manifest_backup_entries)))
  for (directory in manifest_dirs) {
    manifest_stages <- list.files(directory, pattern = "^\\.manifest\\.ya?ml-stage-", full.names = TRUE, all.files = TRUE)
    manifest_backups <- list.files(directory, pattern = "^\\.manifest\\.ya?ml-backup-", full.names = TRUE, all.files = TRUE)
    manifest_yaml <- file.path(directory, "manifest.yaml")
    manifest_yml <- file.path(directory, "manifest.yml")
    manifest_path <- if (file.exists(manifest_yaml)) manifest_yaml else if (file.exists(manifest_yml)) manifest_yml else manifest_yaml
    if (file.exists(manifest_path)) {
      if (length(manifest_stages)) unlink(manifest_stages)
      if (length(manifest_backups)) unlink(manifest_backups)
    } else if (length(manifest_backups)) {
      backup_name <- basename(manifest_backups[[1]])
      if (grepl("manifest\\.yml-backup-", backup_name, ignore.case = TRUE) && !grepl("manifest\\.yaml-backup-", backup_name, ignore.case = TRUE)) {
        manifest_path <- manifest_yml
      }
      if (!file.rename(manifest_backups[[1]], manifest_path)) stop("Could not recover saved analysis manifest backup.", call. = FALSE)
      if (length(manifest_stages)) unlink(manifest_stages)
    }
  }
  invisible(NULL)
}

introstat_acquire_analysis_lock <- function(root, timeout = 30, stale_after = 300) {
  analysis_root <- file.path(normalizePath(root, mustWork = TRUE), "analysis")
  dir.create(analysis_root, recursive = TRUE, showWarnings = FALSE)
  lock <- file.path(analysis_root, ".analysis-lock")
  started <- Sys.time()
  repeat {
    if (dir.create(lock, showWarnings = FALSE)) {
      writeLines(
        paste0("pid=", Sys.getpid(), "\nstarted=", format(started, tz = "UTC", usetz = TRUE)),
        file.path(lock, "owner.txt"),
        useBytes = TRUE
      )
      tryCatch(
        introstat_recover_analysis_transactions(root),
        error = function(error) {
          unlink(lock, recursive = TRUE)
          stop(error)
        }
      )
      return(lock)
    }
    owner <- introstat_analysis_lock_owner(lock)
    if (!is.na(owner$pid) && !introstat_analysis_process_alive(owner$pid)) {
      unlink(lock, recursive = TRUE)
      next
    }
    if (is.na(owner$pid)) {
      info <- file.info(lock)
      age <- if (nrow(info) && !is.na(info$mtime)) as.numeric(difftime(Sys.time(), info$mtime, units = "secs")) else Inf
      # A creator gets a short grace period to write owner.txt; after that an
      # ownerless lock is treated as an interrupted acquisition.
      if (age >= min(1, stale_after)) {
        unlink(lock, recursive = TRUE)
        next
      }
    }
    elapsed <- as.numeric(difftime(Sys.time(), started, units = "secs"))
    if (elapsed >= timeout) {
      stop("Another analysis submission is in progress; try again shortly.", call. = FALSE)
    }
    Sys.sleep(0.05)
  }
}

introstat_release_analysis_lock <- function(lock) {
  if (!is.null(lock) && dir.exists(lock)) unlink(lock, recursive = TRUE)
  invisible(NULL)
}

introstat_analysis_metadata_fields <- c(
  "problem", "question", "section_hint", "section_id", "section", "tags",
  "order", "report_order", "dimensions", "width", "height"
)

introstat_build_analysis_manifest <- function(
    slug, title, artifact_type, display_id, source_path, object_path,
    artifact_relative_path, created_at, updated_at, existing = NULL
) {
  source_digest <- introstat_sha256_file(source_path)
  object_digest <- introstat_sha256_file(object_path)
  values <- list(
    schema_version = introstat_analysis_schema_version,
    key = as.character(slug),
    slug = as.character(slug),
    title = as.character(title),
    status = "analysis",
    artifact_type = as.character(artifact_type),
    display_id = as.character(display_id),
    object = basename(object_path),
    source = basename(source_path),
    artifacts = list(as.character(artifact_relative_path)),
    created_at = as.character(created_at),
    updated_at = as.character(updated_at),
    content_digests = list(analysis_r = source_digest, object_rds = object_digest)
  )
  # Hash staged files before the manifest is written and store only portable
  # paths. Catalog records expose absolute paths after containment checks.
  if (!is.null(existing)) {
    for (field in introstat_analysis_metadata_fields) {
      if (!is.null(existing[[field]])) values[[field]] <- existing[[field]]
    }
  }
  values
}

introstat_manifest_relative_path <- function(path, directory, label) {
  value <- as.character(path %||% "")
  if (length(value) != 1L || !nzchar(value)) stop("Missing ", label, " path in analysis manifest.", call. = FALSE)
  normalized <- gsub("\\\\", "/", value)
  if (grepl("^(?:/|[A-Za-z]:/|~)", normalized) || any(strsplit(normalized, "/", fixed = TRUE)[[1]] %in% c(".."))) {
    stop("Analysis manifest ", label, " path must stay inside its saved analysis directory.", call. = FALSE)
  }
  normalized
}

introstat_path_contained <- function(path, parent) {
  path <- normalizePath(path, mustWork = TRUE)
  parent <- normalizePath(parent, mustWork = TRUE)
  identical(path, parent) || startsWith(path, paste0(parent, .Platform$file.sep))
}

introstat_manifest_digests <- function(manifest) {
  digests <- manifest$content_digests %||% manifest$digests %||% list()
  if (!is.list(digests)) stop("Analysis manifest content_digests must be a mapping.", call. = FALSE)
  source <- digests$analysis_r %||% digests$source %||% digests$source_sha256 %||% digests[["analysis.R"]] %||% manifest$source_sha256 %||% manifest$analysis_sha256
  object <- digests$object_rds %||% digests$object %||% digests$object_sha256 %||% digests[["object.rds"]] %||% manifest$object_sha256
  source <- as.character(source %||% "")
  object <- as.character(object %||% "")
  if (length(source) != 1L || length(object) != 1L ||
      !grepl("^[a-fA-F0-9]{64}$", source) || !grepl("^[a-fA-F0-9]{64}$", object)) {
    stop("Analysis manifest must contain SHA-256 digests for analysis.R and object.rds.", call. = FALSE)
  }
  list(analysis_r = tolower(source), object_rds = tolower(object))
}

introstat_analysis_scalar <- function(value, name, required = TRUE) {
  if (is.null(value) || !length(value)) {
    if (required) stop("Saved analysis manifest requires scalar ", name, ".", call. = FALSE)
    return(NULL)
  }
  if (is.list(value) || length(value) != 1L || is.na(value) || !nzchar(trimws(as.character(value)))) {
    stop("Saved analysis manifest field ", name, " must be one non-empty scalar.", call. = FALSE)
  }
  as.character(value)
}

introstat_analysis_safe_slug <- function(value, name = "slug") {
  value <- introstat_analysis_scalar(value, name)
  if (!grepl("^[a-z0-9][a-z0-9._-]*$", value)) {
    stop("Saved analysis ", name, " is unsafe.", call. = FALSE)
  }
  value
}

introstat_analysis_data_declaration <- function(manifest) {
  fields <- c("data", "data_file", "data_files", "data_path", "data_paths", "required_data_files")
  present <- fields[vapply(fields, function(field) !is.null(manifest[[field]]) && length(manifest[[field]]), logical(1))]
  list(present = length(present) > 0L, fields = present)
}

introstat_write_manifest_atomic <- function(path, values) {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  directory <- dirname(path)
  dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  stage <- tempfile(paste0(".", basename(path), "-stage-"), tmpdir = directory)
  backup <- tempfile(paste0(".", basename(path), "-backup-"), tmpdir = directory)
  yaml::write_yaml(values, stage)
  moved <- FALSE
  installed <- FALSE
  on.exit({
    if (!installed && moved && !file.exists(path) && file.exists(backup)) file.rename(backup, path)
    if (file.exists(stage)) unlink(stage)
    if (file.exists(backup)) unlink(backup)
  }, add = TRUE)
  if (file.exists(path)) {
    if (!file.rename(path, backup)) stop("Could not stage manifest for replacement: ", path, call. = FALSE)
    moved <- TRUE
  }
  if (!file.rename(stage, path)) stop("Could not install manifest: ", path, call. = FALSE)
  installed <- TRUE
  invisible(normalizePath(path, mustWork = TRUE))
}

introstat_legacy_manifest_record <- function(path, manifest) {
  schema_value <- manifest$schema_version
  if (!is.null(schema_value) && length(schema_value)) {
    schema <- suppressWarnings(as.integer(introstat_analysis_scalar(schema_value, "schema_version")))
    if (is.na(schema) || !schema %in% c(1L, introstat_analysis_schema_version)) {
      stop("Unsupported saved analysis manifest schema in ", path, call. = FALSE)
    }
    if (identical(schema, introstat_analysis_schema_version)) return(NULL)
  }
  key <- introstat_analysis_safe_slug(manifest$key %||% manifest$slug, "key")
  slug <- introstat_analysis_safe_slug(manifest$slug, "slug")
  title <- introstat_analysis_scalar(manifest$title, "title")
  status <- introstat_analysis_scalar(manifest$status, "status")
  if (!identical(status, "analysis")) stop("Saved analysis status must be analysis in ", path, call. = FALSE)
  artifact_type <- introstat_analysis_scalar(manifest$artifact_type, "artifact_type")
  if (!artifact_type %in% introstat_analysis_artifact_types) stop("Unsupported artifact_type in ", path, call. = FALSE)
  source_rel <- introstat_manifest_relative_path(manifest$source, dirname(path), "source")
  object_rel <- introstat_manifest_relative_path(manifest$object, dirname(path), "object")
  source_path <- normalizePath(file.path(dirname(path), source_rel), mustWork = TRUE)
  object_path <- normalizePath(file.path(dirname(path), object_rel), mustWork = TRUE)
  if (!introstat_path_contained(source_path, dirname(path)) || !introstat_path_contained(object_path, dirname(path))) {
    stop("Legacy saved analysis paths must remain inside their analysis directory.", call. = FALSE)
  }
  created <- introstat_analysis_scalar(manifest$created_at, "created_at")
  updated <- introstat_analysis_scalar(manifest$updated_at, "updated_at")
  list(
    path = path,
    manifest = manifest,
    key = key,
    slug = slug,
    title = title,
    artifact_type = artifact_type,
    source_path = source_path,
    object_path = object_path,
    created_at = created,
    updated_at = updated,
    data_declaration = introstat_analysis_data_declaration(manifest)
  )
}

introstat_migrate_legacy_analyses <- function(root = getwd(), lock = NULL) {
  root <- normalizePath(root, mustWork = TRUE)
  owned_lock <- is.null(lock)
  if (owned_lock) lock <- introstat_acquire_analysis_lock(root)
  on.exit(if (owned_lock) introstat_release_analysis_lock(lock), add = TRUE)
  paths <- introstat_analysis_manifest_paths(root)
  if (!length(paths)) return(list(migrated = character(), data_declaration_missing = character(), untouched = character()))
  raw_originals <- lapply(paths, function(path) readBin(path, what = "raw", n = file.info(path)$size))
  names(raw_originals) <- paths
  records <- lapply(paths, function(path) list(path = path, manifest = read_manifest(path)))
  legacy <- list()
  untouched <- character()
  for (record in records) {
    schema <- record$manifest$schema_version
    if (!is.null(schema) && length(schema) && identical(suppressWarnings(as.integer(schema)), introstat_analysis_schema_version)) {
      # A current-schema manifest is never silently repaired or downgraded.
      untouched <- c(untouched, record$path)
      next
    }
    prepared <- introstat_legacy_manifest_record(record$path, record$manifest)
    if (!is.null(prepared)) legacy[[length(legacy) + 1L]] <- prepared
  }
  if (!length(legacy)) return(list(migrated = character(), data_declaration_missing = character(), untouched = untouched))

  # Validate the complete ID namespace before changing any manifest. This
  # makes malformed or duplicate legacy sets leave every original byte intact.
  all_types <- vapply(records, function(record) as.character(record$manifest$artifact_type %||% ""), character(1))
  all_ids <- vapply(records, function(record) toupper(trimws(as.character(record$manifest$display_id %||% ""))), character(1))
  for (group in list(c("plot"), c("table", "regression_table", "summary_table"))) {
    selected <- all_types %in% group
    if (any(!selected & !all_types %in% introstat_analysis_artifact_types)) stop("Unsupported artifact type in saved analysis set.", call. = FALSE)
    prefix <- if (identical(group[[1]], "plot")) "P" else "T"
    invalid <- selected & nzchar(all_ids) & !grepl(paste0("^", prefix, "[1-9][0-9]*$"), all_ids)
    if (any(invalid)) stop("Invalid ", prefix, " display ID in saved analysis set.", call. = FALSE)
    valid_ids <- all_ids[selected & nzchar(all_ids)]
    if (anyDuplicated(valid_ids)) stop("Duplicate ", prefix, " display IDs in saved analysis set.", call. = FALSE)
  }

  migrated_paths <- vapply(legacy, function(record) record$path, character(1))
  missing_data <- vapply(legacy, function(record) !isTRUE(record$data_declaration$present), logical(1))
  tryCatch({
    for (record in legacy) {
      updated <- record$manifest
      updated$schema_version <- introstat_analysis_schema_version
      updated$key <- record$key
      updated$content_digests <- list(
        analysis_r = introstat_sha256_file(record$source_path),
        object_rds = introstat_sha256_file(record$object_path)
      )
      introstat_write_manifest_atomic(record$path, updated)
    }
    introstat_backfill_analysis_display_ids(root)
  }, error = function(error) {
    for (path in paths) {
      if (file.exists(path)) unlink(path)
      writeBin(raw_originals[[path]], path)
    }
    stop(error)
  })
  if (any(missing_data)) {
    warning("Legacy saved analyses have no declared data source; migration preserved the existing source and object bytes without inventing data paths.", call. = FALSE)
  }
  list(
    migrated = migrated_paths,
    data_declaration_missing = migrated_paths[missing_data],
    untouched = untouched
  )
}

introstat_read_saved_analysis_catalog <- function(root = getwd()) {
  root <- normalizePath(root, mustWork = TRUE)
  analysis_root <- file.path(root, "analysis")
  if (!dir.exists(analysis_root)) return(list())
  paths <- introstat_analysis_manifest_paths(root)
  if (!length(paths)) return(list())
  records <- lapply(paths, function(manifest_path) {
    manifest_path <- normalizePath(manifest_path, mustWork = TRUE)
    if (!introstat_path_contained(manifest_path, analysis_root)) {
      stop("Saved analysis manifest escapes analysis/: ", manifest_path, call. = FALSE)
    }
    directory <- dirname(manifest_path)
    manifest <- read_manifest(manifest_path)
    schema <- suppressWarnings(as.integer(manifest$schema_version %||% NA_integer_))
    if (is.na(schema) || !identical(schema, introstat_analysis_schema_version)) {
      stop("Unsupported saved analysis manifest schema in ", manifest_path, call. = FALSE)
    }
    artifact_type <- as.character(manifest$artifact_type %||% "")
    if (length(artifact_type) != 1L || !artifact_type %in% introstat_analysis_artifact_types) {
      stop("Unsupported artifact_type in ", manifest_path, ": ", artifact_type, call. = FALSE)
    }
    key <- as.character(manifest$key %||% manifest$slug %||% basename(directory))
    if (length(key) != 1L || !nzchar(key) || key %in% c(".", "..") || grepl("[/\\\\]", key)) {
      stop("Saved analysis key must be a single directory-safe value in ", manifest_path, call. = FALSE)
    }
    source_rel <- introstat_manifest_relative_path(manifest$source %||% "analysis.R", directory, "source")
    object_rel <- introstat_manifest_relative_path(manifest$object %||% "object.rds", directory, "object")
    source_path <- normalizePath(file.path(directory, source_rel), mustWork = TRUE)
    object_path <- normalizePath(file.path(directory, object_rel), mustWork = TRUE)
    if (!introstat_path_contained(source_path, directory) || !introstat_path_contained(object_path, directory)) {
      stop("Saved analysis source and object must remain inside their analysis directory.", call. = FALSE)
    }
    digests <- introstat_manifest_digests(manifest)
    actual_source <- introstat_sha256_file(source_path)
    actual_object <- introstat_sha256_file(object_path)
    if (!identical(actual_source, digests$analysis_r) || !identical(actual_object, digests$object_rds)) {
      stop("Saved analysis content digest mismatch in ", manifest_path, call. = FALSE)
    }
    display_id <- introstat_analysis_manifest_id(manifest, artifact_type)
    if (!nzchar(display_id)) stop("Saved analysis is missing a display ID: ", manifest_path, call. = FALSE)
    dimensions <- manifest$dimensions
    if (is.null(dimensions) && (!is.null(manifest$width) || !is.null(manifest$height))) {
      dimensions <- list(width = manifest$width, height = manifest$height)
    }
    section_hint <- manifest$section_hint %||% manifest$section_id %||% manifest$section
    list(
      key = key,
      slug = as.character(manifest$slug %||% key),
      display_id = display_id,
      title = as.character(manifest$title %||% basename(directory)),
      visible_title = artifact_visible_title(manifest),
      artifact_visible_title = artifact_visible_title(manifest),
      artifact_type = artifact_type,
      source_path = source_path,
      object_path = object_path,
      manifest_path = manifest_path,
      source = source_path,
      object = object_path,
      manifest = manifest_path,
      analysis_directory = normalizePath(directory, mustWork = TRUE),
      paths = list(source = source_path, object = object_path, manifest = manifest_path),
      digests = digests,
      source_digest = digests$analysis_r,
      object_digest = digests$object_rds,
      created_at = as.character(manifest$created_at %||% ""),
      updated_at = as.character(manifest$updated_at %||% ""),
      problem = manifest$problem,
      question = manifest$question,
      section_hint = section_hint,
      explicit_section_hint = section_hint,
      tags = as.character(unlist(manifest$tags %||% character(), use.names = FALSE)),
      order = manifest$order %||% manifest$report_order,
      dimensions = dimensions,
      metadata = manifest
    )
  })
  keys <- vapply(records, `[[`, character(1), "key")
  ids <- vapply(records, `[[`, character(1), "display_id")
  if (anyDuplicated(keys)) stop("Saved analysis keys must be unique.", call. = FALSE)
  if (anyDuplicated(ids)) stop("Saved analysis display IDs must be unique.", call. = FALSE)
  records[order(vapply(records, function(record) {
    paste(record$created_at, record$key, sep = "\u0001")
  }, character(1)), method = "radix")]
}

introstat_discover_saved_analyses <- introstat_read_saved_analysis_catalog
introstat_analysis_catalog <- introstat_read_saved_analysis_catalog

artifact_visible_title <- function(manifest) {
  title <- as.character(manifest$title %||% "Untitled analysis")
  display_id <- toupper(as.character(manifest$display_id %||% ""))
  if (!nzchar(display_id)) return(title)
  if (startsWith(toupper(title), paste0(display_id, ":"))) return(title)
  paste0(display_id, ": ", title)
}
