if (!exists("%||%", mode = "function")) `%||%` <- function(x, y) if (is.null(x)) y else x

introstat_report_require <- function(package) {
  if (!requireNamespace(package, quietly = TRUE)) {
    stop("Required R package is not installed: ", package, call. = FALSE)
  }
}

introstat_prepare_word_table <- function(object, max_width = 6.25) {
  introstat_report_require("flextable")
  if (!inherits(object, "flextable")) stop("Expected a flextable object.", call. = FALSE)

  widths <- flextable::dim_pretty(object)$widths
  if (!length(widths) || any(!is.finite(widths)) || any(widths <= 0)) {
    stop("Could not determine readable table column widths.", call. = FALSE)
  }
  layout <- attr(object, "introstat_layout")
  if (identical(layout, "summary")) {
    columns <- length(widths)
    if (columns < 3L) stop("A summary table must include a group, count, and statistic column.", call. = FALSE)
    group_width <- min(max(widths[[1]], 0.90), 1.30)
    count_width <- 0.45
    statistic_width <- (max_width - group_width - count_width) / (columns - 2L)
    if (statistic_width < 0.70) {
      stop(
        "This summary table has too many statistic columns for a readable portrait Word page. Split it into two saved tables.",
        call. = FALSE
      )
    }
    widths <- c(group_width, count_width, rep(statistic_width, columns - 2L))
    object <- flextable::width(object, j = seq_along(widths), width = widths)
    return(flextable::paginate(object, init = TRUE, hdr_ftr = TRUE))
  }
  # Scale columns, not type. fit_to_width() can make a wide table fit by
  # collapsing its font to an unreadable size.
  if (sum(widths) > max_width) widths <- widths * max_width / sum(widths)
  min_width <- if (identical(layout, "single")) {
    0.38
  } else if (identical(layout, "comparison")) {
    0.65
  } else if (length(widths) <= 4L) {
    0.75
  } else {
    0.40
  }
  if (any(widths < min_width)) {
    stop(
      "This table is too wide for a readable portrait Word page. Shorten ordinary labels or split the model comparison into two saved tables.",
      call. = FALSE
    )
  }
  object <- flextable::width(object, j = seq_along(widths), width = widths)
  flextable::paginate(object, init = TRUE, hdr_ftr = TRUE)
}

introstat_report_artifact <- function(
  object,
  title = NULL,
  problem = NULL,
  question = NULL,
  section_id = NULL,
  section_title = NULL,
  artifact_type = NULL,
  width = NULL,
  height = NULL
) {
  if (is.null(artifact_type)) {
    artifact_type <- if (inherits(object, "ggplot")) {
      "plot"
    } else if (inherits(object, "flextable")) {
      "table"
    } else {
      stop(
        "Cannot infer report artifact type from class: ",
        paste(class(object), collapse = "/"),
        call. = FALSE
      )
    }
  }

  if (!artifact_type %in% c("plot", "table", "regression_table", "summary_table")) {
    stop("Unsupported report artifact type: ", artifact_type, call. = FALSE)
  }
  if (identical(artifact_type, "plot") && !inherits(object, "ggplot")) {
    stop("A plot report artifact must contain a ggplot object.", call. = FALSE)
  }
  if (!identical(artifact_type, "plot") && !inherits(object, "flextable")) {
    stop("A table report artifact must contain a flextable object.", call. = FALSE)
  }

  structure(
    list(
      object = object,
      title = title,
      problem = problem,
      question = question,
      section_id = section_id,
      section_title = section_title,
      artifact_type = artifact_type,
      width = width,
      height = height
    ),
    class = "introstat_report_artifact"
  )
}

introstat_report_value <- function(value, spec) {
  if (inherits(value, "introstat_report_artifact")) {
    item <- value
    fields <- c("title", "problem", "question", "section_id", "section_title", "artifact_type", "width", "height")
    for (field in fields) {
      if (!is.null(spec[[field]])) item[[field]] <- spec[[field]]
    }
    return(item)
  }

  introstat_report_artifact(
    value,
    title = spec$title,
    problem = spec$problem,
    question = spec$question,
    section_id = spec$section_id,
    section_title = spec$section_title,
    artifact_type = spec$artifact_type,
    width = spec$width,
    height = spec$height
  )
}

introstat_report_figure_size <- function(
  item,
  default_width = 4.75,
  default_aspect_ratio = 0.75,
  max_width = 5.25,
  max_height = 4.5,
  min_width = 2.25,
  min_height = 2.25
) {
  width <- item$width
  height <- item$height
  valid_dimension <- function(value) {
    !is.null(value) && is.numeric(value) && length(value) == 1L &&
      !is.na(value) && is.finite(value) && value > 0
  }

  aspect_ratio <- if (valid_dimension(width) && valid_dimension(height)) {
    height / width
  } else {
    item$object$theme$aspect.ratio
  }
  if (!valid_dimension(aspect_ratio)) aspect_ratio <- default_aspect_ratio

  if (!valid_dimension(width) && !valid_dimension(height)) {
    width <- default_width
    height <- width * aspect_ratio
  } else if (valid_dimension(width) && !valid_dimension(height)) {
    height <- width * aspect_ratio
  } else if (!valid_dimension(width) && valid_dimension(height)) {
    width <- height / aspect_ratio
  }

  scale <- min(1, max_width / width, max_height / height)
  size <- c(width = unname(width * scale), height = unname(height * scale))
  if (any(!is.finite(size)) || size[["width"]] < min_width || size[["height"]] < min_height) {
    stop(
      "Figure aspect ratio produces an unreadably narrow or short Word figure (",
      sprintf("%.2f x %.2f inches", size[["width"]], size[["height"]]),
      "). Adjust the saved output dimensions or the ggplot aspect ratio.",
      call. = FALSE
    )
  }
  size
}

introstat_write_compiled_report <- function(
  items,
  output,
  title = "Statistical analysis report",
  subtitle = NULL,
  sections = NULL
) {
  if (!length(items)) stop("No saved outputs were supplied.", call. = FALSE)
  if (file.exists(output)) stop("Report already exists; it will not be overwritten: ", output, call. = FALSE)

  introstat_report_require("officer")
  introstat_report_require("flextable")
  introstat_report_require("ggplot2")
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)

  render_dir <- tempfile("introstat-compiled-report-")
  dir.create(render_dir)
  on.exit(unlink(render_dir, recursive = TRUE), add = TRUE)

  add_text <- function(doc, text, size, bold = FALSE, italic = FALSE, color = "#123047", align = "left", before = 0, after = 0, keep = FALSE) {
    officer::body_add_fpar(
      doc,
      officer::fpar(
        officer::ftext(text, officer::fp_text(font.size = size, bold = bold, italic = italic, color = color)),
        fp_p = officer::fp_par(text.align = align, padding.top = before, padding.bottom = after, keep_with_next = keep)
      )
    )
  }

  doc <- officer::read_docx()
  doc <- officer::body_set_default_section(
    doc,
    officer::prop_section(
      page_size = officer::page_size(width = 8.5, height = 11, orient = "portrait", unit = "in"),
      page_margins = officer::page_mar(top = 1, bottom = 1, left = 1, right = 1, header = 0.5, footer = 0.5)
    )
  )
  doc <- add_text(doc, title, 22, bold = TRUE, after = 4)
  if (!is.null(subtitle) && nzchar(as.character(subtitle))) doc <- add_text(doc, subtitle, 13, color = "#526979", after = 12)

  figure_number <- 0L
  table_number <- 0L
  if (is.null(sections)) {
    sections <- list(list(id = "report-outputs", title = "Report outputs", include_if_empty = FALSE))
    for (i in seq_along(items)) {
      items[[i]]$section_id <- "report-outputs"
      items[[i]]$section_title <- "Report outputs"
    }
  }

  item_index <- 0L
  for (section in sections) {
    section_items <- Filter(function(x) identical(x$section_id, section$id), items)
    if (!length(section_items) && !isTRUE(section$include_if_empty)) next
    doc <- add_text(doc, section$title, 15, bold = TRUE, before = 14, after = 7, keep = TRUE)

    for (item in section_items) {
      item_index <- item_index + 1L
      item_title <- if (!is.null(item$title) && nzchar(item$title)) item$title else paste("Saved output", item_index)
      if (identical(item$artifact_type, "plot")) {
        figure_number <- figure_number + 1L
        caption <- paste0("Figure ", figure_number, ". ", item_title)
        size <- introstat_report_figure_size(item)
        image <- file.path(render_dir, sprintf("figure-%03d.png", figure_number))
        ggplot2::ggsave(
          image,
          item$object,
          width = size[["width"]],
          height = size[["height"]],
          dpi = 300,
          bg = "white"
        )
        doc <- officer::body_add_fpar(
          doc,
          officer::fpar(
            officer::external_img(
              image,
              width = size[["width"]],
              height = size[["height"]]
            ),
            fp_p = officer::fp_par(text.align = "center", keep_with_next = TRUE)
          )
        )
        doc <- add_text(doc, caption, 9, italic = TRUE, color = "#384955", align = "center", before = 4, after = 6)
      } else {
        table_number <- table_number + 1L
        caption <- paste0("Table ", table_number, ". ", item_title)
        doc <- add_text(doc, caption, 9, italic = TRUE, color = "#384955", align = "center", before = 4, after = 6, keep = TRUE)
        table <- introstat_prepare_word_table(item$object, max_width = 6.25)
        doc <- flextable::body_add_flextable(
          doc,
          value = table,
          align = "center",
          topcaption = FALSE,
          keepnext = TRUE
        )
      }

      doc <- officer::body_add_par(doc, "", style = "Normal")
    }
    doc <- officer::body_add_par(doc, "", style = "Normal")
    doc <- officer::body_add_par(doc, "", style = "Normal")
  }

  print(doc, target = output)
  normalizePath(output, mustWork = TRUE)
}

# Validate an object without running the saved analysis source.  Normal report
# compilation calls this on frozen object.rds files; source execution belongs
# exclusively to a snapshot's verify.R script.
introstat_validate_report_object <- function(object, artifact_type) {
  artifact_type <- as.character(artifact_type %||% "")
  if (identical(artifact_type, "plot")) {
    if (!inherits(object, "ggplot")) stop("Expected a ggplot object for a plot output.", call. = FALSE)
  } else if (artifact_type %in% c("table", "regression_table", "summary_table")) {
    if (!inherits(object, "flextable")) stop("Expected a flextable object for a table output.", call. = FALSE)
  } else {
    stop("Unsupported report artifact type: ", artifact_type, call. = FALSE)
  }
  invisible(TRUE)
}

introstat_render_frozen_report <- function(items, output, title = "Statistical analysis report", sections = NULL) {
  if (!length(items)) stop("No frozen report outputs were supplied.", call. = FALSE)
  lapply(items, function(item) introstat_validate_report_object(item$object, item$artifact_type))
  introstat_write_compiled_report(items, output = output, title = title, subtitle = NULL, sections = sections)
}

introstat_report_objects_equivalent <- function(expected, actual, artifact_type) {
  introstat_validate_report_object(expected, artifact_type)
  introstat_validate_report_object(actual, artifact_type)
  isTRUE(all.equal(expected, actual, check.attributes = FALSE))
}

introstat_report_copy_tree <- function(source, destination) {
  source <- normalizePath(source, mustWork = TRUE)
  dir.create(destination, recursive = TRUE, showWarnings = FALSE)
  entries <- list.files(source, recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE)
  for (entry in entries) {
    relative <- substring(normalizePath(entry, mustWork = TRUE), nchar(source) + 2L)
    target <- file.path(destination, relative)
    if (dir.exists(entry)) dir.create(target, recursive = TRUE, showWarnings = FALSE) else {
      dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)
      if (!file.copy(entry, target, overwrite = FALSE, copy.date = TRUE)) stop("Could not copy snapshot verification input.", call. = FALSE)
    }
  }
  invisible(destination)
}

introstat_report_verify_snapshot <- function(snapshot_root, items) {
  snapshot_root <- normalizePath(snapshot_root, mustWork = TRUE)
  workspace <- tempfile("introstat-report-verify-")
  dir.create(workspace, recursive = TRUE)
  on.exit(unlink(workspace, recursive = TRUE), add = TRUE)
  verify_root <- file.path(workspace, "snapshot")
  introstat_report_copy_tree(snapshot_root, verify_root)
  old <- setwd(verify_root)
  on.exit(setwd(old), add = TRUE)
  for (item in items) {
    expected <- readRDS(file.path(verify_root, item$object))
    if (!identical(introstat_sha256_file(file.path(verify_root, item$source)), item$source_digest)) stop("Frozen source digest mismatch: ", item$display_id, call. = FALSE)
    if (!identical(introstat_sha256_file(file.path(verify_root, item$object)), item$object_digest)) stop("Frozen object digest mismatch: ", item$display_id, call. = FALSE)
    environment <- new.env(parent = globalenv())
    result <- source(file.path(verify_root, item$source), local = environment, echo = FALSE)
    if (!introstat_report_objects_equivalent(expected, result$value, item$artifact_type)) stop("Copied source did not reproduce ", item$display_id, " within the recorded environment.", call. = FALSE)
  }
  invisible(TRUE)
}
