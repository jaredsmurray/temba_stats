introstat_require <- function(package) {
  if (!requireNamespace(package, quietly = TRUE)) {
    stop("Required R package is not installed: ", package, call. = FALSE)
  }
}

introstat_theme <- function() {
  introstat_require("ggplot2")
  ggplot2::theme_minimal(base_size = 11) +
    ggplot2::theme(
      plot.title.position = "plot",
      panel.grid.minor = ggplot2::element_blank()
    )
}

artifact_reference_numbers <- function(parts) {
  figure_number <- 0L
  table_number <- 0L
  references <- list()

  for (part in parts) {
    if (identical(part$artifact_type, "plot")) {
      figure_number <- figure_number + 1L
      references[[part$id]] <- list(label = "Figure", number = figure_number)
    } else if (part$artifact_type %in% c("regression_table", "summary_table")) {
      table_number <- table_number + 1L
      references[[part$id]] <- list(label = "Table", number = table_number)
    }
  }

  references
}

artifact_caption <- function(part, reference) {
  paste0(reference$label, " ", reference$number, ". ", part$title)
}

figure_size_for_docx <- function(
  object,
  max_width = 6,
  max_height = 5.6,
  default_aspect_ratio = 4.5 / 7
) {
  validate_artifact(object, "plot")
  aspect_ratio <- object$theme$aspect.ratio
  if (is.null(aspect_ratio) || !is.numeric(aspect_ratio) || length(aspect_ratio) != 1L ||
      is.na(aspect_ratio) || aspect_ratio <= 0) {
    aspect_ratio <- default_aspect_ratio
  }

  width <- max_width
  height <- width * aspect_ratio
  if (height > max_height) {
    height <- max_height
    width <- height / aspect_ratio
  }

  c(width = unname(width), height = unname(height))
}

introstat_true_minus <- function(x) gsub("-", "\u2212", x, fixed = TRUE)

introstat_fixed <- function(x, digits = 2L, unavailable = "\u2014") {
  if (!is.numeric(digits) || length(digits) != 1L || is.na(digits) ||
      digits < 0 || digits > 8 || digits != as.integer(digits)) {
    stop("fmt must be a whole number from 0 through 8.", call. = FALSE)
  }
  out <- rep(unavailable, length(x))
  ok <- is.finite(x)
  if (any(ok)) {
    rounded <- round(x[ok], digits)
    rounded[rounded == 0] <- 0 # remove the misleading display "-0.00"
    out[ok] <- formatC(
      rounded, format = "f", digits = as.integer(digits),
      big.mark = ",", decimal.mark = "."
    )
  }
  introstat_true_minus(out)
}

introstat_pvalue <- function(x, unavailable = "\u2014") {
  out <- rep(unavailable, length(x))
  ok <- is.finite(x) & x >= 0 & x <= 1
  out[ok & x < .001] <- "<0.001"
  ordinary <- ok & x >= .001
  out[ordinary] <- introstat_fixed(x[ordinary], 3L, unavailable)
  out
}

introstat_check_fixed_scale <- function(
  values,
  digits,
  context = "table",
  value_context = context,
  digits_name = "digits",
  rescale_suffix = ""
) {
  introstat_fixed(0, digits)
  values <- abs(values[is.finite(values) & values != 0])
  if (!length(values)) return(invisible(TRUE))
  if (max(values) >= 1e9) {
    stop(
      "Fixed notation would make this ", context,
      " unwieldy. Rescale the relevant variable to more interpretable units",
      rescale_suffix, ".",
      call. = FALSE
    )
  }
  if (min(values) < 0.5 * 10^(-digits)) {
    stop(
      "The requested precision would display a nonzero ", value_context,
      " value as zero. Increase ", digits_name,
      "= or rescale the relevant variable", rescale_suffix, ".",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

introstat_validate_coef_map <- function(coef_map) {
  if (is.null(coef_map)) return(invisible(TRUE))
  if (!is.character(coef_map) || is.null(names(coef_map)) || !length(coef_map) ||
      anyNA(coef_map) || any(!nzchar(names(coef_map))) || any(!nzchar(coef_map)) ||
      anyDuplicated(names(coef_map)) || anyDuplicated(unname(coef_map))) {
    stop(
      "coef_map must be a non-empty named character vector with unique, non-empty term names and labels.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

introstat_reg_models <- function(models) {
  if (inherits(models, "lm")) return(list(Model = models))
  if (!is.list(models) || !length(models)) {
    stop("make_reg_table() requires an lm object or a non-empty named list of lm objects.", call. = FALSE)
  }
  if (is.null(names(models)) || any(!nzchar(names(models))) || anyDuplicated(names(models))) {
    stop("A model list must have unique, non-empty names for its column headings.", call. = FALSE)
  }
  if (!all(vapply(models, inherits, logical(1), "lm"))) {
    stop("Every item in a model list must be an lm object.", call. = FALSE)
  }
  if (length(models) > 4L) {
    stop(
      "A readable comparison table supports at most four models. Split the models into two saved tables.",
      call. = FALSE
    )
  }
  models
}

introstat_model_terms <- function(model) {
  introstat_require("modelsummary")
  estimates <- modelsummary::get_estimates(model, conf_level = .95)
  estimates[!is.na(estimates$term) & nzchar(estimates$term), , drop = FALSE]
}

introstat_check_reg_scale <- function(estimates, fmt) {
  values <- unlist(lapply(
    estimates,
    function(x) c(x$estimate, x$std.error, x$conf.low, x$conf.high)
  ), use.names = FALSE)
  introstat_check_fixed_scale(
    values,
    fmt,
    context = "regression table",
    value_context = "regression",
    digits_name = "fmt",
    rescale_suffix = " and refit the model"
  )
}

introstat_term_order <- function(estimates, coef_map) {
  present <- unique(unlist(lapply(estimates, function(x) x$term), use.names = FALSE))
  if (is.null(coef_map)) present else intersect(names(coef_map), present)
}

introstat_compact_term_piece <- function(value) {
  value <- gsub("`", "", value, fixed = TRUE)
  value <- sub("^factor\\((.*)\\)$", "\\1", value)
  pieces <- strsplit(value, "[^[:alnum:]]+", perl = TRUE)[[1]]
  pieces <- pieces[nzchar(pieces)]
  if (!length(pieces)) return(value)
  paste0(
    vapply(pieces, function(piece) {
      paste0(toupper(substr(piece, 1L, 1L)), substr(piece, 2L, nchar(piece)))
    }, character(1)),
    collapse = ""
  )
}

introstat_factor_levels <- function(models) {
  output <- list()
  for (model in models) {
    for (variable in names(model$xlevels)) {
      output[[variable]] <- unique(c(output[[variable]], as.character(model$xlevels[[variable]])))
    }
  }
  output
}

introstat_default_term_label <- function(term, factor_levels) {
  if (identical(term, "(Intercept)")) return("Intercept")
  components <- strsplit(term, ":", fixed = TRUE)[[1]]
  labels <- vapply(components, function(component) {
    variables <- names(factor_levels)
    if (length(variables)) variables <- variables[order(nchar(variables), decreasing = TRUE)]
    for (variable in variables) {
      for (level in factor_levels[[variable]]) {
        if (identical(component, paste0(variable, level))) {
          return(paste0(
            introstat_compact_term_piece(variable),
            introstat_compact_term_piece(level)
          ))
        }
      }
    }
    component
  }, character(1))
  paste(labels, collapse = " × ")
}

introstat_term_labels <- function(terms, coef_map, models) {
  if (!is.null(coef_map)) return(unname(coef_map[terms]))
  factor_levels <- introstat_factor_levels(models)
  vapply(terms, introstat_default_term_label, character(1), factor_levels = factor_levels)
}

introstat_gof_rows <- function(model, fmt, gof) {
  s <- summary(model)
  labels <- character()
  values <- character()
  if ("sigma" %in% gof) {
    labels <- c(labels, "Residual standard error")
    values <- c(values, introstat_fixed(s$sigma, fmt))
  }
  if ("r.squared" %in% gof) {
    labels <- c(labels, "R\u00b2")
    values <- c(values, introstat_fixed(s$r.squared, 3L))
  }
  if ("adj.r.squared" %in% gof) {
    labels <- c(labels, "Adjusted R\u00b2")
    values <- c(values, introstat_fixed(s$adj.r.squared, 3L))
  }
  if ("nobs" %in% gof) {
    labels <- c(labels, "n")
    values <- c(values, formatC(stats::nobs(model), format = "d", big.mark = ","))
  }
  stats::setNames(values, labels)
}

# Canonical textbook-style table for one lm or a modest named model comparison.
make_reg_table <- function(
  model = NULL,
  fmt = 2,
  coef_map = NULL,
  gof = c("sigma", "r.squared", "adj.r.squared", "nobs"),
  layout = c("auto", "single", "comparison"),
  digits = NULL,
  models = NULL
) {
  introstat_require("flextable")
  introstat_require("modelsummary")
  if (!is.null(digits)) {
    warning("digits= is deprecated; use fmt= instead.", call. = FALSE)
    fmt <- digits
  }
  introstat_fixed(0, fmt) # validate once, before doing model work
  introstat_validate_coef_map(coef_map)
  allowed_gof <- c("sigma", "r.squared", "adj.r.squared", "nobs")
  if (!is.character(gof) || any(!gof %in% allowed_gof) || anyDuplicated(gof)) {
    stop("gof must contain unique values from sigma, r.squared, adj.r.squared, and nobs.", call. = FALSE)
  }

  if (!is.null(model) && !is.null(models)) {
    stop("Supply either model= or models=, not both.", call. = FALSE)
  }
  if (is.null(model)) model <- models
  models <- introstat_reg_models(model)
  layout <- match.arg(layout)
  if (layout == "auto") layout <- if (length(models) == 1L) "single" else "comparison"
  if (layout == "single" && length(models) != 1L) {
    stop("layout = 'single' requires exactly one model.", call. = FALSE)
  }
  estimates <- lapply(models, introstat_model_terms)
  introstat_check_reg_scale(estimates, fmt)
  terms <- introstat_term_order(estimates, coef_map)
  if (!length(terms)) stop("No coefficients remain after applying coef_map.", call. = FALSE)
  labels <- introstat_term_labels(terms, coef_map, models)

  if (layout == "single") {
    est <- estimates[[1]]
    rows <- match(terms, est$term)
    tab <- data.frame(
      Term = labels,
      Estimate = introstat_fixed(est$estimate[rows], fmt),
      `Std. error` = introstat_fixed(est$std.error[rows], fmt),
      `95% CI` = paste0(
        "[", introstat_fixed(est$conf.low[rows], fmt), ", ",
        introstat_fixed(est$conf.high[rows], fmt), "]"
      ),
      t = introstat_fixed(est$statistic[rows], 2L),
      `p-value` = introstat_pvalue(est$p.value[rows]),
      check.names = FALSE
    )
    gof_values <- introstat_gof_rows(models[[1]], fmt, gof)
    if (length(gof_values)) {
      tab <- rbind(
        tab,
        data.frame(
          Term = names(gof_values), Estimate = unname(gof_values),
          `Std. error` = "", `95% CI` = "", t = "", `p-value` = "",
          check.names = FALSE
        )
      )
    }
  } else {
    tab <- data.frame(Term = character(), check.names = FALSE)
    tab <- data.frame(Term = rep(labels, each = 2L), check.names = FALSE)
    tab$Term[seq(2L, nrow(tab), by = 2L)] <- ""
    for (i in seq_along(models)) {
      est <- estimates[[i]]
      rows <- match(terms, est$term)
      values <- rep("\u2014", length(terms) * 2L)
      available <- !is.na(rows)
      values[seq(1L, length(values), by = 2L)[available]] <- introstat_fixed(est$estimate[rows[available]], fmt)
      values[seq(2L, length(values), by = 2L)[available]] <- paste0(
        "[", introstat_fixed(est$conf.low[rows[available]], fmt), ", ",
        introstat_fixed(est$conf.high[rows[available]], fmt), "]"
      )
      tab[[names(models)[i]]] <- values
    }
    gof_labels <- unique(unlist(lapply(models, function(x) names(introstat_gof_rows(x, fmt, gof)))))
    if (length(gof_labels)) {
      gof_tab <- data.frame(Term = gof_labels, check.names = FALSE)
      for (i in seq_along(models)) {
        vals <- introstat_gof_rows(models[[i]], fmt, gof)
        gof_tab[[names(models)[i]]] <- unname(vals[match(gof_labels, names(vals))])
      }
      tab <- rbind(tab, gof_tab)
    }
  }

  ft <- flextable::flextable(tab)
  ft <- flextable::theme_booktabs(ft)
  ft <- flextable::bold(ft, part = "header")
  ft <- flextable::font(ft, fontname = "Arial", part = "all")
  ft <- flextable::fontsize(ft, size = if (layout == "comparison") 9 else 9.5, part = "all")
  ft <- flextable::align(ft, j = 1, align = "left", part = "all")
  if (ncol(tab) > 1L) ft <- flextable::align(ft, j = 2:ncol(tab), align = "right", part = "all")
  ft <- flextable::autofit(ft)
  attr(ft, "introstat_layout") <- layout
  attr(ft, "introstat_model_count") <- length(models)
  attr(ft, "introstat_fmt") <- as.integer(fmt)
  # Keep flextable first so its S3 methods remain the primary dispatch target.
  class(ft) <- unique(c(class(ft), "introstat_regtable"))
  ft
}

make_summary_table <- function(
  data,
  group = NULL,
  variables,
  digits = 2,
  variable_labels = NULL,
  group_label = NULL
) {
  introstat_require("flextable")
  if (!is.data.frame(data)) stop("data must be a data frame.", call. = FALSE)
  introstat_fixed(0, digits)
  if (!is.character(variables) || !length(variables) || anyNA(variables) ||
      any(!nzchar(variables)) || anyDuplicated(variables)) {
    stop("variables must be a non-empty character vector of unique column names.", call. = FALSE)
  }
  if (!is.null(group) && (!is.character(group) || length(group) != 1L || is.na(group) || !nzchar(group))) {
    stop("group must be NULL or one column name.", call. = FALSE)
  }
  if (!is.null(group_label) && (!is.character(group_label) || length(group_label) != 1L ||
      is.na(group_label) || !nzchar(group_label))) {
    stop("group_label must be NULL or one non-empty label.", call. = FALSE)
  }
  required <- c(group, variables)
  missing <- setdiff(required, names(data))
  if (length(missing)) {
    stop("Unknown column(s): ", paste(missing, collapse = ", "), call. = FALSE)
  }
  nonnumeric <- variables[!vapply(data[variables], is.numeric, logical(1))]
  if (length(nonnumeric)) {
    stop("Summary variables must be numeric: ", paste(nonnumeric, collapse = ", "), call. = FALSE)
  }
  if (!is.null(variable_labels)) {
    if (!is.character(variable_labels) || is.null(names(variable_labels)) || anyNA(variable_labels) ||
        any(!nzchar(names(variable_labels))) || any(!nzchar(variable_labels)) || anyDuplicated(names(variable_labels))) {
      stop("variable_labels must be a named character vector with non-empty names and labels.", call. = FALSE)
    }
    unknown_labels <- setdiff(names(variable_labels), variables)
    if (length(unknown_labels)) {
      stop("variable_labels contains unknown summary variables: ", paste(unknown_labels, collapse = ", "), call. = FALSE)
    }
  }

  if (is.null(group)) {
    groups <- list(list(label = "All observations", rows = seq_len(nrow(data))))
    output_group <- if (is.null(group_label)) "Sample" else group_label
  } else {
    usable <- !is.na(data[[group]])
    group_values <- sort(unique(data[[group]][usable]))
    groups <- lapply(group_values, function(value) {
      list(label = as.character(value), rows = which(usable & data[[group]] == value))
    })
    output_group <- if (is.null(group_label)) group else group_label
  }
  if (!length(groups)) stop("No rows have a non-missing group value.", call. = FALSE)

  label_for <- function(variable) {
    if (!is.null(variable_labels) && variable %in% names(variable_labels)) {
      unname(variable_labels[[variable]])
    } else {
      variable
    }
  }
  summaries <- lapply(groups, function(g) {
    subset <- data[g$rows, variables, drop = FALSE]
    lapply(subset, function(x) c(mean = mean(x, na.rm = TRUE), sd = stats::sd(x, na.rm = TRUE)))
  })
  introstat_check_fixed_scale(unlist(summaries, use.names = FALSE), digits, "summary table")

  rows <- lapply(seq_along(groups), function(i) {
    g <- groups[[i]]
    values <- summaries[[i]]
    row <- data.frame(Group = g$label, N = length(g$rows), check.names = FALSE)
    for (v in variables) {
      label <- label_for(v)
      row[[paste0(label, " mean")]] <- introstat_fixed(values[[v]][["mean"]], digits)
      row[[paste0(label, " SD")]] <- introstat_fixed(values[[v]][["sd"]], digits)
    }
    row
  })
  tab <- do.call(rbind, rows)
  names(tab)[1] <- output_group

  ft <- flextable::flextable(tab)
  variable_headers <- vapply(variables, label_for, character(1))
  header_map <- data.frame(
    col_keys = names(tab),
    variable = c(output_group, "N", rep(variable_headers, each = 2L)),
    statistic = c(output_group, "N", rep(c("Mean", "SD"), times = length(variables))),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  ft <- flextable::set_header_df(ft, mapping = header_map, key = "col_keys")
  ft <- flextable::merge_h(ft, i = 1, part = "header")
  ft <- flextable::merge_v(ft, j = 1:2, part = "header")
  ft <- flextable::theme_booktabs(ft)
  ft <- flextable::bold(ft, part = "header")
  ft <- flextable::colformat_int(ft, j = 2, big.mark = ",")
  ft <- flextable::font(ft, fontname = "Arial", part = "all")
  ft <- flextable::fontsize(ft, size = 9.5, part = "all")
  ft <- flextable::align(ft, j = 1, align = "left", part = "all")
  if (ncol(tab) > 1L) ft <- flextable::align(ft, j = 2:ncol(tab), align = "right", part = "all")
  ft <- flextable::align(ft, align = "center", part = "header")
  ft <- flextable::autofit(ft)
  attr(ft, "introstat_layout") <- "summary"
  attr(ft, "introstat_fmt") <- as.integer(digits)
  # Keep flextable first so its S3 methods remain the primary dispatch target.
  class(ft) <- unique(c(class(ft), "introstat_summarytable"))
  ft
}

# Canonical saved artifact for a specifically requested numerical scalar.
make_value_table <- function(statistic, value, digits = 3, value_format = c("number", "p_value")) {
  introstat_require("flextable")
  value_format <- match.arg(value_format)
  if (!is.character(statistic) || length(statistic) != 1L || is.na(statistic) || !nzchar(statistic)) {
    stop("statistic must be one non-empty label.", call. = FALSE)
  }
  if (length(value) != 1L || is.na(value)) {
    stop("value must be one non-missing scalar.", call. = FALSE)
  }
  if (identical(value_format, "p_value")) {
    if (!is.numeric(value) || !is.finite(value) || value < 0 || value > 1) {
      stop("A p-value must be one finite numeric value from 0 through 1.", call. = FALSE)
    }
    display_value <- introstat_pvalue(value)
  } else if (is.numeric(value)) {
    introstat_check_fixed_scale(value, digits, "value table")
    display_value <- introstat_fixed(value, digits)
  } else {
    display_value <- as.character(value)
  }
  tab <- data.frame(Statistic = statistic, Value = display_value, check.names = FALSE)
  ft <- flextable::flextable(tab)
  ft <- flextable::theme_booktabs(ft)
  ft <- flextable::bold(ft, part = "header")
  ft <- flextable::font(ft, fontname = "Arial", part = "all")
  ft <- flextable::fontsize(ft, size = 9.5, part = "all")
  ft <- flextable::align(ft, j = 1, align = "left", part = "all")
  ft <- flextable::align(ft, j = 2, align = "right", part = "all")
  flextable::autofit(ft)
}

artifact_type_from_object <- function(object) {
  if (inherits(object, "introstat_regtable")) return("regression_table")
  if (inherits(object, "introstat_summarytable")) return("summary_table")
  if (inherits(object, "ggplot")) return("plot")
  if (inherits(object, "flextable")) return("table")
  stop("Unsupported artifact class: ", paste(class(object), collapse = "/"), call. = FALSE)
}

expected_class_for_type <- function(type) {
  switch(
    type,
    plot = "ggplot",
    table = "flextable",
    regression_table = "introstat_regtable",
    summary_table = "introstat_summarytable",
    prose_only = NA_character_,
    stop("Unknown artifact type: ", type, call. = FALSE)
  )
}

validate_artifact <- function(object, type) {
  expected <- expected_class_for_type(type)
  if (is.na(expected)) stop("A prose-only part cannot contain an artifact.", call. = FALSE)
  if (!inherits(object, expected)) {
    stop(
      "Artifact has class ", paste(class(object), collapse = "/"),
      "; expected ", expected, ".", call. = FALSE
    )
  }
  invisible(TRUE)
}

introstat_markdown_cell <- function(value) {
  value <- as.character(value)
  value[is.na(value)] <- ""
  value <- gsub("\n", "<br>", value, fixed = TRUE)
  gsub("|", "\\|", value, fixed = TRUE)
}

introstat_write_chat_table <- function(object, path) {
  tab <- object$body$dataset
  header_data <- object$header$dataset
  headers <- vapply(names(tab), function(column) {
    values <- introstat_markdown_cell(header_data[[column]])
    values <- values[nzchar(values)]
    values <- values[!duplicated(values)]
    if (length(values)) paste(values, collapse = " — ") else column
  }, character(1))
  row_line <- function(values) paste0("| ", paste(introstat_markdown_cell(values), collapse = " | "), " |")
  lines <- c(
    row_line(headers),
    row_line(c(":---", rep("---:", max(0L, ncol(tab) - 1L)))),
    apply(tab, 1L, row_line)
  )
  writeLines(lines, path, useBytes = TRUE)
  path
}

render_artifact <- function(object, type, output_dir, stem = "artifact") {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  validate_artifact(object, type)

  if (identical(type, "plot")) {
    introstat_require("ggplot2")
    path <- file.path(output_dir, paste0(stem, ".png"))
    ggplot2::ggsave(path, object, width = 7, height = 4.5, dpi = 144, bg = "white")
    return(path)
  }

  introstat_require("flextable")
  introstat_require("htmltools")
  path <- file.path(output_dir, paste0(stem, ".html"))
  page <- htmltools::tags$html(
    htmltools::tags$head(
      htmltools::tags$meta(charset = "utf-8"),
      htmltools::tags$style(".introstat-table-scroll{max-width:100%;overflow-x:auto;padding:2px;}")
    ),
    htmltools::tags$body(
      htmltools::tags$div(
        class = "introstat-table-scroll",
        flextable::htmltools_value(object)
      )
    )
  )
  htmltools::save_html(page, file = path)
  chat_path <- file.path(output_dir, paste0(stem, "-chat.png"))
  table_grob <- flextable::gen_grob(object, fit = "fixed", just = "center")
  table_size <- dim(table_grob)
  grDevices::png(
    filename = chat_path,
    width = table_size$width + 12 / 72,
    height = table_size$height + 12 / 72,
    units = "in",
    res = 160,
    bg = "white"
  )
  tryCatch({
    grid::grid.newpage()
    grid::grid.draw(table_grob)
  }, finally = {
    grDevices::dev.off()
  })
  introstat_write_chat_table(
    object,
    file.path(output_dir, paste0(stem, "-chat.md"))
  )
  path
}
