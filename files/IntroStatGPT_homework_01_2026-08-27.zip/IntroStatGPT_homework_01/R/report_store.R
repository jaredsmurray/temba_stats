`%||%` <- function(x, y) if (is.null(x)) y else x

introstat_read_report_manifest <- function(path) {
  extension <- tolower(tools::file_ext(path))
  if (extension %in% c("yaml", "yml")) {
    if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
    return(yaml::read_yaml(path))
  }
  if (identical(extension, "json")) {
    if (!requireNamespace("jsonlite", quietly = TRUE)) stop("Package jsonlite is required.", call. = FALSE)
    return(jsonlite::fromJSON(path, simplifyVector = TRUE))
  }
  stop("Unsupported report manifest: ", path, call. = FALSE)
}

introstat_first_nonempty <- function(...) {
  values <- list(...)
  for (value in values) {
    if (!is.null(value) && length(value) == 1L && !is.na(value) && nzchar(as.character(value))) return(as.character(value))
  }
  NULL
}

introstat_slug <- function(value) {
  slug <- gsub("[^a-z0-9]+", "-", tolower(trimws(as.character(value))))
  slug <- gsub("^-|-$", "", slug)
  if (nzchar(slug)) slug else "section"
}

introstat_character_values <- function(value) {
  if (is.null(value)) return(character())
  as.character(unlist(value, use.names = FALSE))
}

# Persistent report containers -------------------------------------------------
#
# The functions below implement the persistent report contract.  Working
# outputs live in analysis/ and reports/report-N/ contains immutable snapshots.

introstat_report_schema <- "introstat-report-1"

introstat_report_discover_saved <- function(root) {
  if (!exists("introstat_discover_saved_analysis", mode = "function")) {
    catalog <- file.path(root, "R", "analysis_store.R")
    if (file.exists(catalog)) source(catalog, local = .GlobalEnv, echo = FALSE)
  }
  if (!exists("introstat_discover_saved_analysis", mode = "function")) stop("Saved analysis catalog is unavailable.", call. = FALSE)
  introstat_discover_saved_analysis(root)
}

introstat_report_migrate_legacy <- function(root) {
  if (exists("introstat_migrate_legacy_analyses", mode = "function")) {
    return(introstat_migrate_legacy_analyses(root))
  }
  invisible(NULL)
}

introstat_report_hash_value <- function(value) {
  if (!exists("introstat_sha256_file", mode = "function")) {
    stop("R/harness_io.R must be sourced before report_store.R.", call. = FALSE)
  }
  path <- tempfile("introstat-report-hash-")
  on.exit(if (file.exists(path)) unlink(path), add = TRUE)
  connection <- file(path, open = "wb")
  closed <- FALSE
  on.exit(if (!closed) close(connection), add = TRUE)
  writeBin(serialize(value, NULL, version = 2L), connection)
  close(connection)
  closed <- TRUE
  introstat_sha256_file(path)
}

introstat_report_atomic_write_yaml <- function(value, path) {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "-"), tmpdir = dirname(path))
  backup <- tempfile(paste0(".", basename(path), "-backup-"), tmpdir = dirname(path))
  moved <- FALSE
  installed <- FALSE
  on.exit({
    if (!installed && moved && !file.exists(path) && file.exists(backup)) file.rename(backup, path)
    if (file.exists(tmp)) unlink(tmp)
    if (file.exists(backup)) unlink(backup)
  }, add = TRUE)
  yaml::write_yaml(value, tmp)
  installed <- file.rename(tmp, path)
  if (!installed && file.exists(path)) {
    if (!file.rename(path, backup)) stop("Could not stage existing report metadata: ", path, call. = FALSE)
    moved <- TRUE
    installed <- file.rename(tmp, path)
  }
  if (!installed) stop("Could not install report metadata: ", path, call. = FALSE)
  if (file.exists(backup)) unlink(backup)
  invisible(normalizePath(path, mustWork = TRUE))
}

introstat_report_atomic_write_lines <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "-"), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  writeLines(lines, tmp, useBytes = TRUE)
  installed <- file.rename(tmp, path)
  if (!installed && file.exists(path) && isTRUE(file.remove(path))) installed <- file.rename(tmp, path)
  if (!installed) stop("Could not install report file: ", path, call. = FALSE)
  invisible(normalizePath(path, mustWork = TRUE))
}

introstat_report_id <- function(value) {
  value <- as.character(value %||% "")
  if (!grepl("^report-[1-9][0-9]*$", value)) stop("Report IDs must look like report-1.", call. = FALSE)
  value
}

introstat_snapshot_id <- function(value) {
  value <- as.character(value %||% "")
  if (!grepl("^[0-9]{4}$", value)) stop("Snapshot IDs must be four digits.", call. = FALSE)
  value
}

introstat_report_paths <- function(root, report_id) {
  root <- normalizePath(root, mustWork = TRUE)
  report_id <- introstat_report_id(report_id)
  directory <- file.path(root, "reports", report_id)
  list(
    root = root,
    directory = directory,
    report = file.path(directory, "report.yaml"),
    snapshots = file.path(directory, "snapshots")
  )
}

introstat_report_acquire_lock <- function(root, report_id, timeout = 5, stale_after = 120) {
  root <- normalizePath(root, mustWork = TRUE)
  lock_id <- gsub("[^A-Za-z0-9_.-]+", "-", as.character(report_id))
  locks <- file.path(root, "reports", ".locks")
  dir.create(locks, recursive = TRUE, showWarnings = FALSE)
  lock <- file.path(locks, paste0(lock_id, ".lock"))
  started <- Sys.time()
  repeat {
    if (dir.create(lock, showWarnings = FALSE)) {
      owner <- file.path(lock, "owner.yaml")
      owner_error <- tryCatch(introstat_report_atomic_write_yaml(list(
        report_id = report_id,
        pid = Sys.getpid(),
        host = Sys.info()[["nodename"]] %||% "unknown",
        acquired_at = format(Sys.time(), tz = "UTC", usetz = TRUE)
      ), owner), error = identity)
      if (inherits(owner_error, "condition")) {
        unlink(lock, recursive = TRUE)
        stop(owner_error)
      }
      return(lock)
    }
    owner <- file.path(lock, "owner.yaml")
    owner_data <- if (file.exists(owner)) tryCatch(introstat_report_read_yaml(owner, "report lock owner"), error = function(e) NULL) else NULL
    age <- if (file.exists(owner)) as.numeric(difftime(Sys.time(), file.info(owner)$mtime, units = "secs")) else stale_after + 1
    live <- introstat_report_lock_owner_live(owner_data)
    if (is.finite(age) && age > stale_after && !isTRUE(live)) {
      unlink(lock, recursive = TRUE)
      next
    }
    if (as.numeric(difftime(Sys.time(), started, units = "secs")) >= timeout) {
      stop("Another report operation is in progress; try again shortly.", call. = FALSE)
    }
    Sys.sleep(0.05)
  }
}

introstat_report_release_lock <- function(lock) {
  if (!is.null(lock) && dir.exists(lock)) unlink(lock, recursive = TRUE)
  invisible(TRUE)
}

introstat_report_lock_owner_live <- function(owner) {
  if (is.null(owner) || !identical(as.character(owner$host %||% ""), as.character(Sys.info()[["nodename"]] %||% ""))) return(NA)
  pid <- suppressWarnings(as.integer(owner$pid %||% NA_integer_))
  if (is.na(pid) || pid <= 0L) return(NA)
  if (identical(.Platform$OS.type, "unix")) {
    return(tryCatch(isTRUE(suppressWarnings(system2("kill", c("-0", as.character(pid)), stdout = FALSE, stderr = FALSE)) == 0L), error = function(e) NA))
  }
  NA
}

introstat_report_with_lock <- function(root, report_id, code, timeout = 5) {
  lock <- introstat_report_acquire_lock(root, report_id, timeout = timeout)
  on.exit(introstat_report_release_lock(lock), add = TRUE)
  force(code())
}

introstat_report_read_yaml <- function(path, label = "report metadata") {
  if (!file.exists(path)) stop("Missing ", label, ": ", path, call. = FALSE)
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  yaml::read_yaml(path)
}

introstat_report_path_inside <- function(path, root) {
  root <- normalizePath(root, mustWork = TRUE)
  path <- normalizePath(path, mustWork = TRUE)
  identical(path, root) || startsWith(path, paste0(root, .Platform$file.sep))
}

introstat_report_file_digest <- function(path) {
  if (!file.exists(path)) stop("Missing report input: ", path, call. = FALSE)
  introstat_sha256_file(path)
}

introstat_report_object_digest <- function(path) introstat_report_file_digest(path)

introstat_report_spec_digest <- function(spec) {
  provided <- introstat_first_nonempty(spec$content_digest, spec$content_hash, spec$digest)
  if (!is.null(provided)) return(as.character(provided))
  if (!is.null(spec$source_digest) && !is.null(spec$object_digest)) {
    return(introstat_report_hash_value(list(
      source = as.character(spec$source_digest),
      object = as.character(spec$object_digest),
      artifact_type = spec$artifact_type %||% "",
      title = spec$title %||% "",
      visible_title = spec$visible_title %||% "",
      width = spec$width %||% spec$dimensions$width,
      height = spec$height %||% spec$dimensions$height,
      dimensions = spec$dimensions %||% list(),
      render_metadata = spec$render_metadata %||% list()
    )))
  }
  pieces <- list(
    source = if (!is.null(spec$source) && file.exists(spec$source)) introstat_report_file_digest(spec$source) else NA_character_,
    object = if (!is.null(spec$object) && file.exists(spec$object)) introstat_report_object_digest(spec$object) else NA_character_,
    manifest = if (!is.null(spec$manifest) && file.exists(spec$manifest)) introstat_report_file_digest(spec$manifest) else NA_character_,
    artifact_type = spec$artifact_type %||% "",
    title = spec$title %||% spec$visible_title %||% "",
    visible_title = spec$visible_title %||% "",
    width = spec$width %||% spec$dimensions$width,
    height = spec$height %||% spec$dimensions$height,
    dimensions = spec$dimensions %||% list(),
    render_metadata = spec$render_metadata %||% list()
  )
  introstat_report_hash_value(pieces)
}

introstat_report_spec_paths <- function(spec, root) {
  root <- normalizePath(root, mustWork = TRUE)
  path_value <- function(value, fallback = NULL) {
    if (is.null(value) || !length(value) || is.na(value) || !nzchar(as.character(value))) return(fallback)
    value <- as.character(value)
    path <- if (grepl("^(/|[A-Za-z]:[\\\\/])", value)) value else file.path(root, value)
    normalizePath(path, mustWork = FALSE)
  }
  manifest <- path_value(spec$manifest_path, if (is.character(spec$manifest)) spec$manifest else NULL)
  source <- path_value(spec$source_path, spec$source)
  object <- path_value(spec$object_path, spec$object)
  if (is.null(manifest) || is.null(source) || is.null(object)) {
    stop("Saved analysis is missing manifest, source, or object paths.", call. = FALSE)
  }
  for (path in c(manifest, source, object)) {
    if (!file.exists(path)) stop("Saved analysis input does not exist: ", path, call. = FALSE)
    if (!introstat_report_path_inside(path, root)) stop("Saved analysis input escapes the assignment root: ", path, call. = FALSE)
  }
  list(manifest = manifest, source = source, object = object)
}

introstat_report_scaffold <- function(root) {
  path <- file.path(root, "report_outline.yaml")
  if (!file.exists(path)) return(list(title = "Statistical analysis report", sections = list()))
  value <- introstat_report_read_yaml(path, "report outline")
  sections <- value$sections %||% list()
  if (!length(sections)) return(list(title = as.character(value$title %||% "Statistical analysis report"), sections = list()))
  out <- lapply(sections, function(section) {
    title <- introstat_first_nonempty(section$title, section$id)
    id <- introstat_first_nonempty(section$id, introstat_slug(title))
    if (is.null(title) || is.null(id)) stop("Report outline sections require an id or title.", call. = FALSE)
    list(
      id = id,
      title = title,
      include_if_empty = if (is.null(section$include_if_empty)) FALSE else isTRUE(section$include_if_empty),
      explicit = unique(c(introstat_character_values(section$problem), introstat_character_values(section$problems), introstat_character_values(section$section_hint))),
      default = FALSE
    )
  })
  ids <- vapply(out, function(x) x$id, character(1))
  if (anyDuplicated(ids)) stop("Report outline section IDs must be unique.", call. = FALSE)
  list(title = as.character(value$title %||% "Statistical analysis report"), sections = out)
}

introstat_report_initial_section <- function(spec, scaffold) {
  hint <- tolower(trimws(as.character(spec$section_hint %||% "")))
  problem <- tolower(trimws(as.character(spec$problem %||% "")))
  if (nzchar(hint)) {
    matches <- vapply(scaffold$sections, function(x) tolower(x$id) == hint || tolower(x$title) == hint, logical(1))
    if (any(matches)) return(scaffold$sections[[which(matches)[[1]]]]$id)
  }
  if (nzchar(problem)) {
    matches <- vapply(scaffold$sections, function(x) any(tolower(x$explicit) == problem), logical(1))
    if (any(matches)) return(scaffold$sections[[which(matches)[[1]]]]$id)
  }
  NULL
}

introstat_report_item <- function(spec, section_id = "report-outputs") {
  list(
    key = spec$key,
    display_id = spec$display_id,
    title = spec$title,
    visible_title = spec$visible_title,
    artifact_type = spec$artifact_type,
    section_id = section_id,
    width = spec$width %||% spec$dimensions$width,
    height = spec$height %||% spec$dimensions$height,
    # Keep the full declared dimensions mapping in the definition digest.  A
    # change to a render-affecting dimension must require outline approval even
    # when width/height happen to be absent or are supplied under a new key.
    dimensions = spec$dimensions %||% list(),
    render_metadata = spec$render_metadata %||% list()
  )
}

introstat_report_sync_new_outputs <- function(root, draft, specs) {
  changed <- FALSE
  # Refresh metadata that affects rendering for already-selected outputs while
  # preserving their selection, section, and order.  Content digests are
  # intentionally not part of the definition: an object-only revision can be
  # updated in place without a new structural approval. Newly cataloged
  # outputs remain available through explicit `include` only.
  by_id <- if (length(specs)) stats::setNames(specs, tolower(vapply(specs, function(x) as.character(x$display_id), character(1)))) else list()
  for (section_index in seq_along(draft$sections)) {
    items <- draft$sections[[section_index]]$items %||% list()
    for (item_index in seq_along(items)) {
      item <- items[[item_index]]
      spec <- by_id[[tolower(as.character(item$display_id))]]
      if (is.null(spec)) next
      refreshed <- introstat_report_item(spec, item$section_id)
      if (!identical(item, refreshed)) {
        draft$sections[[section_index]]$items[[item_index]] <- refreshed
        changed <- TRUE
      }
    }
  }
  if (changed) draft$definition_revision <- as.integer(draft$definition_revision %||% 0L) + 1L
  draft
}

introstat_report_new_draft <- function(root, report_id, title = NULL, specs = introstat_report_discover_saved(root)) {
  scaffold <- introstat_report_scaffold(root)
  selected <- lapply(specs, function(spec) introstat_report_item(spec, introstat_report_initial_section(spec, scaffold) %||% "report-outputs"))
  assigned <- if (length(selected)) vapply(selected, function(x) x$section_id, character(1)) else character()
  sections <- list()
  for (section in scaffold$sections) {
    if (section$id %in% assigned) {
      sections[[length(sections) + 1L]] <- list(
        id = section$id,
        title = section$title,
        include_if_empty = isTRUE(section$include_if_empty),
        items = selected[assigned == section$id]
      )
    }
  }
  if (!length(specs)) {
    sections <- lapply(Filter(function(section) isTRUE(section$include_if_empty), scaffold$sections), function(section) {
      list(id = section$id, title = section$title, include_if_empty = TRUE, items = list())
    })
  }
  if (any(!assigned %in% vapply(sections, function(x) x$id, character(1)))) {
    sections[[length(sections) + 1L]] <- list(id = "report-outputs", title = "Report outputs", include_if_empty = FALSE, items = selected[assigned == "report-outputs"])
  }
  if (!length(sections) && length(specs)) sections <- list(list(id = "report-outputs", title = "Report outputs", include_if_empty = FALSE, items = selected))
  list(
    schema = introstat_report_schema,
    report_id = introstat_report_id(report_id),
    title = as.character(title %||% scaffold$title),
    definition_revision = 1L,
    sections = sections,
    omitted = list()
  )
}

introstat_report_draft_items <- function(draft) {
  if (!length(draft$sections)) return(list())
  unlist(lapply(draft$sections, function(section) section$items %||% list()), recursive = FALSE)
}

introstat_report_draft_digest <- function(draft) {
  value <- list(
    schema = draft$schema %||% introstat_report_schema,
    report_id = draft$report_id,
    title = draft$title,
    sections = draft$sections %||% list(),
    omitted = draft$omitted %||% list()
  )
  introstat_report_hash_value(value)
}

introstat_report_validate_draft <- function(draft, specs = list()) {
  if (!identical(as.character(draft$schema %||% ""), introstat_report_schema)) stop("Unsupported report draft schema.", call. = FALSE)
  if (!length(draft$sections) && length(introstat_report_draft_items(draft))) stop("Report draft has items but no sections.", call. = FALSE)
  section_ids <- vapply(draft$sections %||% list(), function(x) as.character(x$id %||% ""), character(1))
  if (any(!nzchar(section_ids)) || anyDuplicated(section_ids)) stop("Report draft section IDs must be unique and non-empty.", call. = FALSE)
  items <- introstat_report_draft_items(draft)
  ids <- vapply(items, function(x) as.character(x$display_id %||% x$key %||% ""), character(1))
  if (any(!nzchar(ids)) || anyDuplicated(ids)) stop("Report draft output IDs must be unique and non-empty.", call. = FALSE)
  omitted <- draft$omitted %||% list()
  omitted_ids <- vapply(omitted, function(x) as.character(x$display_id %||% x$key %||% ""), character(1))
  if (anyDuplicated(c(ids, omitted_ids))) stop("Report draft cannot select and omit the same output.", call. = FALSE)
  if (length(items)) {
    unknown_sections <- setdiff(vapply(items, function(x) x$section_id, character(1)), section_ids)
    if (length(unknown_sections)) stop("Report draft refers to unknown sections: ", paste(unknown_sections, collapse = ", "), call. = FALSE)
  }
  invisible(TRUE)
}

introstat_report_read_state <- function(root, report_id) {
  paths <- introstat_report_paths(root, report_id)
  if (!file.exists(paths$report)) stop("Report does not exist: ", report_id, call. = FALSE)
  report <- introstat_report_read_yaml(paths$report, "report metadata")
  if (!identical(as.character(report$schema %||% ""), introstat_report_schema) || !identical(as.character(report$report_id %||% ""), introstat_report_id(report_id))) stop("Report metadata does not match its container.", call. = FALSE)
  introstat_report_validate_draft(report)
  list(paths = paths, report = report, draft = report)
}

introstat_report_write_state <- function(paths, report, draft) {
  introstat_report_validate_draft(draft)
  report$schema <- introstat_report_schema
  report$report_id <- draft$report_id
  report$title <- draft$title
  report$sections <- draft$sections %||% list()
  report$omitted <- draft$omitted %||% list()
  report$definition_revision <- as.integer(draft$definition_revision)
  introstat_report_atomic_write_yaml(report, paths$report)
  invisible(list(report = report, draft = draft))
}

introstat_report_print_outline <- function(draft) {
  cat(draft$title, "\n")
  if (!length(draft$sections)) {
    cat("\nNo saved outputs yet.\n")
    return(invisible(draft))
  }
  for (section in draft$sections) {
    cat("\n", section$title, "\n", sep = "")
    items <- section$items %||% list()
    if (!length(items)) next
    for (item in items) cat("  - ", item$display_id, ": ", item$title, " [", if (item$artifact_type == "plot") "Figure" else "Table", "]\n", sep = "")
  }
  if (length(draft$omitted %||% list())) {
    cat("\nOmitted outputs\n")
    for (item in draft$omitted) cat("  - ", item$display_id, ": ", item$title, "\n", sep = "")
  }
  cat("\nDescribe changes or approve this outline to compile the report.\n")
  invisible(draft)
}

introstat_report_find_item <- function(draft, query, include_omitted = FALSE) {
  query <- tolower(trimws(as.character(query)))
  pool <- c(introstat_report_draft_items(draft), if (include_omitted) draft$omitted %||% list() else list())
  if (!length(pool)) stop("No saved outputs are available.", call. = FALSE)
  hits <- which(vapply(pool, function(x) tolower(as.character(x$display_id %||% x$key)) == query || tolower(as.character(x$title)) == query, logical(1)))
  if (length(hits) != 1L) stop("Expected one saved output matching ", query, ".", call. = FALSE)
  list(index = hits[[1]], item = pool[[hits[[1]]]], pool = pool)
}

introstat_report_find_section <- function(draft, query) {
  query <- tolower(trimws(as.character(query)))
  hits <- which(vapply(draft$sections, function(x) tolower(as.character(x$id)) == query || tolower(as.character(x$title)) == query, logical(1)))
  if (length(hits) != 1L) return(integer())
  hits[[1]]
}

introstat_report_custom_section <- function(draft, title) {
  base <- introstat_slug(title)
  ids <- vapply(draft$sections, function(x) x$id, character(1))
  id <- base
  suffix <- 2L
  while (id %in% ids) { id <- paste0(base, "-", suffix); suffix <- suffix + 1L }
  draft$sections[[length(draft$sections) + 1L]] <- list(id = id, title = as.character(title), include_if_empty = FALSE, items = list())
  list(draft = draft, index = length(draft$sections), id = id)
}

introstat_report_mutate_unlocked <- function(root, report_id, mutation) {
  state <- introstat_report_read_state(root, report_id)
  introstat_report_migrate_legacy(root)
  specs <- introstat_report_discover_saved(root)
  draft <- mutation(introstat_report_sync_new_outputs(root, state$draft, specs), specs)
  draft$sections <- Filter(function(section) length(section$items %||% list()) > 0L || isTRUE(section$include_if_empty), draft$sections %||% list())
  draft$definition_revision <- as.integer(state$draft$definition_revision %||% 0L) + 1L
  introstat_report_validate_draft(draft)
  introstat_report_write_state(state$paths, state$report, draft)
  introstat_report_print_outline(draft)
  invisible(draft)
}

introstat_report_mutate <- function(root, report_id, mutation) {
  introstat_report_with_lock(root, report_id, function() introstat_report_mutate_unlocked(root, report_id, mutation))
}

introstat_report_propose_unlocked <- function(root = getwd(), report_id = NULL, title = NULL) {
  root <- normalizePath(root, mustWork = TRUE)
  introstat_report_migrate_legacy(root)
  if (is.null(report_id)) {
    existing <- list.dirs(file.path(root, "reports"), full.names = FALSE, recursive = FALSE)
    numbers <- suppressWarnings(as.integer(sub("^report-", "", existing[grepl("^report-[0-9]+$", existing)])))
    report_id <- paste0("report-", if (length(numbers)) max(numbers) + 1L else 1L)
  }
  report_id <- introstat_report_id(report_id)
  paths <- introstat_report_paths(root, report_id)
  if (file.exists(paths$report)) {
    state <- introstat_report_read_state(root, report_id)
    draft <- introstat_report_sync_new_outputs(root, state$draft, introstat_report_discover_saved(root))
    if (!identical(introstat_report_draft_digest(draft), introstat_report_draft_digest(state$draft))) {
      introstat_report_write_state(paths, state$report, draft)
    }
    introstat_report_print_outline(draft)
    return(invisible(draft))
  }
  dir.create(paths$directory, recursive = TRUE, showWarnings = FALSE)
  dir.create(paths$snapshots, recursive = TRUE, showWarnings = FALSE)
  draft <- introstat_report_new_draft(root, report_id, title)
  report <- list(schema = introstat_report_schema, report_id = report_id, title = draft$title, definition_revision = 1L, latest_snapshot = NULL, latest_snapshot_path = NULL)
  introstat_report_write_state(paths, report, draft)
  introstat_report_print_outline(draft)
  invisible(draft)
}

introstat_report_propose <- function(root = getwd(), report_id = NULL, title = NULL) {
  introstat_report_with_lock(root, report_id %||% "__reports__", function() introstat_report_propose_unlocked(root, report_id, title))
}

introstat_report_show <- function(root = getwd(), report_id = "report-1") {
  introstat_report_with_lock(root, report_id, function() {
    state <- introstat_report_read_state(root, report_id)
    introstat_report_print_outline(state$draft)
    invisible(state$draft)
  })
}

introstat_report_omit <- function(root, report_id, query) {
  introstat_report_mutate(root, report_id, function(draft, specs) {
    found <- introstat_report_find_item(draft, query)
    item <- found$item
    for (i in seq_along(draft$sections)) draft$sections[[i]]$items <- Filter(function(x) !identical(x$display_id, item$display_id), draft$sections[[i]]$items %||% list())
    draft$omitted <- c(draft$omitted %||% list(), list(item))
    draft
  })
}

introstat_report_include <- function(root, report_id, query) {
  introstat_report_mutate(root, report_id, function(draft, specs) {
    normalized <- tolower(trimws(as.character(query)))
    spec_hits <- which(vapply(specs, function(x) normalized %in% tolower(c(x$key, x$display_id, x$title, x$visible_title)), logical(1)))
    if (length(spec_hits) != 1L) stop("The saved output is unavailable and cannot be included.", call. = FALSE)
    spec <- specs[[spec_hits[[1]]]]
    selected <- introstat_report_draft_items(draft)
    if (any(vapply(selected, function(x) normalized %in% tolower(c(x$key, x$display_id, x$title, x$visible_title)), logical(1)))) {
      stop("That output is already included.", call. = FALSE)
    }
    omitted <- draft$omitted %||% list()
    omitted_hit <- which(vapply(omitted, function(x) identical(as.character(x$key %||% ""), as.character(spec$key)) || identical(as.character(x$display_id %||% ""), as.character(spec$display_id)), logical(1)))
    scaffold <- introstat_report_scaffold(root)
    section_id <- if (length(omitted_hit)) omitted[[omitted_hit[[1]]]]$section_id else introstat_report_initial_section(spec, scaffold) %||% "report-outputs"
    section_index <- introstat_report_find_section(draft, section_id)
    if (!length(section_index)) {
      neutral <- Filter(function(section) identical(section$id, "report-outputs"), scaffold$sections)
      if (identical(section_id, "report-outputs") && length(neutral)) {
        draft$sections[[length(draft$sections) + 1L]] <- list(
          id = "report-outputs",
          title = neutral[[1]]$title,
          include_if_empty = isTRUE(neutral[[1]]$include_if_empty),
          items = list()
        )
        created <- list(draft = draft, index = length(draft$sections))
      } else {
        created <- introstat_report_custom_section(draft, "Report outputs")
      }
      draft <- created$draft
      section_index <- created$index
    }
    draft$sections[[section_index]]$items <- c(draft$sections[[section_index]]$items %||% list(), list(introstat_report_item(spec, draft$sections[[section_index]]$id)))
    draft$omitted <- Filter(function(x) !identical(as.character(x$key %||% ""), as.character(spec$key)) && !identical(as.character(x$display_id %||% ""), as.character(spec$display_id)), omitted)
    draft
  })
}

introstat_report_move <- function(root, report_id, query, section) {
  introstat_report_mutate(root, report_id, function(draft, specs) {
    found <- introstat_report_find_item(draft, query)
    item <- found$item
    for (i in seq_along(draft$sections)) draft$sections[[i]]$items <- Filter(function(x) !identical(x$display_id, item$display_id), draft$sections[[i]]$items %||% list())
    section_index <- introstat_report_find_section(draft, section)
    if (!length(section_index)) { created <- introstat_report_custom_section(draft, section); draft <- created$draft; section_index <- created$index }
    item$section_id <- draft$sections[[section_index]]$id
    draft$sections[[section_index]]$items <- c(draft$sections[[section_index]]$items %||% list(), list(item))
    draft
  })
}

introstat_report_move_relative <- function(root, report_id, query, target, direction) {
  introstat_report_mutate(root, report_id, function(draft, specs) {
    if (tolower(trimws(as.character(query))) == tolower(trimws(as.character(target)))) stop("An output cannot be moved relative to itself.", call. = FALSE)
    found <- introstat_report_find_item(draft, query)
    target_found <- introstat_report_find_item(draft, target)
    item <- found$item
    for (i in seq_along(draft$sections)) draft$sections[[i]]$items <- Filter(function(x) !identical(x$display_id, item$display_id), draft$sections[[i]]$items %||% list())
    target_index <- 0L
    section_index <- 0L
    for (i in seq_along(draft$sections)) {
      hits <- which(vapply(draft$sections[[i]]$items %||% list(), function(x) identical(x$display_id, target_found$item$display_id), logical(1)))
      if (length(hits)) { section_index <- i; target_index <- hits[[1]]; break }
    }
    if (!section_index) stop("Could not locate the target output.", call. = FALSE)
    items <- draft$sections[[section_index]]$items %||% list()
    insert_at <- if (direction == "before") target_index else target_index + 1L
    item$section_id <- draft$sections[[section_index]]$id
    if (insert_at > length(items)) items <- c(items, list(item)) else items <- append(items, list(item), after = insert_at - 1L)
    draft$sections[[section_index]]$items <- items
    draft
  })
}

introstat_report_rename_section <- function(root, report_id, query, title) {
  introstat_report_mutate(root, report_id, function(draft, specs) {
    index <- introstat_report_find_section(draft, query)
    if (!length(index)) stop("No report section matches: ", query, call. = FALSE)
    draft$sections[[index]]$title <- as.character(title)
    draft
  })
}

introstat_report_move_section <- function(root, report_id, query, target, direction) {
  introstat_report_mutate(root, report_id, function(draft, specs) {
    index <- introstat_report_find_section(draft, query)
    target_index <- introstat_report_find_section(draft, target)
    if (!length(index) || !length(target_index) || identical(index, target_index)) stop("Report sections must name two different sections.", call. = FALSE)
    section <- draft$sections[[index]]
    draft$sections <- draft$sections[-index]
    target_index <- introstat_report_find_section(draft, target)
    insert_at <- if (direction == "before") target_index else target_index + 1L
    draft$sections <- if (insert_at > length(draft$sections)) c(draft$sections, list(section)) else append(draft$sections, list(section), after = insert_at - 1L)
    draft
  })
}

introstat_report_copy_checked <- function(source, destination, root) {
  source <- normalizePath(source, mustWork = TRUE)
  if (!introstat_report_path_inside(source, root)) stop("Report input escapes the assignment root: ", source, call. = FALSE)
  dir.create(dirname(destination), recursive = TRUE, showWarnings = FALSE)
  if (!file.copy(source, destination, overwrite = FALSE, copy.date = TRUE)) stop("Could not copy report input: ", source, call. = FALSE)
  invisible(destination)
}

introstat_report_copy_runtime <- function(root, stage) {
  runtime <- file.path(root, "R")
  if (!dir.exists(runtime)) stop("Assignment runtime R/ directory is missing.", call. = FALSE)
  files <- list.files(runtime, recursive = TRUE, full.names = TRUE, all.files = TRUE)
  files <- files[file.info(files)$isdir %in% FALSE]
  for (source in files) {
    relative <- substring(normalizePath(source, mustWork = TRUE), nchar(normalizePath(runtime, mustWork = TRUE)) + 2L)
    introstat_report_copy_checked(source, file.path(stage, "R", relative), root)
  }
  for (name in c("AGENTS.md", "assignment.qmd", "ASSIGNMENT.pdf", "report_outline.yaml", "HARNESS_VERSION.txt", "required_data_files.txt")) {
    source <- file.path(root, name)
    if (file.exists(source)) introstat_report_copy_checked(source, file.path(stage, name), root)
  }
  for (name in c("setup_harness.R", "check_setup.R")) {
    source <- file.path(root, "scripts", name)
    if (file.exists(source)) introstat_report_copy_checked(source, file.path(stage, "scripts", name), root)
  }
  package_file <- file.path(root, "required_packages.txt")
  if (!file.exists(package_file)) package_file <- file.path(root, ".codex", "required_packages.txt")
  if (file.exists(package_file)) {
    introstat_report_copy_checked(package_file, file.path(stage, "required_packages.txt"), root)
    introstat_report_copy_checked(package_file, file.path(stage, "runtime", "required_packages.txt"), root)
  }
  invisible(TRUE)
}

introstat_report_copy_assignment_data <- function(root, stage) {
  manifest <- file.path(root, "required_data_files.txt")
  if (!file.exists(manifest)) stop("This assignment is missing required_data_files.txt; rebuild it with the current assignment packager before compiling a report.", call. = FALSE)
  relative_paths <- trimws(readLines(manifest, warn = FALSE))
  relative_paths <- unique(relative_paths[nzchar(relative_paths) & !startsWith(relative_paths, "#")])
  copied <- lapply(relative_paths, function(relative) {
    normalized <- gsub("\\\\", "/", relative)
    components <- strsplit(normalized, "/", fixed = TRUE)[[1]]
    if (grepl("^(?:/|[A-Za-z]:/|~)", normalized) || any(components %in% c("", ".", ".."))) {
      stop("required_data_files.txt contains an unsafe path: ", relative, call. = FALSE)
    }
    source <- file.path(root, normalized)
    if (!file.exists(source) || dir.exists(source)) stop("Required assignment data file is missing: ", relative, call. = FALSE)
    destination <- file.path(stage, normalized)
    introstat_report_copy_checked(source, destination, root)
    source_digest <- introstat_report_file_digest(source)
    staged_digest <- introstat_report_file_digest(destination)
    if (!identical(source_digest, staged_digest)) stop("Assignment data changed while staging: ", relative, call. = FALSE)
    list(path = normalized, sha256 = staged_digest)
  })
  copied
}

introstat_report_snapshot_number <- function(paths) {
  if (!dir.exists(paths$snapshots)) return(1L)
  names <- list.files(paths$snapshots, pattern = "^[0-9]{4}$", full.names = FALSE)
  numbers <- suppressWarnings(as.integer(names))
  if (length(numbers)) max(numbers) + 1L else 1L
}

introstat_report_light_catalog <- function(root) {
  paths <- list.files(file.path(root, "analysis"), pattern = "^manifest\\.ya?ml$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  if (!length(paths)) return(list())
  output <- list()
  for (manifest_path in paths) {
    manifest <- tryCatch(introstat_read_report_manifest(manifest_path), error = function(e) NULL)
    if (is.null(manifest)) next
    directory <- dirname(manifest_path)
    source <- file.path(directory, as.character(manifest$source %||% "analysis.R"))
    object <- file.path(directory, as.character(manifest$object %||% "object.rds"))
    if (!file.exists(source) || !file.exists(object)) next
    type <- as.character(manifest$artifact_type %||% "")
    id <- toupper(as.character(manifest$display_id %||% ""))
    title <- as.character(manifest$title %||% basename(directory))
    dimensions <- manifest$dimensions
    if (is.null(dimensions) && (!is.null(manifest$width) || !is.null(manifest$height))) dimensions <- list(width = manifest$width, height = manifest$height)
    digests <- manifest$content_digests %||% manifest$digests %||% list()
    source_digest <- as.character(digests$analysis_r %||% digests$source %||% "")
    object_digest <- as.character(digests$object_rds %||% digests$object %||% "")
    spec <- list(
      key = as.character(manifest$key %||% manifest$slug %||% basename(directory)),
      display_id = id,
      title = title,
      visible_title = if (nzchar(id)) paste0(id, ": ", title) else title,
      artifact_type = type,
      manifest = normalizePath(manifest_path, mustWork = TRUE),
      source = normalizePath(source, mustWork = TRUE),
      object = normalizePath(object, mustWork = TRUE),
      source_digest = source_digest,
      object_digest = object_digest,
      dimensions = dimensions,
      width = if (is.list(dimensions)) dimensions$width else NULL,
      height = if (is.list(dimensions)) dimensions$height else NULL,
      render_metadata = manifest$render_metadata %||% list()
    )
    actual_source <- tryCatch(introstat_report_file_digest(spec$source), error = function(e) NA_character_)
    actual_object <- tryCatch(introstat_report_file_digest(spec$object), error = function(e) NA_character_)
    spec$content_valid <- identical(tolower(source_digest), tolower(actual_source)) && identical(tolower(object_digest), tolower(actual_object))
    spec$content_digest <- if (isTRUE(spec$content_valid)) tryCatch(introstat_report_spec_digest(spec), error = function(e) NA_character_) else NA_character_
    output[[length(output) + 1L]] <- spec
  }
  output
}

introstat_report_load_object <- function(path, artifact_type) {
  if (!file.exists(path)) stop("Missing staged report object: ", path, call. = FALSE)
  object <- readRDS(path)
  valid <- if (identical(artifact_type, "plot")) inherits(object, "ggplot") else inherits(object, "flextable")
  if (!valid) stop("Staged report object does not match artifact type ", artifact_type, ".", call. = FALSE)
  object
}

introstat_report_stage_input <- function(spec, stage, root) {
  paths <- introstat_report_spec_paths(spec, root)
  display <- gsub("[^A-Za-z0-9_.-]+", "-", as.character(spec$display_id))
  input <- file.path(stage, "inputs", display)
  dir.create(input, recursive = TRUE, showWarnings = FALSE)
  introstat_report_copy_checked(paths$manifest, file.path(input, "manifest.yaml"), root)
  introstat_report_copy_checked(paths$source, file.path(input, "analysis.R"), root)
  introstat_report_copy_checked(paths$object, file.path(input, "object.rds"), root)
  copied_digests <- c(
    manifest = introstat_report_file_digest(file.path(input, "manifest.yaml")),
    source = introstat_report_file_digest(file.path(input, "analysis.R")),
    object = introstat_report_file_digest(file.path(input, "object.rds"))
  )
  expected_source <- as.character(spec$source_digest %||% spec$digests$analysis_r %||% "")
  expected_object <- as.character(spec$object_digest %||% spec$digests$object_rds %||% "")
  if (!grepl("^[a-fA-F0-9]{64}$", expected_source)) expected_source <- introstat_report_file_digest(paths$source)
  if (!grepl("^[a-fA-F0-9]{64}$", expected_object)) expected_object <- introstat_report_file_digest(paths$object)
  expected_source <- tolower(expected_source)
  expected_object <- tolower(expected_object)
  if (!identical(copied_digests[["source"]], expected_source) || !identical(copied_digests[["object"]], expected_object)) stop("Saved analysis content changed while staging ", spec$display_id, ".", call. = FALSE)
  copied_manifest <- introstat_read_report_manifest(file.path(input, "manifest.yaml"))
  copied_manifest_digests <- copied_manifest$content_digests %||% list()
  if (!identical(tolower(as.character(copied_manifest_digests$analysis_r %||% "")), expected_source) ||
      !identical(tolower(as.character(copied_manifest_digests$object_rds %||% "")), expected_object) ||
      !identical(as.character(copied_manifest$key %||% ""), as.character(spec$key)) ||
      !identical(toupper(as.character(copied_manifest$display_id %||% "")), toupper(as.character(spec$display_id))) ||
      !identical(as.character(copied_manifest$artifact_type %||% ""), as.character(spec$artifact_type))) {
    stop("Saved analysis manifest changed while staging ", spec$display_id, ".", call. = FALSE)
  }
  current_digest <- introstat_report_spec_digest(spec)
  list(
    key = spec$key,
    display_id = spec$display_id,
    title = spec$title,
    visible_title = spec$visible_title,
    artifact_type = spec$artifact_type,
    section_id = spec$section_id,
    width = spec$width %||% spec$dimensions$width,
    height = spec$height %||% spec$dimensions$height,
    dimensions = spec$dimensions %||% list(),
    render_metadata = spec$render_metadata %||% list(),
    content_digest = current_digest,
    source_digest = expected_source,
    object_digest = expected_object,
    manifest_digest = copied_digests[["manifest"]],
    manifest = file.path("inputs", display, "manifest.yaml"),
    source = file.path("inputs", display, "analysis.R"),
    object = file.path("inputs", display, "object.rds")
  )
}

introstat_report_snapshot_plan <- function(draft, specs) {
  selected <- introstat_report_draft_items(draft)
  if (!length(selected)) stop("A report needs at least one included saved output.", call. = FALSE)
  by_id <- stats::setNames(specs, vapply(specs, function(x) tolower(x$display_id), character(1)))
  plan_items <- lapply(selected, function(item) {
    spec <- by_id[[tolower(item$display_id)]]
    if (is.null(spec)) stop("Included output is no longer available: ", item$display_id, call. = FALSE)
    spec$section_id <- item$section_id
    spec$title <- spec$title %||% item$title
    spec
  })
  list(items = plan_items, sections = draft$sections)
}

introstat_report_snapshot_manifest <- function(snapshot_id, report_id, draft, staged_items, data_files, root) {
  list(
    schema = "introstat-report-snapshot-1",
    report_id = report_id,
    snapshot_id = snapshot_id,
    title = draft$title,
    definition_revision = as.integer(draft$definition_revision),
    definition_digest = introstat_report_draft_digest(draft),
    created_at = format(Sys.time(), tz = "UTC", usetz = TRUE),
    reproducibility = "Reproducible within the recorded compatible R and package environment; the snapshot does not bundle R or platform-specific libraries.",
    inputs = staged_items,
    assignment_data = data_files,
    environment = list(r_version = R.version.string, platform = R.version$platform, required_packages = "runtime/required_packages.txt", package_versions = "runtime/package-versions.tsv", session_info = "runtime/session-info.txt")
  )
}

introstat_report_write_snapshot_scripts <- function(stage, snapshot_manifest) {
  items <- snapshot_manifest$inputs
  sections <- lapply(snapshot_manifest$sections %||% list(), function(section) {
    list(id = section$id, title = section$title, include_if_empty = isTRUE(section$include_if_empty))
  })
  # Scripts are deliberately small: rebuild reads frozen objects, while verify
  # is the separate operation that executes copied analysis sources.
  item_text <- paste(capture.output(dput(items)), collapse = "\n")
  section_text <- paste(capture.output(dput(sections)), collapse = "\n")
  title_text <- paste(capture.output(dput(snapshot_manifest$title)), collapse = "\n")
  rebuild <- c(
    "#!/usr/bin/env Rscript",
    "args <- commandArgs(trailingOnly = TRUE)",
    "snapshot_root <- normalizePath(if (length(args)) args[[1]] else getwd(), mustWork = TRUE)",
    "output_path <- if (length(args) >= 2L) normalizePath(args[[2]], mustWork = FALSE) else file.path(dirname(snapshot_root), paste0(basename(snapshot_root), '-rebuild.docx'))",
    "dir.create(dirname(output_path), recursive = TRUE, showWarnings = FALSE)",
    "if (length(args) >= 2L && (identical(output_path, snapshot_root) || startsWith(output_path, paste0(snapshot_root, .Platform$file.sep)))) stop('Rebuild destination must be outside the immutable snapshot.')",
    "setwd(snapshot_root)",
    "source(file.path('R', 'harness_io.R'))",
    "source(file.path('R', 'report_runtime.R'))",
    paste0("snapshot_items <- ", item_text),
    paste0("snapshot_sections <- ", section_text),
    "frozen <- lapply(snapshot_items, function(item) {",
    "  if (!identical(introstat_sha256_file(file.path(snapshot_root, item$object)), item$object_digest)) stop('Frozen object digest mismatch: ', item$display_id)",
    "  object <- readRDS(file.path(snapshot_root, item$object))",
    "  introstat_report_value(object, item)",
    "})",
    paste0("snapshot_title <- ", title_text),
    "introstat_write_compiled_report(frozen, output = output_path, title = snapshot_title, sections = snapshot_sections)",
    "cat('Rebuilt ', output_path, '\\n', sep = '')"
  )
  verify <- c(
    "#!/usr/bin/env Rscript",
    "args <- commandArgs(trailingOnly = TRUE)",
    "snapshot_root <- normalizePath(if (length(args)) args[[1]] else getwd(), mustWork = TRUE)",
    "setwd(snapshot_root)",
    "source(file.path('R', 'harness_io.R'))",
    "source(file.path('R', 'report_runtime.R'))",
    paste0("snapshot_items <- ", item_text),
    "introstat_report_verify_snapshot(snapshot_root, snapshot_items)",
    "cat('Verified copied analysis sources and artifact types.\\n')"
  )
  introstat_report_atomic_write_lines(rebuild, file.path(stage, "rebuild.R"))
  introstat_report_atomic_write_lines(verify, file.path(stage, "verify.R"))
}

introstat_report_validate_docx <- function(path) {
  if (!file.exists(path) || file.info(path)$size <= 0) stop("Report Word output is missing or empty.", call. = FALSE)
  entries <- tryCatch(utils::unzip(path, list = TRUE)$Name, error = function(e) character())
  if (!all(c("[Content_Types].xml", "word/document.xml") %in% entries)) stop("Report Word output is not a valid DOCX package.", call. = FALSE)
  invisible(TRUE)
}

introstat_report_record_package_versions <- function(stage) {
  package_file <- file.path(stage, "runtime", "required_packages.txt")
  packages <- if (file.exists(package_file)) trimws(readLines(package_file, warn = FALSE)) else character()
  packages <- unique(packages[nzchar(packages) & !startsWith(packages, "#")])
  versions <- vapply(packages, function(package) {
    if (requireNamespace(package, quietly = TRUE)) as.character(utils::packageVersion(package)) else "NOT INSTALLED"
  }, character(1))
  lines <- c("package\tversion", if (length(packages)) paste(packages, versions, sep = "\t") else character())
  introstat_report_atomic_write_lines(lines, file.path(stage, "runtime", "package-versions.tsv"))
  invisible(versions)
}

introstat_report_update_pointer <- function(paths, report, snapshot_id, draft) {
  # `report.yaml` is the canonical definition as well as the latest-snapshot
  # pointer.  Persist the exact definition that was staged before exposing the
  # new immutable snapshot; otherwise a newly discovered output could be
  # compiled but disappear from the next `show`/`link` operation.
  report$title <- draft$title
  report$sections <- draft$sections %||% list()
  report$omitted <- draft$omitted %||% list()
  report$latest_snapshot <- snapshot_id
  report$latest_snapshot_path <- file.path("snapshots", snapshot_id)
  report$definition_revision <- as.integer(draft$definition_revision)
  introstat_report_atomic_write_yaml(report, paths$report)
  report
}

introstat_build_report_unlocked <- function(root = getwd(), report_id = "report-1", mode = c("build", "update"), approval = NULL) {
  mode <- match.arg(mode)
  state <- introstat_report_read_state(root, report_id)
  introstat_report_migrate_legacy(root)
  specs <- introstat_report_discover_saved(root)
  draft <- introstat_report_sync_new_outputs(root, state$draft, specs)
  latest <- state$report$latest_snapshot %||% NULL
  latest_dir <- if (!is.null(latest)) file.path(state$paths$snapshots, as.character(latest)) else NULL
  if (identical(mode, "update")) {
    if (is.null(latest) || !dir.exists(latest_dir)) stop("There is no compiled report version to update.", call. = FALSE)
    latest_manifest_path <- file.path(latest_dir, "snapshot.yaml")
    latest_manifest <- introstat_report_read_yaml(latest_manifest_path, "snapshot metadata")
    if (!identical(as.character(latest_manifest$definition_digest %||% ""), introstat_report_draft_digest(draft))) {
      if (!isTRUE(approval)) stop("The report outline changed; approve the current outline before updating.", call. = FALSE)
    }
  } else {
    if (!isTRUE(approval)) stop("Approve the current report outline before the first build.", call. = FALSE)
  }
  plan <- introstat_report_snapshot_plan(draft, specs)
  number <- introstat_report_snapshot_number(state$paths)
  snapshot_id <- sprintf("%04d", number)
  stage <- file.path(state$paths$snapshots, paste0(".", snapshot_id, "-stage-", Sys.getpid(), "-", as.integer(runif(1, 1, 1e8))))
  if (file.exists(stage)) stop("Snapshot staging path already exists.", call. = FALSE)
  dir.create(stage, recursive = TRUE, showWarnings = FALSE)
  committed <- FALSE
  on.exit(if (!committed && dir.exists(stage)) unlink(stage, recursive = TRUE), add = TRUE)
  staged_items <- lapply(plan$items, introstat_report_stage_input, stage = stage, root = root)
  data_files <- introstat_report_copy_assignment_data(root, stage)
  introstat_report_copy_runtime(root, stage)
  dir.create(file.path(stage, "runtime"), recursive = TRUE, showWarnings = FALSE)
  introstat_report_record_package_versions(stage)
  snapshot_manifest <- introstat_report_snapshot_manifest(snapshot_id, report_id, draft, staged_items, data_files, root)
  snapshot_manifest$sections <- plan$sections
  introstat_report_atomic_write_yaml(snapshot_manifest, file.path(stage, "snapshot.yaml"))
  introstat_report_atomic_write_yaml(list(report_id = report_id, snapshot_id = snapshot_id, definition_revision = draft$definition_revision, sections = plan$sections, items = staged_items), file.path(stage, "plan.yaml"))
  introstat_report_write_snapshot_scripts(stage, snapshot_manifest)
  frozen <- lapply(seq_along(staged_items), function(i) {
    item <- staged_items[[i]]
    object <- introstat_report_load_object(file.path(stage, item$object), item$artifact_type)
    introstat_report_value(object, item)
  })
  output <- file.path(stage, "report.docx")
  if (!exists("introstat_write_compiled_report", mode = "function")) stop("R/report_runtime.R must be sourced before building a report.", call. = FALSE)
  introstat_write_compiled_report(
    frozen,
    output = output,
    title = draft$title,
    subtitle = NULL,
    sections = lapply(plan$sections, function(x) list(
      id = x$id,
      title = x$title,
      include_if_empty = isTRUE(x$include_if_empty)
    ))
  )
  introstat_report_validate_docx(output)
  introstat_report_atomic_write_lines(capture.output(sessionInfo()), file.path(stage, "runtime", "session-info.txt"))
  final <- file.path(state$paths$snapshots, snapshot_id)
  if (dir.exists(final)) stop("Snapshot already exists and will not be overwritten: ", snapshot_id, call. = FALSE)
  if (!file.rename(stage, final)) stop("Could not install report snapshot: ", snapshot_id, call. = FALSE)
  committed <- TRUE
  old_report <- state$report
  pointer_error <- tryCatch({ introstat_report_update_pointer(state$paths, state$report, snapshot_id, draft); NULL }, error = identity)
  if (!is.null(pointer_error)) {
    unlink(final, recursive = TRUE)
    stop(pointer_error)
  }
  report_path <- normalizePath(file.path(final, "report.docx"), mustWork = TRUE)
  cat(
    "[Open the report — version ", as.integer(snapshot_id), "](<",
    report_path,
    ">)\n",
    sep = ""
  )
  invisible(list(report_id = report_id, snapshot_id = snapshot_id, path = file.path(final, "report.docx"), report = state$report))
}

introstat_build_report <- function(root = getwd(), report_id = "report-1", mode = c("build", "update"), approval = FALSE) {
  introstat_report_with_lock(root, report_id, function() introstat_build_report_unlocked(root, report_id, mode, approval))
}

introstat_report_link_unlocked <- function(root = getwd(), report_id = "report-1") {
  state <- introstat_report_read_state(root, report_id)
  latest <- state$report$latest_snapshot %||% NULL
  if (is.null(latest)) stop("The report has no compiled version yet.", call. = FALSE)
  latest <- introstat_snapshot_id(sprintf("%04d", as.integer(latest)))
  snapshot_dir <- file.path(state$paths$snapshots, latest)
  report_docx <- file.path(snapshot_dir, "report.docx")
  if (!file.exists(report_docx)) stop("The latest report version is missing its Word document.", call. = FALSE)
  manifest <- introstat_report_read_yaml(file.path(snapshot_dir, "snapshot.yaml"), "snapshot metadata")
  link <- paste0("[Open the report — version ", as.integer(latest), "](<", normalizePath(report_docx, mustWork = TRUE), ">)")
  cat(link, "\n")
  catalog_error <- NULL
  warnings <- character()
  specs <- tryCatch(introstat_report_discover_saved(root), error = function(error) {
    catalog_error <<- error
    NULL
  })
  if (is.null(specs)) specs <- introstat_report_light_catalog(root)
  by_key <- if (length(specs)) stats::setNames(specs, vapply(specs, function(x) x$key, character(1))) else list()
  for (item in manifest$inputs %||% list()) {
    spec <- by_key[[as.character(item$key)]]
    if (is.null(spec)) {
      warnings <- c(warnings, paste0(as.character(item$display_id), " is no longer among the saved outputs."))
    } else if (identical(spec$content_valid, FALSE)) {
      warnings <- c(warnings, paste0(as.character(item$display_id), " has changed or failed validation since version ", as.integer(latest), "."))
    } else if (!identical(as.character(item$content_digest), as.character(introstat_report_spec_digest(spec)))) {
      warnings <- c(warnings, paste0(as.character(item$display_id), " has changed since version ", as.integer(latest), "."))
    }
  }
  if (length(warnings)) {
    for (warning in warnings) cat(warning, " I can update the report with the revised output.\n", sep = "")
  } else if (!is.null(catalog_error) && !length(specs)) {
    cat("The latest report is linked, but current included-output freshness could not be checked.\n")
  }
  invisible(list(report_id = report_id, snapshot_id = latest, path = normalizePath(report_docx, mustWork = TRUE), stale = length(warnings) > 0L, warnings = warnings, link = link))
}

introstat_report_link <- function(root = getwd(), report_id = "report-1") {
  tryCatch(
    introstat_report_with_lock(root, report_id, function() introstat_report_link_unlocked(root, report_id), timeout = 2),
    error = function(error) {
      if (grepl("report operation is in progress", conditionMessage(error), fixed = TRUE)) return(introstat_report_link_unlocked(root, report_id))
      stop(error)
    }
  )
}

introstat_delete_report_snapshot_unlocked <- function(root, report_id, snapshot_id, confirm = FALSE) {
  if (!isTRUE(confirm)) stop("Deleting a report version requires explicit confirmation.", call. = FALSE)
  state <- introstat_report_read_state(root, report_id)
  snapshot_id <- introstat_snapshot_id(snapshot_id)
  target <- file.path(state$paths$snapshots, snapshot_id)
  if (!dir.exists(target)) stop("Report version does not exist: ", as.integer(snapshot_id), call. = FALSE)
  unlink(target, recursive = TRUE)
  if (dir.exists(target)) stop("Could not delete report version: ", as.integer(snapshot_id), call. = FALSE)
  remaining <- list.files(state$paths$snapshots, pattern = "^[0-9]{4}$", full.names = FALSE)
  remaining <- remaining[order(as.integer(remaining), decreasing = TRUE)]
  state$report$latest_snapshot <- if (length(remaining)) remaining[[1]] else NULL
  state$report$latest_snapshot_path <- if (length(remaining)) file.path("snapshots", remaining[[1]]) else NULL
  introstat_report_atomic_write_yaml(state$report, state$paths$report)
  invisible(state$report)
}

introstat_delete_report_snapshot <- function(root, report_id, snapshot_id, confirm = FALSE) {
  introstat_report_with_lock(root, report_id, function() introstat_delete_report_snapshot_unlocked(root, report_id, snapshot_id, confirm))
}

introstat_delete_report_unlocked <- function(root, report_id, confirm = FALSE) {
  if (!isTRUE(confirm)) stop("Deleting a report requires explicit confirmation.", call. = FALSE)
  paths <- introstat_report_paths(root, report_id)
  if (!dir.exists(paths$directory)) stop("Report does not exist: ", report_id, call. = FALSE)
  unlink(paths$directory, recursive = TRUE)
  if (dir.exists(paths$directory)) stop("Could not delete report: ", report_id, call. = FALSE)
  invisible(TRUE)
}

introstat_delete_report <- function(root, report_id, confirm = FALSE) {
  introstat_report_with_lock(root, report_id, function() introstat_delete_report_unlocked(root, report_id, confirm))
}
