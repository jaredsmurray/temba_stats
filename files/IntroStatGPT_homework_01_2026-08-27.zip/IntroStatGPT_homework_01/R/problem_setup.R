# TEMBA 2026 course data.
austin_houses <- readr::read_csv(
  "data/austin_houses/austin_houses.csv",
  show_col_types = FALSE
)

returns_prices <- readr::read_csv(
  "data/returns/returns_prices.csv",
  show_col_types = FALSE
)
returns_prices$date <- as.Date(returns_prices$date)
returns_prices <- returns_prices[order(returns_prices$date), , drop = FALSE]

# Arithmetic returns are measured in percentage points: 1 means a 1% return.
price_columns <- grep("_price$", names(returns_prices), value = TRUE)
return_columns <- sub("_price$", "", price_columns)
for (i in seq_along(price_columns)) {
  price <- returns_prices[[price_columns[[i]]]]
  returns_prices[[return_columns[[i]]]] <- 100 * (price / dplyr::lag(price) - 1)
}
returns <- returns_prices[c("date", return_columns)]

cps_earnings <- readr::read_csv(
  "data/mincer/cps_asec_2023.csv",
  show_col_types = FALSE
)

kroger <- readr::read_csv(
  "data/kroger_cheese/kroger.csv",
  show_col_types = FALSE
)

lending_club <- readr::read_csv(
  "data/lending_club/data/df_all.csv",
  show_col_types = FALSE
)

shed <- readr::read_csv(
  "data/shed/shed_2025.csv",
  show_col_types = FALSE
)

bloom_attrition <- readr::read_csv(
  "data/bloom_wfh/attrition.csv",
  show_col_types = FALSE
)

bloom_perceptions <- readr::read_csv(
  "data/bloom_wfh/perceptions.csv",
  show_col_types = FALSE
)
