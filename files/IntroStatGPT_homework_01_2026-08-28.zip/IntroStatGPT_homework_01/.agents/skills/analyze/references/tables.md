# Draft tables

Create only the descriptive, inferential, or other non-regression table the
student requested. Use `make_summary_table()` for its canonical grouped or
ungrouped mean-and-standard-deviation layout when that layout matches the
request. Build another validated `flextable` when the requested rows or
statistics require a different structure.

Use a concise descriptive title, plain-language headers, and clear group labels.
When a unit is established by the request, assignment context, or a supplied
variable description, include it in the relevant header or variable label and
format the displayed cells accordingly. Do not infer a unit from the values or
column name alone.

Use enough precision to show the requested result without distracting trailing
digits. Format counts as whole numbers and use grouping separators when they
materially improve readability. Apply familiar currency or percentage display
only when the unit and stored scale are known. Preserve the computed values;
formatting, labels, emphasis, and column layout must not change the statistic,
population, filter, or underlying data.

When a descriptive table has nine or more columns, keep it readable in the
Word report from the start. Use `Group`, `Sample n`, `Miss.`, `Mean`, `SD`,
`Q1`, `Median`, `Q3`, `IQR`, `Min.`, and `Max.` for the corresponding columns,
and use 8-point Arial throughout the table. Do not default every statistic to
two decimal places. For a variable recorded in whole units, show means and
standard deviations to at most one decimal place and show order statistics
with no more precision than helps distinguish the observed values. Retain two
decimal places when they are meaningful, as with prices recorded in cents.

The canonical summary and value helpers reject fixed-notation output that would
silently round a nonzero value to zero or create an unwieldy cell. Increase the
requested display precision or use student-approved, interpretable units rather
than bypassing that guard. Display p-values with the canonical threshold rule:
`<0.001` below the threshold and three decimal places otherwise.

Use ordinary formatting defaults without asking about optional digits, units,
or styling when the requested table is otherwise specified. The student can
revise those presentation choices through the same visible table ID.
