# IntroStatGPT for TEMBA Statistics

This folder contains the IntroStatGPT workspace, Homework 1, and the course
datasets. Keep the folder and its contents together.

To begin:

1. Open this extracted folder in one of the supported desktop tools:
   - In Codex, open the folder as a workspace and start a new task.
   - In Claude Code, select **Code**, **Local**, and then select this folder.
2. Send: “Set up this IntroStatGPT workspace and verify that it is ready. Do
   not begin an analysis yet.”

Setup is complete when IntroStatGPT reports that the assignment data and
required R packages are ready. The Homework 1 assignment is also included as
`ASSIGNMENT.pdf`.
