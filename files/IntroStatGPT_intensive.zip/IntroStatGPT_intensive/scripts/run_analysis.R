#!/usr/bin/env Rscript

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  value_after <- function(flag, default = NULL) {
    hit <- which(args == flag)
    if (!length(hit)) return(default)
    if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
    args[[hit[[1]] + 1L]]
  }
  flags <- c("--root", "--title", "--analysis")
  value_indices <- unlist(lapply(flags, function(flag) {
    hit <- which(args == flag)
    if (length(hit) && hit[[1]] < length(args)) hit[[1]] + 1L else integer()
  }))
  positionals <- args[setdiff(which(!grepl("^--", args)), value_indices)]
  analysis_ref <- value_after("--analysis")
  replace <- "--replace" %in% args
  if ((is.null(analysis_ref) && length(positionals) != 1L) ||
      (!is.null(analysis_ref) && length(positionals) != 0L)) {
    stop("Usage: run_analysis.R <slug> [--replace] [--title <title>] or --analysis <visible-ref> [--title <title>].", call. = FALSE)
  }
  root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
  source(file.path(root, "R", "harness_utils.R"))
  source(file.path(root, "R", "harness_io.R"))
  source(file.path(root, "R", "workspace_lock.R"))
  source(file.path(root, "R", "analysis_board.R"))
  dir.create(file.path(root, "analysis"), recursive = TRUE, showWarnings = FALSE)
  board <- introstat_sync_analysis_board(root)
  slug <- if (is.null(analysis_ref)) positionals[[1]] else introstat_board_resolve(board, analysis_ref)
  if (!introstat_safe_analysis_slug(slug)) stop("Analysis slug must use lowercase letters, numbers, and internal hyphens.", call. = FALSE)
  directory <- file.path(root, "analysis", slug)
  source_path <- file.path(directory, "analysis.R")
  if (!file.exists(source_path)) stop("Missing analysis source: ", source_path, call. = FALSE)
  existing <- if (file.exists(file.path(directory, "manifest.yaml"))) read_manifest(file.path(directory, "manifest.yaml")) else NULL
  title <- value_after("--title", as.character(existing$title %||% tools::toTitleCase(gsub("-", " ", slug))))
  if (!is.character(title) || length(title) != 1L || is.na(title) || !nzchar(trimws(title))) stop("Analysis title must be a non-empty string.", call. = FALSE)
  title <- trimws(sub("^[PRT][1-9][0-9]*:[[:space:]]*", "", title, ignore.case = TRUE))
  if (!nzchar(title)) stop("Analysis title must contain text after any visible-ID prefix.", call. = FALSE)
  stage <- tempfile(paste0(".", slug, "-stage-"), tmpdir = file.path(root, "analysis"))
  dir.create(stage)
  on.exit(if (!is.null(stage) && dir.exists(stage)) unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)
  old <- setwd(root); on.exit(setwd(old), add = TRUE)
  env <- new.env(parent = globalenv())
  source("R/analysis_header.R", local = env, echo = FALSE)
  result <- source(source_path, local = env, echo = FALSE)
  object <- result$value
  artifact_type <- artifact_type_from_object(object)
  validate_artifact(object, artifact_type)
  if (!is.null(existing) && nzchar(as.character(existing$artifact_type %||% "")) &&
      !identical(as.character(existing$artifact_type), artifact_type)) {
    stop("A revision must keep the existing artifact type.", call. = FALSE)
  }
  created_at <- as.character(existing$created_at %||% format(Sys.time(), tz = "UTC", usetz = TRUE))
  now <- format(Sys.time(), tz = "UTC", usetz = TRUE)
  saveRDS(object, file.path(stage, "object.rds"))
  rendered <- render_artifact(object, artifact_type, file.path(stage, "preview"))
  manifest <- list(slug = slug, title = title,
                   status = "analysis", artifact_type = artifact_type, object = "object.rds",
                   source = "analysis.R", artifacts = list(file.path("preview", basename(rendered))),
                   created_at = created_at, updated_at = now)
  if (!is.null(existing$display_id)) manifest$display_id <- existing$display_id
  write_manifest(file.path(stage, "manifest.yaml"), manifest)
  if (!file.copy(source_path, file.path(stage, "analysis.R"), overwrite = TRUE)) stop("Could not stage the analysis source.", call. = FALSE)
  artifact_tx <- NULL; board_tx <- NULL
  introstat_with_workspace_lock(root, function() {
    on.exit(if (!is.null(board_tx)) board_tx$rollback(), add = TRUE)
    on.exit(if (!is.null(artifact_tx)) artifact_tx$rollback(), add = TRUE)
    if (identical(Sys.getenv("INTROSTAT_FAIL_ARTIFACT_INSTALL", ""), "1")) stop("Injected artifact install failure.", call. = FALSE)
    artifact_tx <<- introstat_begin_replace_dir(stage, directory)
    candidate <- introstat_sync_analysis_board_unlocked(root, persist = FALSE)
    installed <- read_manifest(file.path(directory, "manifest.yaml"))
    installed$display_id <- candidate$artifacts[[slug]]$display_id
    if (identical(Sys.getenv("INTROSTAT_FAIL_INSTALLED_MANIFEST_WRITE", ""), "1")) stop("Injected installed manifest write failure.", call. = FALSE)
    staged_manifest <- tempfile(".manifest-stage-", tmpdir = directory)
    on.exit(if (file.exists(staged_manifest)) unlink(staged_manifest, force = TRUE), add = TRUE)
    write_manifest(staged_manifest, installed)
    introstat_atomic_replace_file(staged_manifest, file.path(directory, "manifest.yaml"))
    board_path <- introstat_board_path(root)
    old_board <- if (file.exists(board_path)) yaml::read_yaml(board_path) else NULL
    board_changed <- is.null(old_board) || !identical(introstat_board_semantic(candidate), introstat_board_semantic(old_board))
    if (board_changed) {
      staged_board <- tempfile(".board-stage-", tmpdir = file.path(root, "analysis"))
      on.exit(if (file.exists(staged_board)) unlink(staged_board, force = TRUE), add = TRUE)
      introstat_board_write_yaml(candidate, staged_board)
      if (identical(Sys.getenv("INTROSTAT_FAIL_BOARD_INSTALL", ""), "1")) stop("Injected board install failure.", call. = FALSE)
      board_tx <<- introstat_begin_replace_file(staged_board, board_path)
      if (identical(Sys.getenv("INTROSTAT_FAIL_AFTER_BOARD_INSTALL", ""), "1")) stop("Injected failure after board install.", call. = FALSE)
    }
    if (!is.null(board_tx)) board_tx$commit()
    artifact_tx$commit()
    invisible(NULL)
  })
  stage <- NULL
  render_error <- tryCatch({
    source(file.path(root, "scripts", "render_analysis.R"), local = new.env(parent = globalenv()))
    NULL
  }, error = identity)
  final <- read_manifest(file.path(directory, "manifest.yaml"))
  id <- as.character(final$display_id %||% "")
  artifact_path <- file.path(directory, final$artifacts[[1]])
  cat("Rendered analysis: ", if (nzchar(id)) paste0(id, ": ", final$title) else final$title, "\n", sep = "")
  if (nzchar(id) && identical(final$artifact_type, "plot")) cat("Plot ID: ", id, "\n", sep = "") else if (nzchar(id)) cat("Artifact ID: ", id, "\n", sep = "")
  chat_preview <- if (identical(final$artifact_type, "plot")) artifact_path else file.path(dirname(artifact_path), "artifact-chat.png")
  cat("Chat preview: ", normalizePath(chat_preview, mustWork = TRUE), "\n", sep = "")
  if (!identical(final$artifact_type, "plot")) {
    chat_table <- file.path(dirname(artifact_path), "artifact-chat.md")
    cat("Chat table: ", normalizePath(chat_table, mustWork = TRUE), "\n", sep = "")
    cat("--- CHAT TABLE BEGIN ---\n"); cat(readLines(chat_table, warn = FALSE), sep = "\n"); cat("\n--- CHAT TABLE END ---\n")
  }
  page <- file.path(root, "generated", "analysis.html")
  if (file.exists(page)) cat("Analysis page: ", normalizePath(page, mustWork = TRUE), "\n", sep = "")
  if (!is.null(render_error)) warning("saved; page refresh failed: ", conditionMessage(render_error), call. = FALSE)
  invisible(list(artifact_id = if (nzchar(id)) id else slug, artifact_type = artifact_type, operation = "rerun"))
}
log_args <- commandArgs(trailingOnly = TRUE)
root_hit <- which(log_args == "--root")
log_root <- if (length(root_hit) && root_hit[[1]] < length(log_args)) log_args[[root_hit[[1]] + 1L]] else getwd()
log_root <- normalizePath(log_root, mustWork = TRUE)
source(file.path(log_root, "R", "harness_log.R"))
introstat_run_workflow(log_root, "analysis_run", main())
