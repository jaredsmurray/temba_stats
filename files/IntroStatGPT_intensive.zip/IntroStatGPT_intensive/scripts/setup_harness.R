#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
value_after <- function(flag, default = NULL) {
  hit <- which(args == flag)
  if (!length(hit)) return(default)
  if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[hit[[1]] + 1L]]
}

root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
if (getRversion() < "4.2.0") {
  stop("R 4.2 or newer is required before packages can be installed.", call. = FALSE)
}

package_file <- file.path(root, "required_packages.txt")
if (!file.exists(package_file)) stop("Missing required_packages.txt.", call. = FALSE)
packages <- trimws(readLines(package_file, warn = FALSE))
packages <- unique(packages[nzchar(packages) & !startsWith(packages, "#")])
missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]

if (!length(missing)) {
  cat("All required R packages are already installed.\n")
} else {
  user_library <- Sys.getenv("R_LIBS_USER")
  if (nzchar(user_library)) {
    dir.create(user_library, recursive = TRUE, showWarnings = FALSE)
    if (dir.exists(user_library)) .libPaths(c(user_library, .libPaths()))
  }
  writable <- .libPaths()[file.access(.libPaths(), 2L) == 0L]
  if (!length(writable)) {
    stop("R has no writable user package library. Check the R installation and try setup again.", call. = FALSE)
  }
  library_path <- writable[[1]]
  cat("Installing missing R packages: ", paste(missing, collapse = ", "), "\n", sep = "")
  utils::install.packages(
    missing,
    repos = "https://cloud.r-project.org",
    lib = library_path,
    dependencies = NA
  )
}

still_missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(still_missing)) {
  stop("These packages are still unavailable: ", paste(still_missing, collapse = ", "), call. = FALSE)
}

old <- setwd(root)
on.exit(setwd(old), add = TRUE)
status <- system2("Rscript", "scripts/check_setup.R")
if (!identical(status, 0L)) stop("Package installation finished, but harness validation failed.", call. = FALSE)
cat("Setup is complete.\n")
