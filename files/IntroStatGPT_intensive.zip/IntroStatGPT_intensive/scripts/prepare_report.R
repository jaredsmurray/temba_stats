#!/usr/bin/env Rscript

main <- function() {
  args <- commandArgs(trailingOnly = TRUE); value_after <- function(flag, default = NULL) { hit <- which(args == flag); if (!length(hit)) return(default); if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE); args[[hit[[1]] + 1L]] }
  root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE); source(file.path(root, "R", "harness_utils.R")); source(file.path(root, "R", "harness_io.R")); source(file.path(root, "R", "workspace_lock.R")); source(file.path(root, "R", "analysis_board.R")); source(file.path(root, "R", "report_runtime.R")); source(file.path(root, "R", "report_snapshots.R"))
  report_ready_root <- file.path(root, "report_ready"); generated_root <- file.path(root, "generated"); if (introstat_is_symlink(report_ready_root) || introstat_is_symlink(generated_root)) stop("Report-ready and generated directories cannot be symbolic links.", call. = FALSE); dir.create(report_ready_root, recursive = TRUE, showWarnings = FALSE); dir.create(generated_root, recursive = TRUE, showWarnings = FALSE)
  plan_path <- file.path(generated_root, "report_plan.yaml"); snapshot_txs <- list(); plan_tx <- NULL; stages <- character(); result <- NULL
  introstat_with_workspace_lock(root, function() {
    on.exit({ for (tx in rev(snapshot_txs)) try(tx$rollback(), silent = TRUE); if (!is.null(plan_tx)) try(plan_tx$rollback(), silent = TRUE); if (length(stages)) unlink(stages, recursive = TRUE, force = TRUE) }, add = TRUE)
    board_path <- introstat_board_path(root); if (!file.exists(board_path)) stop("Analysis board is not initialized.", call. = FALSE); board <- yaml::read_yaml(board_path); introstat_board_validate(board); board <- introstat_board_normalize_legacy_sections(board); synced <- introstat_sync_analysis_board_unlocked(root, persist = TRUE); if (!identical(introstat_board_semantic(synced), introstat_board_semantic(board))) stop("Analysis board changed; refresh the board before preparing the report.", call. = FALSE); board <- synced; ordinary <- board$sections[vapply(board$sections, function(x) identical(x$role, "report"), logical(1))]; selected <- lapply(ordinary, function(section) {
      keys <- as.character(unlist(section$artifacts %||% character(), use.names = FALSE)); keys[vapply(keys, function(key) isTRUE(board$artifacts[[key]]$include_in_report) && !isTRUE(board$artifacts[[key]]$archived), logical(1))]
    }); names(selected) <- vapply(ordinary, `[[`, character(1), "id")
    unassigned <- board$sections[[length(board$sections)]]; blocked <- as.character(unlist(unassigned$artifacts %||% character(), use.names = FALSE)); blocked <- blocked[vapply(blocked, function(key) isTRUE(board$artifacts[[key]]$include_in_report) && !isTRUE(board$artifacts[[key]]$archived), logical(1))]
    if (length(blocked)) stop("Selected artifacts remain in Unassigned: ", paste(vapply(blocked, function(key) board$artifacts[[key]]$display_id, character(1)), collapse = ", "), ". Place them in a report section before preparing the report.", call. = FALSE)
    # Every ordinary board section is part of the report skeleton, including
    # sections that currently have no selected artifacts. Unassigned remains a
    # placement diagnostic and is never emitted as a report heading.
    records <- list(); emitted <- seq_along(ordinary); plan_sections <- lapply(emitted, function(i) list(section_id = ordinary[[i]]$id, title = ordinary[[i]]$title, include_if_empty = TRUE, artifacts = unname(vapply(selected[[i]], function(key) board$artifacts[[key]]$display_id, character(1)))))
    for (i in seq_along(ordinary)) for (key in selected[[i]]) {
      stage <- introstat_snapshot_stage(root, board, key, list(existing = if (dir.exists(file.path(root, "report_ready", key)) && file.exists(file.path(root, "report_ready", key, "manifest.yaml"))) yaml::read_yaml(file.path(root, "report_ready", key, "manifest.yaml")) else list())); stages <- c(stages, stage); manifest <- attr(stage, "manifest"); records[[length(records) + 1L]] <- list(display_id = manifest$display_id, slug = key, manifest = file.path("report_ready", key, "manifest.yaml"), manifest_hash = introstat_snapshot_hash(file.path(stage, "manifest.yaml")), object = file.path("report_ready", key, "object.rds"), object_hash = manifest$object_hash)
    }
    title <- "Statistical analysis report skeleton"; subtitle <- NULL; outline_path <- file.path(root, "report_outline.yaml"); if (file.exists(outline_path)) { outline <- yaml::read_yaml(outline_path); if (!is.null(outline$title)) title <- introstat_snapshot_scalar(outline$title, "Report title"); if (!is.null(outline$subtitle)) subtitle <- introstat_snapshot_scalar(outline$subtitle, "Report subtitle") }
    binding <- list(schema_version = 1L, board_revision = as.integer(board$revision), title = title, subtitle = subtitle, sections = plan_sections, snapshots = records); token <- introstat_report_plan_hash(binding)
    if (isTRUE(getOption("introstat.fail_plan_invalidation", FALSE)) || identical(Sys.getenv("INTROSTAT_FAIL_PLAN_INVALIDATION", ""), "1")) stop("Injected report-plan invalidation failure.", call. = FALSE)
    if (file.exists(plan_path)) unlink(plan_path, force = TRUE)
    if (file.exists(plan_path)) stop("Could not invalidate the previous report plan.", call. = FALSE)
    for (record in records) { if (identical(Sys.getenv("INTROSTAT_FAIL_SNAPSHOT_INSTALL", ""), record$slug)) stop("Injected snapshot install failure for ", record$slug, ".", call. = FALSE); stage <- stages[[match(record$slug, vapply(records, `[[`, character(1), "slug"))]]; target <- file.path(root, "report_ready", record$slug); snapshot_txs[[length(snapshot_txs) + 1L]] <<- introstat_begin_replace_dir(stage, target) }
    stages <- character()
    plan <- list(schema_version = 1L, board_revision = as.integer(board$revision), render_token = token, title = title, subtitle = subtitle, sections = plan_sections, snapshots = records)
    plan_stage <- tempfile(".report-plan-", tmpdir = file.path(root, "generated")); dir.create(dirname(plan_stage), recursive = TRUE, showWarnings = FALSE); if (isTRUE(getOption("introstat.fail_report_plan_write", FALSE)) || identical(Sys.getenv("INTROSTAT_FAIL_REPORT_PLAN_WRITE", ""), "1")) stop("Injected report-plan write failure.", call. = FALSE); yaml::write_yaml(plan, plan_stage); plan_tx <<- introstat_begin_replace_file(plan_stage, plan_path)
    for (tx in snapshot_txs) tx$commit(); plan_tx$commit(); snapshot_txs <<- list(); plan_tx <<- NULL
    result <<- list(board_revision = board$revision, render_token = token, plan = plan)
  })
  gallery_error <- tryCatch({ source(file.path(root, "scripts", "render_analysis.R"), local = new.env(parent = globalenv())); NULL }, error = identity); if (!is.null(gallery_error)) warning("saved; page refresh failed: ", conditionMessage(gallery_error), call. = FALSE)
  cat("Report preparation ready for approval.\nRender token: ", result$render_token, "\n", sep = ""); for (section in result$plan$sections) cat(section$title, ": ", if (length(section$artifacts)) paste(section$artifacts, collapse = ", ") else "(empty)", "\n", sep = ""); cat("Approve compilation using this render token.\n")
  invisible(result)
}

args <- commandArgs(trailingOnly = TRUE); hit <- which(args == "--root"); log_root <- if (length(hit) && hit[[1]] < length(args)) args[[hit[[1]] + 1L]] else getwd(); log_root <- normalizePath(log_root, mustWork = TRUE); source(file.path(log_root, "R", "harness_log.R")); introstat_run_workflow(log_root, "report_prepare", main())
