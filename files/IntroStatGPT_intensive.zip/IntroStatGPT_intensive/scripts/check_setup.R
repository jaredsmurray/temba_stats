#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
value_after <- function(flag, default = NULL) {
  hit <- which(args == flag)
  if (!length(hit)) return(default)
  if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[hit[[1]] + 1L]]
}

root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
package_file <- file.path(root, "required_packages.txt")
default_packages <- c(
  "ggplot2", "dplyr", "readr", "tibble", "scales", "patchwork",
  "modelsummary", "flextable", "officer", "htmltools", "yaml", "jsonlite", "filelock"
)
packages <- if (file.exists(package_file)) {
  lines <- trimws(readLines(package_file, warn = FALSE))
  unique(lines[nzchar(lines) & !startsWith(lines, "#")])
} else {
  default_packages
}

cat("R version:", as.character(getRversion()), "\n")
if (getRversion() < "4.2.0") {
  cat("ERROR: R 4.2 or newer is required.\n")
  quit(save = "no", status = 1L)
}

missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) {
  cat("Missing required R packages:\n  ", paste(missing, collapse = ", "), "\n", sep = "")
  cat("Ask Codex to set up the assignment. It will request permission before installing them.\n\n")
  quit(save = "no", status = 1L)
}
cat("Required packages: OK\n")

required_files <- c(
  "AGENTS.md",
  "required_packages.txt",
  "R/harness_io.R",
  "R/harness_log.R",
  "R/analysis_header.R",
  "R/harness_utils.R",
  "R/workspace_lock.R",
  "R/analysis_board.R",
  "R/report_runtime.R",
  "R/report_snapshots.R",
  "R/report_store.R",
  "scripts/export_analysis.R",
  "scripts/run_analysis.R",
  "scripts/submit_analysis.R",
  "scripts/render_analysis.R",
  "scripts/render_analysis_organizer.R",
  "scripts/update_analysis_board.R",
  ".agents/skills/organize-analysis/SKILL.md",
  ".agents/skills/view-analysis/SKILL.md",
  ".agents/skills/compile-report/SKILL.md",
  "scripts/setup_harness.R",
  "scripts/mark_report_ready.R",
  "scripts/prepare_report.R",
  "scripts/compile_report.R",
  "report_outline.yaml"
)
missing_files <- required_files[!file.exists(file.path(root, required_files))]
if (length(missing_files)) {
  cat("ERROR: Assignment folder is incomplete. Missing:\n  ", paste(missing_files, collapse = "\n  "), "\n", sep = "")
  quit(save = "no", status = 1L)
}
cat("Harness files: OK\n")

data_list <- file.path(root, "required_data_files.txt")
if (file.exists(data_list)) {
  data_files <- trimws(readLines(data_list, warn = FALSE))
  data_files <- data_files[nzchar(data_files) & !startsWith(data_files, "#")]
  missing_data <- data_files[!file.exists(file.path(root, data_files))]
  if (length(missing_data)) {
    cat("ERROR: Assignment data are missing:\n  ", paste(missing_data, collapse = "\n  "), "\n", sep = "")
    quit(save = "no", status = 1L)
  }
  cat("Assignment data: OK\n")
}

old <- setwd(root)
on.exit(setwd(old), add = TRUE)
header_env <- new.env(parent = globalenv())
header_error <- tryCatch({
  source("R/analysis_header.R", local = header_env, echo = FALSE)
  NULL
}, error = identity)
if (!is.null(header_error)) {
  cat("ERROR: Shared analysis setup failed:\n  ", conditionMessage(header_error), "\n", sep = "")
  quit(save = "no", status = 1L)
}
cat("Shared analysis setup: OK\n")

model <- stats::lm(mpg ~ wt, data = mtcars)
make_table <- get("make_reg_table", envir = header_env, inherits = TRUE)
table <- make_table(model)
if (!inherits(table, "introstat_regtable")) {
  cat("ERROR: Regression-table self-check returned the wrong object class.\n")
  quit(save = "no", status = 1L)
}
cat("Regression-table self-check: OK\n")
cat("Setup check passed.\n")
