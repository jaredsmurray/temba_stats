#!/usr/bin/env Rscript

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  value_after <- function(flag, default = NULL) {
    hit <- which(args == flag)
    if (!length(hit)) return(default)
    if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
    args[[hit[[1]] + 1L]]
  }
  fork_ref <- value_after("--fork")
  analysis_ref <- value_after("--analysis")
  replace <- "--replace" %in% args
  if (sum(c(!is.null(fork_ref), !is.null(analysis_ref), replace)) > 1L) stop("Choose exactly one of --fork, --analysis, or --replace.", call. = FALSE)
  flags <- c("--root", "--title", "--fork", "--analysis")
  value_indices <- unlist(lapply(flags, function(flag) {
    hit <- which(args == flag)
    if (length(hit) && hit[[1]] < length(args)) hit[[1]] + 1L else integer()
  }))
  positionals <- args[setdiff(which(!grepl("^--", args)), value_indices)]
  if (!is.null(fork_ref)) {
    if (length(positionals) != 1L) stop("Usage: submit_analysis.R --fork <visible-ref> <new-slug> --title <title>.", call. = FALSE)
    new_slug <- positionals[[1]]
  } else if (!is.null(analysis_ref)) {
    if (length(positionals)) stop("A reference cannot have a positional slug.", call. = FALSE)
    new_slug <- NULL
  } else {
    if (length(positionals) != 1L) stop("Usage: submit_analysis.R <slug> [--replace] or --analysis <visible-ref>.", call. = FALSE)
    new_slug <- tolower(gsub("[^a-z0-9]+", "-", positionals[[1]]))
    new_slug <- gsub("^-+|-+$", "", new_slug)
  }
  root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
  body <- readLines(file("stdin"), warn = FALSE)
  if (!length(body) || !any(nzchar(trimws(body)))) stop("Submit a non-empty R expression through standard input.", call. = FALSE)
  source(file.path(root, "R", "harness_utils.R"))
  source(file.path(root, "R", "harness_io.R"))
  source(file.path(root, "R", "workspace_lock.R"))
  source(file.path(root, "R", "analysis_board.R"))
  analysis_root <- file.path(root, "analysis")
  dir.create(analysis_root, recursive = TRUE, showWarnings = FALSE)
  needs_ref <- !is.null(fork_ref) || !is.null(analysis_ref) || replace
  board <- if (!needs_ref && !file.exists(introstat_board_path(root))) NULL else introstat_sync_analysis_board(root)
  source_key <- if (!is.null(fork_ref)) introstat_board_resolve(board, fork_ref) else if (!is.null(analysis_ref)) introstat_board_resolve(board, analysis_ref) else if (replace) introstat_board_resolve(board, new_slug) else NULL
  slug <- if (is.null(fork_ref)) if (is.null(source_key)) new_slug else source_key else new_slug
  if (!introstat_safe_analysis_slug(slug)) stop("Analysis slug must use lowercase letters, numbers, and internal hyphens.", call. = FALSE)
  directory <- file.path(analysis_root, slug)
  if (is.null(source_key) && dir.exists(directory)) stop("An analysis with this slug already exists; use --replace for a revision.", call. = FALSE)
  if (!is.null(fork_ref) && dir.exists(directory)) stop("The fork destination already exists.", call. = FALSE)
  referenced <- if (!is.null(source_key)) board$artifacts[[source_key]] else NULL
  existing <- if (file.exists(file.path(directory, "manifest.yaml"))) read_manifest(file.path(directory, "manifest.yaml")) else NULL
  title <- value_after("--title", as.character(existing$title %||% referenced$last_known_title %||% tools::toTitleCase(gsub("-", " ", slug))))
  if (!is.character(title) || length(title) != 1L || is.na(title) || !nzchar(trimws(title))) stop("Analysis title must be a non-empty string.", call. = FALSE)
  title <- trimws(sub("^[PRT][1-9][0-9]*:[[:space:]]*", "", title, ignore.case = TRUE))
  if (!nzchar(title)) stop("Analysis title must contain text after any visible-ID prefix.", call. = FALSE)
  stage <- tempfile(paste0(".", slug, "-stage-"), tmpdir = analysis_root)
  dir.create(stage)
  on.exit(if (!is.null(stage) && dir.exists(stage)) unlink(stage, recursive = TRUE, force = TRUE), add = TRUE)
  old <- setwd(root); on.exit(setwd(old), add = TRUE)
  env <- new.env(parent = globalenv())
  evaluate_body <- function(lines) {
    connection <- textConnection(lines)
    on.exit(close(connection), add = TRUE)
    source(connection, local = env, echo = FALSE)
  }
  result <- evaluate_body(c('source("R/analysis_header.R")', "", body))
  object <- result$value
  artifact_type <- artifact_type_from_object(object)
  validate_artifact(object, artifact_type)
  if (!is.null(referenced) && !identical(as.character(referenced$artifact_type %||% ""), artifact_type)) stop("A revision or fork must keep the source artifact type.", call. = FALSE)
  if (!is.null(existing) && (replace || !is.null(analysis_ref)) && !identical(as.character(existing$artifact_type %||% ""), artifact_type)) stop("A revision must keep the existing artifact type.", call. = FALSE)
  now <- format(Sys.time(), tz = "UTC", usetz = TRUE)
  created_at <- as.character(existing$created_at %||% now)
  saveRDS(object, file.path(stage, "object.rds"))
  rendered <- render_artifact(object, artifact_type, file.path(stage, "preview"))
  manifest <- list(slug = slug, title = title,
                   status = "analysis", artifact_type = artifact_type, object = "object.rds",
                   source = "analysis.R", artifacts = list(file.path("preview", basename(rendered))),
                   created_at = created_at, updated_at = now)
  if (!is.null(existing$display_id)) manifest$display_id <- existing$display_id
  write_manifest(file.path(stage, "manifest.yaml"), manifest)
  writeLines(c('source("R/analysis_header.R")', "", body), file.path(stage, "analysis.R"), useBytes = TRUE)
  artifact_tx <- NULL; board_tx <- NULL
  introstat_with_workspace_lock(root, function() {
    on.exit(if (!is.null(board_tx)) board_tx$rollback(), add = TRUE)
    on.exit(if (!is.null(artifact_tx)) artifact_tx$rollback(), add = TRUE)
    if (identical(Sys.getenv("INTROSTAT_FAIL_ARTIFACT_INSTALL", ""), "1")) stop("Injected artifact install failure.", call. = FALSE)
    artifact_tx <<- introstat_begin_replace_dir(stage, directory)
    candidate <- introstat_sync_analysis_board_unlocked(root, persist = FALSE)
    if (!is.null(fork_ref)) {
      candidate <- introstat_analysis_board_insert_after_unlocked(candidate, source_key, slug)
      candidate$artifacts[[slug]]$include_in_report <- FALSE
      candidate$artifacts[[slug]]$archived <- FALSE
    }
    installed <- read_manifest(file.path(directory, "manifest.yaml"))
    installed$display_id <- candidate$artifacts[[slug]]$display_id
    if (identical(Sys.getenv("INTROSTAT_FAIL_INSTALLED_MANIFEST_WRITE", ""), "1")) stop("Injected installed manifest write failure.", call. = FALSE)
    staged_manifest <- tempfile(".manifest-stage-", tmpdir = directory)
    on.exit(if (file.exists(staged_manifest)) unlink(staged_manifest, force = TRUE), add = TRUE)
    write_manifest(staged_manifest, installed)
    introstat_atomic_replace_file(staged_manifest, file.path(directory, "manifest.yaml"))
    board_path <- introstat_board_path(root)
    old_board <- if (file.exists(board_path)) yaml::read_yaml(board_path) else NULL
    board_changed <- is.null(old_board) || !identical(introstat_board_semantic(candidate), introstat_board_semantic(old_board))
    if (board_changed) {
      staged_board <- tempfile(".board-stage-", tmpdir = analysis_root)
      on.exit(if (file.exists(staged_board)) unlink(staged_board, force = TRUE), add = TRUE)
      introstat_board_write_yaml(candidate, staged_board)
      if (identical(Sys.getenv("INTROSTAT_FAIL_BOARD_INSTALL", ""), "1")) stop("Injected board install failure.", call. = FALSE)
      board_tx <<- introstat_begin_replace_file(staged_board, board_path)
      if (identical(Sys.getenv("INTROSTAT_FAIL_AFTER_BOARD_INSTALL", ""), "1")) stop("Injected failure after board install.", call. = FALSE)
    }
    if (!is.null(board_tx)) board_tx$commit()
    artifact_tx$commit()
    invisible(NULL)
  })
  stage <- NULL
  render_error <- tryCatch({
    source(file.path(root, "scripts", "render_analysis.R"), local = new.env(parent = globalenv()))
    NULL
  }, error = identity)
  final <- read_manifest(file.path(directory, "manifest.yaml"))
  id <- as.character(final$display_id %||% "")
  artifact_path <- file.path(directory, final$artifacts[[1]])
  visible <- if (nzchar(id)) paste0(id, ": ", final$title) else final$title
  cat(if (is.null(source_key) || !is.null(fork_ref)) "Created analysis: " else "Updated analysis: ", visible, "\n", sep = "")
  if (nzchar(id) && identical(final$artifact_type, "plot")) cat("Plot ID: ", id, "\n", sep = "") else if (nzchar(id)) cat("Artifact ID: ", id, "\n", sep = "")
  chat_preview <- if (identical(final$artifact_type, "plot")) artifact_path else file.path(dirname(artifact_path), "artifact-chat.png")
  cat("Chat preview: ", normalizePath(chat_preview, mustWork = TRUE), "\n", sep = "")
  if (!identical(final$artifact_type, "plot")) {
    chat_table <- file.path(dirname(artifact_path), "artifact-chat.md")
    cat("Chat table: ", normalizePath(chat_table, mustWork = TRUE), "\n", sep = "")
    cat("--- CHAT TABLE BEGIN ---\n"); cat(readLines(chat_table, warn = FALSE), sep = "\n"); cat("\n--- CHAT TABLE END ---\n")
  }
  page <- file.path(root, "generated", "analysis.html")
  if (file.exists(page)) cat("Analysis page: ", normalizePath(page, mustWork = TRUE), "\n", sep = "")
  if (!is.null(render_error)) warning("saved; page refresh failed: ", conditionMessage(render_error), call. = FALSE)
  invisible(list(artifact_id = if (nzchar(id)) id else slug, artifact_type = artifact_type, operation = if (is.null(source_key)) "create" else if (!is.null(fork_ref)) "fork" else "replace"))
}
log_args <- commandArgs(trailingOnly = TRUE)
root_hit <- which(log_args == "--root")
log_root <- if (length(root_hit) && root_hit[[1]] < length(log_args)) log_args[[root_hit[[1]] + 1L]] else getwd()
log_root <- normalizePath(log_root, mustWork = TRUE)
source(file.path(log_root, "R", "harness_log.R"))
introstat_run_workflow(log_root, "analysis_submit", main())
