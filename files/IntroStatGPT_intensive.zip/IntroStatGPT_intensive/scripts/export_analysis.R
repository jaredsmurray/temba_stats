#!/usr/bin/env Rscript

main <- function() {

args <- commandArgs(trailingOnly = TRUE)
value_after <- function(flag, default = NULL) {
  hit <- which(args == flag)
  if (!length(hit)) return(default)
  if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[hit[[1]] + 1L]]
}
value_flags <- c("--analysis", "--root")
value_indices <- unlist(lapply(value_flags, function(flag) {
  hit <- which(args == flag)
  if (length(hit) && hit[[1]] < length(args)) hit[[1]] + 1L else integer()
}))
positionals <- args[setdiff(which(!grepl("^--", args)), value_indices)]
query <- value_after("--analysis", if (length(positionals)) positionals[[1]] else NULL)
if (is.null(query) || !nzchar(trimws(query)) || length(positionals) > 1L) {
  stop(
    paste(
      "Usage: Rscript scripts/export_analysis.R --analysis <visible-title>",
      "[--detailed-comments] [--working] [--overwrite] [--root <path>]"
    ),
    call. = FALSE
  )
}

root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
source(file.path(root, "R", "harness_io.R"))
`%||%` <- function(x, y) if (is.null(x)) y else x
detailed <- "--detailed-comments" %in% args
working <- "--working" %in% args
overwrite <- "--overwrite" %in% args

manifests <- list.files(
  file.path(root, "analysis"), pattern = "^manifest\\.ya?ml$",
  recursive = TRUE, full.names = TRUE, ignore.case = TRUE
)
records <- lapply(manifests, function(path) {
  manifest <- read_manifest(path)
  list(
    slug = as.character(manifest$slug %||% basename(dirname(path))),
    title = as.character(manifest$title %||% basename(dirname(path))),
    directory = dirname(path), manifest = manifest
  )
})
normalized <- tolower(trimws(query))
matches <- which(vapply(records, function(x) normalized %in% tolower(c(x$title, x$slug)), logical(1)))
if (!length(matches)) {
  matches <- which(vapply(records, function(x) {
    grepl(normalized, tolower(x$title), fixed = TRUE) || grepl(normalized, tolower(x$slug), fixed = TRUE)
  }, logical(1)))
}
if (length(matches) != 1L) {
  titles <- if (length(matches)) vapply(records[matches], `[[`, character(1), "title") else vapply(records, `[[`, character(1), "title")
  prefix <- if (length(matches)) "More than one analysis matches" else "No analysis matches"
  stop(prefix, ": ", query, ". Available titles: ", paste(titles, collapse = "; "), call. = FALSE)
}
record <- records[[matches[[1]]]]

ready_source <- file.path(root, "report_ready", record$slug, "reproduce.R")
analysis_source <- file.path(record$directory, as.character(record$manifest$source %||% "analysis.R"))
use_ready <- file.exists(ready_source) && !working
source_path <- if (use_ready) ready_source else analysis_source
if (!file.exists(source_path)) stop("Missing artifact source: ", source_path, call. = FALSE)

clean_source <- function(path) {
  lines <- sub("[[:space:]]+$", "", readLines(path, warn = FALSE))
  lines <- lines[!grepl("^# Standalone reproduction script generated", lines)]
  lines <- lines[!grepl("analysis_header[.]R", lines)]
  while (length(lines) && !nzchar(lines[[1]])) lines <- lines[-1]
  while (length(lines) && !nzchar(lines[[length(lines)]])) lines <- lines[-length(lines)]
  if (requireNamespace("styler", quietly = TRUE)) {
    styled <- tryCatch(styler::style_text(lines), error = function(error) lines)
    if (!inherits(try(parse(text = styled), silent = TRUE), "try-error")) lines <- styled
  }
  lines
}

call_name <- function(call) {
  head <- call[[1]]
  if (is.symbol(head)) return(as.character(head))
  if (is.call(head) && identical(as.character(head[[1]]), "::")) {
    return(paste0(as.character(head[[2]]), "::", as.character(head[[3]])))
  }
  ""
}
call_specs <- list(
  `ggplot2::ggplot` = list(summary = "Starts a ggplot from a data frame and aesthetic mapping.", positionals = c("data", "mapping")),
  ggplot = list(summary = "Starts a ggplot from a data frame and aesthetic mapping.", positionals = c("data", "mapping")),
  aes = list(summary = "Maps data variables to visual properties such as x, y, or color.", positionals = character()),
  `ggplot2::aes` = list(summary = "Maps data variables to visual properties such as x, y, or color.", positionals = character()),
  geom_point = list(summary = "Adds points to a plot.", positionals = c("mapping", "data")),
  geom_smooth = list(summary = "Adds a fitted smooth or regression line to a plot.", positionals = c("mapping", "data")),
  geom_boxplot = list(summary = "Adds boxplots showing the distribution within groups.", positionals = c("mapping", "data")),
  labs = list(summary = "Sets human-readable plot labels.", positionals = character()),
  lm = list(summary = "Fits a linear regression model.", positionals = c("formula", "data")),
  `stats::lm` = list(summary = "Fits a linear regression model.", positionals = c("formula", "data")),
  make_reg_table = list(summary = "Formats one or more fitted models as the canonical regression table.", positionals = c("model")),
  make_summary_table = list(summary = "Computes and formats grouped or ungrouped numerical summaries.", positionals = c("data", "group", "variables")),
  factor = list(summary = "Treats the supplied values as categorical levels.", positionals = c("x")),
  list = list(summary = "Combines named objects into one list; here the names become model headings.", positionals = character()),
  c = list(summary = "Combines values into a vector; named entries pair internal names with display labels.", positionals = character()),
  predict = list(summary = "Computes fitted values or predictions from a fitted model.", positionals = c("object", "newdata")),
  `stats::predict` = list(summary = "Computes fitted values or predictions from a fitted model.", positionals = c("object", "newdata"))
)

collect_calls <- function(expression) {
  found <- list()
  syntactic_operators <- c("<-", "=", "~", "+", "-", "*", "/", "^", "{", "(")
  walk <- function(node) {
    if (!is.call(node)) return(invisible(NULL))
    name <- call_name(node)
    if (nzchar(name) && !name %in% syntactic_operators) {
      key <- paste(deparse(node, width.cutoff = 160), collapse = " ")
      if (is.null(found[[key]])) found[[key]] <<- node
    }
    for (child in as.list(node)[-1]) walk(child)
    invisible(NULL)
  }
  for (item in as.list(expression)) walk(item)
  unname(found)
}

explain_call <- function(call) {
  name <- call_name(call)
  spec <- call_specs[[name]]
  summary <- if (is.null(spec)) paste0("Calls `", name, "` with the supplied values.") else spec$summary
  positionals <- if (is.null(spec)) character() else spec$positionals
  values <- as.list(call)[-1]
  tags <- names(call)[-1]
  if (is.null(tags)) tags <- rep("", length(values))
  positional_index <- 0L
  lines <- c(paste0("# ", name, "(): ", summary))
  for (i in seq_along(values)) {
    argument <- tags[[i]]
    if (!nzchar(argument)) {
      positional_index <- positional_index + 1L
      argument <- if (positional_index <= length(positionals)) positionals[[positional_index]] else paste0("argument ", positional_index)
    }
    value <- paste(deparse(values[[i]], width.cutoff = 90), collapse = " ")
    lines <- c(lines, paste0("#   - ", argument, " = ", value))
  }
  lines
}

source_lines <- clean_source(source_path)
source_expression <- parse(text = source_lines, keep.source = FALSE)
suffix <- if (detailed) "_reproduce_detailed.R" else "_reproduce.R"
output <- file.path(root, "exports", paste0(record$slug, suffix))
if (file.exists(output) && !overwrite) stop("Export already exists; use --overwrite to replace it: ", output, call. = FALSE)
dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)

guide <- character()
if (detailed) {
  calls <- collect_calls(source_expression)
  guide <- c("# Detailed function and supplied-argument guide", "# These comments explain the calls below; they do not change the analysis.", "#")
  for (call in calls) guide <- c(guide, explain_call(call), "#")
  guide <- c(guide, "")
}

origin <- if (use_ready) "report-ready snapshot" else "current working analysis"
render_dir <- file.path("exports", "reproduced", record$slug)
lines <- c(
  "# IntroStatGPT reproducibility script",
  paste0("# Output: ", record$title),
  paste0("# Exported from the ", origin, "."),
  "# Run this file from the assignment root with Rscript.",
  "if (!exists(\"introstat_report_header_loaded\")) source(\"R/analysis_header.R\")",
  "", guide,
  "# Rebuild the canonical statistical artifact.",
  "artifact <- {", paste0("  ", source_lines), "}", "",
  "# Validate and write a viewable copy.",
  "artifact_type <- artifact_type_from_object(artifact)",
  paste0("rendered_file <- render_artifact(artifact, artifact_type, ", encodeString(render_dir, quote = '"'), ")"),
  "message(\"Reproduced artifact: \", rendered_file)"
)
invisible(parse(text = lines, keep.source = FALSE))
writeLines(lines, output, useBytes = TRUE)
cat("Exported", output, if (detailed) "with detailed comments\n" else "with concise comments\n")
invisible(list(
  artifact_id = as.character(record$manifest$display_id %||% record$slug),
  artifact_type = as.character(record$manifest$artifact_type %||% "unknown"),
  operation = if (detailed) "detailed" else "concise"
))
}

log_args <- commandArgs(trailingOnly = TRUE)
root_hit <- which(log_args == "--root")
log_root <- if (length(root_hit) && root_hit[[1]] < length(log_args)) log_args[[root_hit[[1]] + 1L]] else getwd()
log_root <- normalizePath(log_root, mustWork = TRUE)
source(file.path(log_root, "R", "harness_log.R"))
introstat_run_workflow(log_root, "analysis_export", main())
