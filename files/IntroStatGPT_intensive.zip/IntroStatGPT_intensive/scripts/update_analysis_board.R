#!/usr/bin/env Rscript

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  value_after <- function(flag, default = NULL) {
    hit <- which(args == flag)
    if (!length(hit)) return(default)
    if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
    args[[hit[[1]] + 1L]]
  }
  root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
  source(file.path(root, "R", "workspace_lock.R"))
  source(file.path(root, "R", "analysis_board.R"))
  payload_path <- value_after("--payload")
  operation_flags <- c("--include", "--exclude", "--archive", "--restore", "--add-section", "--rename-section", "--remove-section", "--move-section", "--move-artifact")
  operation <- NULL; reference <- NULL
  for (flag in operation_flags) if (flag %in% args) { operation <- sub("^--", "", flag); reference <- value_after(flag); break }
  if (!is.null(payload_path) && !is.null(operation)) stop("Use either --payload or one granular board operation.", call. = FALSE)
  if (is.null(payload_path) && is.null(operation)) stop("Supply --payload or a granular board operation.", call. = FALSE)
  timeout_ms <- as.numeric(value_after("--timeout-ms", 10000))
  result <- if (!is.null(payload_path)) {
    if (!file.exists(payload_path)) stop("Mutation payload does not exist: ", payload_path, call. = FALSE)
    payload <- yaml::read_yaml(payload_path)
    introstat_analysis_board_apply_payload(root, payload, timeout_ms = timeout_ms)
  } else {
    position <- if ("--start" %in% args) "start" else if ("--end" %in% args) "end" else if ("--before" %in% args) "before" else if ("--after" %in% args) "after" else "end"
    anchor <- value_after(if (position == "before") "--before" else if (position == "after") "--after" else "--anchor")
    section <- value_after("--to")
    title <- value_after("--title", if (identical(operation, "add-section")) reference else NULL)
    include_empty <- tolower(value_after("--include-if-empty", "true"))
    if (!include_empty %in% c("true", "false")) stop("--include-if-empty must be true or false.", call. = FALSE)
    introstat_analysis_board_operation(root, operation, reference = reference, title = title, section = section, position = position, anchor = anchor, include_if_empty = identical(include_empty, "true"), confirm = "--confirm" %in% args, timeout_ms = timeout_ms)
  }
  render_error <- tryCatch({
    source(file.path(root, "scripts", "render_analysis.R"), local = new.env(parent = globalenv()))
    NULL
  }, error = identity)
  if (!is.null(render_error)) warning("saved; page refresh failed: ", conditionMessage(render_error), call. = FALSE)
  mapping <- attr(result, "new_section_ids") %||% character()
  cat("Updated analysis board to revision ", result$revision, ".\n", sep = "")
  if (length(mapping)) for (client in names(mapping)) cat("Section ", client, ": ", mapping[[client]], "\n", sep = "")
  invisible(list(revision = result$revision, section_ids = mapping))
}

args <- commandArgs(trailingOnly = TRUE)
root_hit <- which(args == "--root")
log_root <- if (length(root_hit) && root_hit[[1]] < length(args)) args[[root_hit[[1]] + 1L]] else getwd()
log_root <- normalizePath(log_root, mustWork = TRUE)
source(file.path(log_root, "R", "harness_log.R"))
introstat_run_workflow(log_root, "analysis_board_update", main())
