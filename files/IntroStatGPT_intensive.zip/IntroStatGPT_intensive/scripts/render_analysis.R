#!/usr/bin/env Rscript

# The gallery is a read-only projection of the analysis board. Its only
# durable writes are the two generated files published under the workspace
# lock; analysis and report state are owned by their respective workflows.

`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x

html_escape <- function(value) {
  value <- enc2utf8(as.character(value %||% ""))
  if (!length(value)) return("")
  codepoints <- utf8ToInt(value[[1]])
  out <- vapply(codepoints, function(codepoint) {
    if (codepoint < 0x20L && !codepoint %in% c(0x09L, 0x0aL, 0x0dL)) {
      return(sprintf("&#x%02X;", codepoint))
    }
    character <- intToUtf8(codepoint)
    switch(character,
      "&" = "&amp;", "<" = "&lt;", ">" = "&gt;", "\"" = "&quot;",
      "'" = "&#39;", character
    )
  }, character(1))
  paste0(out, collapse = "")
}

js_string <- function(value) {
  encoded <- jsonlite::toJSON(as.character(value %||% ""), auto_unbox = TRUE)
  encoded <- gsub("<", "\\u003C", encoded, fixed = TRUE)
  encoded <- gsub(">", "\\u003E", encoded, fixed = TRUE)
  encoded <- gsub("/", "\\u002F", encoded, fixed = TRUE)
  encoded
}

json_text <- function(value) {
  encoded <- jsonlite::toJSON(value, auto_unbox = TRUE, null = "null", digits = NA)
  encoded <- gsub("<", "\\u003C", encoded, fixed = TRUE)
  encoded <- gsub(">", "\\u003E", encoded, fixed = TRUE)
  encoded <- gsub("/", "\\u002F", encoded, fixed = TRUE)
  encoded
}

normalize_value <- function(value, default = "") {
  if (is.null(value) || !length(value) || is.na(value[[1]])) return(default)
  as.character(value[[1]])
}

is_true <- function(value) isTRUE(value) || identical(value, 1L) || identical(value, 1)

current_manifest <- function(record) {
  if (is.null(record)) return(list())
  data <- record$manifest_data
  if (!is.null(data) && is.list(data) && any(c("analysis", "current", "report_ready", "ready") %in% names(data))) {
    return(data$analysis %||% data$current %||% data)
  }
  data %||% list()
}

record_values <- function(record) {
  if (is.null(record)) return(list(directory = "", manifest = "", artifacts = character(), manifest_data = list()))
  if (is.list(record$record) && length(record$record)) record <- record$record
  list(
    directory = normalize_value(record$directory), manifest = normalize_value(record$manifest),
    artifacts = as.character(unlist(record$artifacts %||% character(), use.names = FALSE)),
    manifest_data = record$manifest_data %||% list()
  )
}

safe_artifact_path <- function(path, directory, root) {
  path <- normalize_value(path); directory <- normalize_value(directory)
  if (!nzchar(path) || !nzchar(directory) || grepl("^[/\\\\]", path) || grepl("^[A-Za-z]:", path)) return(NULL)
  directory <- normalizePath(directory, mustWork = FALSE)
  candidate <- normalizePath(file.path(directory, path), mustWork = FALSE)
  root <- normalizePath(root, mustWork = TRUE)
  dir_prefix <- paste0(directory, .Platform$file.sep); root_prefix <- paste0(root, .Platform$file.sep)
  if (!(identical(candidate, directory) || startsWith(candidate, dir_prefix))) return(NULL)
  if (!(identical(candidate, root) || startsWith(candidate, root_prefix))) return(NULL)
  candidate
}

relative_artifact_path <- function(path, root) {
  if (is.null(path) || !length(path) || !nzchar(path)) return(NULL)
  path <- normalizePath(path, mustWork = FALSE); root <- normalizePath(root, mustWork = TRUE)
  prefix <- paste0(root, .Platform$file.sep)
  if (!(identical(path, root) || startsWith(path, prefix))) return(NULL)
  relative <- if (identical(path, root)) "" else substring(path, nchar(prefix) + 1L)
  gsub("\\\\", "/", file.path("..", relative))
}

file_fingerprint <- function(path) {
  if (is.null(path) || !file.exists(path) || !is.finite(file.info(path)$size[[1]])) return("missing")
  paste(unname(tools::md5sum(path)), file.info(path)$size[[1]], sep = ":")
}

discover_ready_records <- function(root) {
  store <- file.path(root, "report_ready")
  if (!dir.exists(store)) return(list())
  if (nzchar(Sys.readlink(store))) stop("The report-ready store cannot be a symbolic link.", call. = FALSE)
  store_real <- normalizePath(store, mustWork = TRUE)
  store_prefix <- paste0(store_real, .Platform$file.sep)
  root_prefix <- paste0(normalizePath(root, mustWork = TRUE), .Platform$file.sep)
  if (!startsWith(paste0(store_real, .Platform$file.sep), root_prefix)) stop("The report-ready store must remain inside the assignment root.", call. = FALSE)
  manifest_paths <- list.files(store, pattern = "^manifest\\.ya?ml$", full.names = TRUE, recursive = TRUE, ignore.case = TRUE)
  if (!length(manifest_paths)) return(list())
  records <- lapply(manifest_paths, function(manifest_path) {
    if (nzchar(Sys.readlink(manifest_path)) || nzchar(Sys.readlink(dirname(manifest_path)))) {
      stop("Report-ready manifests and artifact directories cannot be symbolic links.", call. = FALSE)
    }
    manifest_path <- normalizePath(manifest_path, mustWork = TRUE)
    directory <- normalizePath(dirname(manifest_path), mustWork = FALSE)
    if (!startsWith(manifest_path, store_prefix)) stop("Report-ready manifest escapes the report-ready store.", call. = FALSE)
    relative <- substring(manifest_path, nchar(store_real) + 2L)
    if (!grepl("^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/manifest\\.ya?ml$", relative, perl = TRUE)) {
      stop("Malformed report-ready layout: expected report_ready/<slug>/manifest.yaml.", call. = FALSE)
    }
    directory_slug <- basename(directory)
    manifest_data <- yaml::read_yaml(manifest_path)
    manifest_slug <- normalize_value(manifest_data$slug)
    if (!identical(manifest_slug, directory_slug)) stop("Report-ready manifest slug does not match its directory.", call. = FALSE)
    artifacts <- as.character(unlist(manifest_data$artifacts %||% character(), use.names = FALSE))
    artifact_path <- NULL
    valid_artifact <- FALSE
    if (length(artifacts) > 1L || (length(artifacts) == 1L && (grepl("^[/\\\\]", artifacts[[1]]) || grepl("^[A-Za-z]:", artifacts[[1]])))) {
      stop("Report-ready manifests must name one confined relative artifact path.", call. = FALSE)
    }
    if (length(artifacts) == 1L) {
      candidate <- file.path(directory, artifacts[[1]])
      if (file.exists(candidate) && nzchar(Sys.readlink(candidate))) stop("Report-ready artifacts cannot be symbolic links.", call. = FALSE)
      artifact_path <- normalizePath(candidate, mustWork = FALSE)
      directory_prefix <- paste0(directory, .Platform$file.sep)
      if (!startsWith(artifact_path, directory_prefix) || !startsWith(artifact_path, root_prefix)) {
        stop("Report-ready artifact path escapes its snapshot directory.", call. = FALSE)
      }
      valid_artifact <- file.exists(artifact_path)
    }
    list(
      slug = normalize_value(manifest_data$slug, basename(directory)), directory = directory,
      manifest = manifest_path, artifacts = artifacts, manifest_data = manifest_data,
      valid_artifact = valid_artifact, artifact_path = artifact_path
    )
  })
  records <- Filter(Negate(is.null), records)
  slugs <- vapply(records, function(record) record$slug, character(1))
  if (anyDuplicated(slugs)) stop("Report-ready slugs must be unique.", call. = FALSE)
  records
}

ready_for_asset <- function(asset, ready_records) {
  keys <- c(normalize_value(asset$key), normalize_value(asset$record$manifest_data$slug))
  keys <- keys[nzchar(keys)]
  if (!length(keys)) return(NULL)
  matches <- Filter(function(record) as.character(record$slug) %in% keys, ready_records)
  if (length(matches)) matches[[1]] else NULL
}

frozen_snapshot_hash <- function(manifest_data) {
  if (!is.list(manifest_data)) return("")
  normalize_value(manifest_data$source_object_hash)
}

current_object_hash <- function(asset, root) {
  slug <- normalize_value(asset$key)
  if (!nzchar(slug)) return("")
  analysis <- file.path(root, "analysis", slug)
  object <- file.path(analysis, "object.rds")
  root_real <- normalizePath(root, mustWork = TRUE)
  analysis_real <- normalizePath(analysis, mustWork = FALSE)
  object_real <- normalizePath(object, mustWork = FALSE)
  root_prefix <- paste0(root_real, .Platform$file.sep)
  analysis_prefix <- paste0(analysis_real, .Platform$file.sep)
  if (!startsWith(analysis_real, root_prefix) || !startsWith(object_real, analysis_prefix) ||
      !file.exists(object) || dir.exists(object) || nzchar(Sys.readlink(analysis)) || nzchar(Sys.readlink(object))) return("")
  hash <- unname(tools::md5sum(object))
  if (!is.character(hash) || length(hash) != 1L || !grepl("^[0-9a-f]{32}$", hash)) return("")
  hash
}

render_asset <- function(asset, section, root, ready_records = list()) {
  record <- asset$record; current <- current_manifest(record); ready <- ready_for_asset(asset, ready_records)
  current_values <- record_values(record); ready_values <- record_values(ready)
  current_path <- if (length(current_values$artifacts)) safe_artifact_path(current_values$artifacts[[1]], current_values$directory, root) else NULL
  ready_path <- if (length(ready_values$artifacts)) safe_artifact_path(ready_values$artifacts[[1]], ready_values$directory, root) else NULL
  available <- is_true(asset$available) && !is.null(current_path) && file.exists(current_path)
  artifact_type <- normalize_value(asset$artifact_type, normalize_value(current$artifact_type, "artifact"))
  display_id <- toupper(normalize_value(asset$display_id, normalize_value(current$display_id)))
  title <- normalize_value(asset$title, normalize_value(current$title, "Untitled analysis"))
  updated <- normalize_value(current$updated_at, normalize_value(current$created_at))
  ready_manifest <- if (is.null(ready)) list() else ready$manifest_data %||% list()
  ready_at <- normalize_value(ready_manifest$report_ready_at, normalize_value(ready_manifest$locked_at))
  current_hash <- current_object_hash(asset, root); ready_hash <- frozen_snapshot_hash(ready$manifest_data)
  stale <- FALSE
  if (!is.null(ready) && ready$valid_artifact && nzchar(current_hash) && nzchar(ready_hash)) {
    stale <- !identical(current_hash, ready_hash)
  } else if (!is.null(ready) && ready$valid_artifact && nzchar(ready_hash)) {
    stale <- TRUE
  } else if (!is.null(ready) && ready$valid_artifact && !nzchar(ready_hash) && nzchar(updated) && nzchar(ready_at)) {
    # Legacy snapshots predate source_object_hash; timestamps are retained only
    # for those manifests and never override exact object-hash comparison.
    current_time <- suppressWarnings(as.POSIXct(updated, tz = "UTC")); snapshot_time <- suppressWarnings(as.POSIXct(ready_at, tz = "UTC"))
    stale <- !is.na(current_time) && !is.na(snapshot_time) && current_time > snapshot_time
  }
  status <- if (!available) "unavailable" else if (stale) "stale" else if (!is.null(ready) && ready$valid_artifact) "report-ready" else "current"
  list(
    key = paste0(if (nzchar(display_id)) display_id else "asset", "-", normalize_value(asset$key, "output")),
    visible_id = display_id, title = title, display_title = if (nzchar(display_id)) paste0(display_id, ": ", title) else title,
    section_id = normalize_value(section$id, "unassigned-outputs"), selected = is_true(asset$include_in_report), archived = is_true(asset$archived),
    available = available, artifact_type = artifact_type, status = status,
    current_path = current_path, ready_path = if (!is.null(ready) && ready$valid_artifact) ready_path else NULL, current_href = relative_artifact_path(current_path, root), ready_href = if (!is.null(ready) && ready$valid_artifact) relative_artifact_path(ready_path, root) else NULL,
    current_fingerprint = file_fingerprint(current_path), ready_fingerprint = file_fingerprint(if (!is.null(ready) && ready$valid_artifact) ready_path else NULL),
    manifest_fingerprint = file_fingerprint(current_values$manifest), ready_manifest_fingerprint = file_fingerprint(ready_values$manifest)
  )
}

section_role <- function(section) {
  role <- tolower(normalize_value(section$role, "report"))
  if (role %in% c("unassigned", "fixed")) "unassigned" else "report"
}

projection <- function(layout, sections, root, ready_records = list()) {
  list(schema_version = layout$schema_version %||% 1, revision = layout$revision %||% 0,
    sections = lapply(seq_along(sections), function(index) {
      section <- sections[[index]]
      list(id = normalize_value(section$id, paste0("section-", index)), title = normalize_value(section$title, "Report section"),
        role = section_role(section), include_if_empty = is_true(section$include_if_empty),
        assets = lapply(section$assets %||% list(), function(asset) {
          rendered <- render_asset(asset, section, root, ready_records)
          rendered[c("key", "visible_id", "title", "selected", "archived", "available", "artifact_type", "status", "current_fingerprint", "ready_fingerprint", "manifest_fingerprint", "ready_manifest_fingerprint")]
        }))
    }))
}

render_card <- function(card) {
  id <- html_escape(card$visible_id); title <- html_escape(card$title); key <- html_escape(card$key); section_id <- html_escape(card$section_id)
  statuses <- c(if (card$status == "current") "CURRENT", if (card$status == "report-ready") "REPORT READY", if (card$status == "stale") "STALE", if (card$selected) "IN REPORT", if (!card$available) "UNAVAILABLE")
  status_class <- paste0('status status-', html_escape(card$status), if (card$selected) ' status-in-report' else '')
  status_html <- paste0('<span class="', status_class, '" role="status">', html_escape(paste(statuses, collapse = " · ")), '</span>')
  preview <- if (!card$available || is.null(card$current_href)) {
    '<div class="preview unavailable" role="img" aria-label="Preview unavailable">Preview unavailable</div>'
  } else if (card$artifact_type == "plot") {
    paste0('<img class="preview" src="', html_escape(card$current_href), '" alt="Preview: ', html_escape(card$display_title), '" loading="lazy">')
  } else {
    paste0('<iframe class="preview table-preview" sandbox src="', html_escape(card$current_href), '" title="Preview: ', html_escape(card$display_title), '" loading="lazy"></iframe>')
  }
  noun <- if (card$artifact_type == "plot") "figure" else "table"; downloads <- character()
  if (!is.null(card$current_href) && file.exists(card$current_path)) downloads <- c(downloads, paste0('<a class="download" href="', html_escape(card$current_href), '" download="', html_escape(basename(card$current_path)), '">Download current ', noun, '</a>'))
  if (!is.null(card$ready_href) && file.exists(card$ready_path)) downloads <- c(downloads, paste0('<a class="download report-download" href="', html_escape(card$ready_href), '" download="', html_escape(basename(card$ready_path)), '">Download report-ready ', noun, '</a>'))
  paste0('<article class="card" data-card-key="', key, '" data-visible-id="', id, '" data-section-id="', section_id, '" data-selected="', tolower(card$selected), '" data-archived="', tolower(card$archived), '">',
    '<div class="card-head"><div><p class="card-id">', id, '</p><h3>', title, '</h3><p class="kind">', html_escape(gsub("_", " ", card$artifact_type, fixed = TRUE)), '</p></div><div class="card-statuses">', status_html, '</div></div>',
    '<button type="button" class="collapse-control" aria-expanded="true" aria-controls="preview-', key, '">Collapse preview</button><div id="preview-', key, '" class="card-content">', preview, '<div class="card-foot">', paste(downloads, collapse = ""), '</div></div></article>')
}

css <- function() paste0(
  'body{--gallery-fg:var(--foreground,#202124);--gallery-muted:var(--muted-foreground,#5f6368);--gallery-border:var(--border,#d9dadd);--gallery-bg:var(--background,#f7f7f8);--gallery-surface:var(--card,#ffffff);--gallery-accent:var(--primary,#315f87);--gallery-accent-fg:var(--primary-foreground,#fff);--gallery-accent-soft:#e6edf4;--gallery-warn:#654a08;--gallery-warn-surface:#f6e8bd;--gallery-danger:#702d2a;--gallery-danger-surface:#f0dcda;font-family:Inter,system-ui,sans-serif;color:var(--gallery-fg);background:var(--gallery-bg);color-scheme:light dark}*{box-sizing:border-box}body{max-width:1120px;margin:0 auto;padding:28px 18px 64px;background:var(--gallery-bg);color:var(--gallery-fg)}',
  'header{margin-bottom:22px}h1{font-size:clamp(1.5rem,4vw,2.1rem);margin:0 0 6px;color:var(--gallery-fg)}header p{margin:0;color:var(--gallery-muted)}.counts{display:flex;flex-wrap:wrap;gap:8px;margin:16px 0}.count{padding:6px 10px;border:1px solid var(--gallery-border);border-radius:999px;background:var(--gallery-surface);font-size:.84rem}',
  '.filters{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 26px}.filter{border:1px solid var(--gallery-border);border-radius:7px;background:var(--gallery-surface);color:var(--gallery-fg);padding:9px 13px;font:inherit;cursor:pointer}.filter[aria-pressed=\"true\"]{background:var(--gallery-accent);color:var(--gallery-accent-fg);border-color:var(--gallery-accent)}',
  '.report-section{margin:28px 0}.section-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px;border-bottom:1px solid var(--gallery-border);padding-bottom:7px}.section-head h2{font-size:1.25rem;margin:0}.section-count{font-size:.8rem;color:var(--gallery-muted)}.diagnostic{font-size:.86rem;color:var(--gallery-warn);margin:7px 0}',
  '.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:14px;margin-top:14px}.card{background:var(--gallery-surface);border:1px solid var(--gallery-border);border-radius:10px;padding:15px;min-width:0}.card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}.card-id{font-size:.76rem;font-weight:750;letter-spacing:.05em;color:var(--gallery-muted);margin:0 0 3px}.card h3{font-size:1rem;line-height:1.25;margin:0;overflow-wrap:anywhere}.kind{text-transform:capitalize;font-size:.78rem;color:var(--gallery-muted);margin:4px 0 0}',
  '.card-statuses{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:4px}.status{white-space:nowrap;font-size:.68rem;font-weight:750;letter-spacing:.03em;padding:4px 7px;border-radius:999px;border:1px solid transparent;background:var(--gallery-accent-soft);color:#284e70}.status-current{background:var(--gallery-accent-soft);color:#284e70;border-color:#a9ccd7}.status-report-ready{background:#deeee2;color:#245b36;border-color:#afd0b8}.status-in-report{border-color:#4f8291}.status-stale{background:var(--gallery-warn-surface);color:var(--gallery-warn);border-color:#d4b96c}.status-unavailable{background:var(--gallery-danger-surface);color:var(--gallery-danger);border-color:#d0aaa6}.collapse-control{margin-top:12px;border:0;background:transparent;color:var(--gallery-accent);padding:4px 0;font:inherit;font-size:.82rem;cursor:pointer}.card-content{margin-top:8px}.card.is-collapsed .card-content{display:none}',
  '.preview{display:block;width:100%;max-width:100%;height:auto;min-height:40px;object-fit:contain;background:var(--gallery-surface);border-radius:6px}.table-preview{height:260px;border:0}.preview.unavailable{display:grid;place-items:center;min-height:100px;background:var(--gallery-bg);color:var(--gallery-muted);font-size:.88rem}.card-foot{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;padding-top:11px;border-top:1px solid var(--gallery-border)}.download{display:inline-block;white-space:nowrap;background:var(--gallery-accent);color:var(--gallery-accent-fg);text-decoration:none;font-size:.78rem;font-weight:650;padding:8px 10px;border-radius:7px}.download:hover,.filter:hover:not(:disabled),.collapse-control:hover{filter:brightness(.92)}.empty{color:var(--gallery-muted);font-size:.88rem;padding:12px 0}.hidden{display:none!important}',
  'button:disabled,select:disabled,input:disabled{opacity:.55;cursor:not-allowed}.filter:focus-visible,.download:focus-visible,.collapse-control:focus-visible{outline:3px solid var(--gallery-accent);outline-offset:2px}@media(max-width:500px){body{padding:20px 12px 48px}.card-head{display:block}.card-statuses{justify-content:flex-start;margin-top:8px}.download{white-space:normal}.section-head{display:block}.section-count{display:block;margin-top:4px}}@media(prefers-color-scheme:dark){body{--gallery-fg:var(--foreground,#f4f4f5);--gallery-muted:var(--muted-foreground,#b4b4bc);--gallery-border:var(--border,#494951);--gallery-bg:var(--background,#18181b);--gallery-surface:var(--card,#242428);--gallery-accent:var(--primary,#8ab4f8);--gallery-accent-fg:var(--primary-foreground,#111827);--gallery-accent-soft:#35404a;--gallery-warn-surface:#4a4124;--gallery-warn:#f0d88b;--gallery-danger-surface:#4a3030;--gallery-danger:#f0b7b1}.status{color:#d7e5f5}.status-current{color:#d7e5f5;border-color:#4c7d89}.status-report-ready{background:#294736;color:#c8e7ce;border-color:#5f9670}.status-stale{border-color:#9c8442}.status-unavailable{border-color:#96615d}}'
)

refresh_js <- function(token) paste0(
  '(function(){"use strict";const pageToken=', js_string(token), ';const stateKey="analysis-gallery:"+window.location.pathname;const filters=["all","in-report","not-in-report","archived"];let view={filter:"all",collapsed:{},scroll:null};',
  'function read(){try{const value=window.sessionStorage.getItem(stateKey);if(value)view=Object.assign(view,JSON.parse(value));}catch(_){}}function write(){try{window.sessionStorage.setItem(stateKey,JSON.stringify(view));}catch(_){}}',
  'function mode(card,filter){const archived=card.dataset.archived==="true",selected=card.dataset.selected==="true";if(filter==="archived")return archived;if(archived)return false;if(filter==="in-report")return selected;if(filter==="not-in-report")return !selected;return true;}',
  'function apply(){const filter=filters.includes(view.filter)?view.filter:"all";view.filter=filter;document.querySelectorAll(".filter").forEach(function(button){button.setAttribute("aria-pressed",String(button.dataset.filter===filter));});document.querySelectorAll(".report-section").forEach(function(section){const role=section.dataset.role;let visible=0,selectedVisible=0;section.querySelectorAll(".card").forEach(function(card){const show=mode(card,filter);card.classList.toggle("hidden",!show);if(show){visible++;if(card.dataset.selected==="true")selectedVisible++;}});const showSection=filter==="all"?true:(filter==="in-report"?(role==="report"||visible>0):visible>0);section.classList.toggle("hidden",!showSection);section.querySelector(".section-count").textContent=visible+" "+(visible===1?"output":"outputs");const title=section.querySelector(".section-title");if(title)title.textContent=(role==="unassigned"&&filter==="in-report")?"Needs placement":title.dataset.canonical;const diagnostic=section.querySelector(".diagnostic");if(diagnostic)diagnostic.classList.toggle("hidden",!(role==="unassigned"&&(filter==="all"||filter==="in-report")&&selectedVisible>0));});document.querySelectorAll(".card").forEach(function(card){const key=card.dataset.cardKey,collapsed=Boolean(view.collapsed&&view.collapsed[key]);card.classList.toggle("is-collapsed",collapsed);const button=card.querySelector(".collapse-control");if(button){button.setAttribute("aria-expanded",String(!collapsed));button.textContent=collapsed?"Expand preview":"Collapse preview";}});}',
  'window.addEventListener("DOMContentLoaded",function(){document.querySelectorAll(".filter").forEach(function(button){button.onclick=function(){view.filter=button.dataset.filter;write();apply();};});document.querySelectorAll(".collapse-control").forEach(function(button){button.onclick=function(){const card=button.closest(".card"),key=card.dataset.cardKey;view.collapsed=view.collapsed||{};view.collapsed[key]=!card.classList.contains("is-collapsed");write();apply();};});read();apply();});',
  'window.addEventListener("load",function(){if(view.scroll!==null)window.requestAnimationFrame(function(){window.scrollTo(0,Number(view.scroll));view.scroll=null;write();});});function reloadFor(token){if(!token||token===pageToken)return;try{view.scroll=window.scrollY;write();}catch(_){}window.location.reload();}function check(){if(document.hidden)return;const probe=document.createElement("script");probe.src="analysis-version.js?checked="+Date.now();probe.onload=function(){probe.remove();reloadFor(window.__analysisLatestVersion);};probe.onerror=function(){probe.remove();};document.head.appendChild(probe);}window.setInterval(check,1500);document.addEventListener("visibilitychange",check);})();'
)

render_page <- function(layout, root) {
  ready_records <- discover_ready_records(root)
  sections <- layout$sections %||% list()
  if (!any(vapply(sections, function(section) section_role(section) == "unassigned", logical(1)))) sections[[length(sections) + 1L]] <- list(id = "unassigned-outputs", title = "Unassigned", role = "unassigned", include_if_empty = TRUE, assets = list())
  sections <- c(Filter(function(section) section_role(section) != "unassigned", sections), Filter(function(section) section_role(section) == "unassigned", sections))
  rendered_cards <- lapply(seq_along(sections), function(index) lapply(sections[[index]]$assets %||% list(), function(asset) render_asset(asset, sections[[index]], root, ready_records)))
  section_html <- vapply(seq_along(sections), function(index) {
    section <- sections[[index]]; section_id <- html_escape(normalize_value(section$id, paste0("section-", index))); title <- html_escape(normalize_value(section$title, "Report section")); role <- section_role(section); cards <- rendered_cards[[index]]
    body <- if (length(cards)) paste(vapply(cards, render_card, character(1)), collapse = "") else '<p class="empty">No outputs in this section.</p>'
    initial_count <- sum(vapply(cards, function(card) !card$archived, logical(1))); selected_initial <- sum(vapply(cards, function(card) !card$archived && card$selected, logical(1))); diagnostic_class <- if (role == "unassigned" && selected_initial > 0L) "diagnostic" else "diagnostic hidden"
    paste0('<section class="report-section" data-section-id="', section_id, '" data-role="', role, '" data-include="', tolower(is_true(section$include_if_empty)), '"><div class="section-head"><h2 class="section-title" data-canonical="', title, '">', title, '</h2><span class="section-count" aria-live="polite">', initial_count, ' ', if (initial_count == 1L) 'output' else 'outputs', '</span></div><p class="', diagnostic_class, '">Selected output needs placement in a report section.</p><div class="cards">', body, '</div></section>')
  }, character(1))
  cards <- unlist(rendered_cards, recursive = FALSE); active <- sum(vapply(cards, function(card) !card$archived, logical(1))); selected <- sum(vapply(cards, function(card) !card$archived && card$selected, logical(1))); archived <- sum(vapply(cards, function(card) card$archived, logical(1)))
  projected <- projection(layout, sections, root, ready_records); projected$counts <- list(active = active, selected = selected, archived = archived)
  token_stage <- tempfile("analysis-token-"); on.exit(unlink(token_stage, force = TRUE), add = TRUE); writeLines(json_text(projected), token_stage, useBytes = TRUE); token <- unname(tools::md5sum(token_stage))
  page <- paste0('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="analysis-token" content="', token, '"><title>Analysis output</title><style>', css(), '</style><script src="analysis-version.js"></script><script>', refresh_js(token), '</script></head><body><header><h1>Analysis output</h1><p>Requested statistical output, organized for report selection.</p><div class="counts" aria-label="Output counts"><span class="count">Active: ', active, '</span><span class="count">Selected: ', selected, '</span><span class="count">Archived: ', archived, '</span></div><nav class="filters" aria-label="Output filters"><button type="button" class="filter" data-filter="all" aria-pressed="true">All</button><button type="button" class="filter" data-filter="in-report" aria-pressed="false">In report</button><button type="button" class="filter" data-filter="not-in-report" aria-pressed="false">Not in report</button><button type="button" class="filter" data-filter="archived" aria-pressed="false">Archived</button></nav></header>', paste(section_html, collapse = ""), '</body></html>')
  list(page = page, token = token, projection = projected)
}

# Core transaction contract: introstat_begin_replace_file(staged, target)
# returns an object exposing commit() and rollback().
publish <- function(rendered, root, begin_replace) {
  generated <- file.path(root, "generated"); dir.create(generated, recursive = TRUE, showWarnings = FALSE)
  html_target <- file.path(generated, "analysis.html"); version_target <- file.path(generated, "analysis-version.js")
  html_stage <- tempfile("analysis-", tmpdir = generated, fileext = ".html"); version_stage <- tempfile("analysis-version-", tmpdir = generated, fileext = ".js")
  on.exit(unlink(c(html_stage, version_stage), force = TRUE), add = TRUE)
  writeLines(rendered$page, html_stage, useBytes = TRUE); writeLines(paste0("window.__analysisLatestVersion = ", js_string(rendered$token), ";"), version_stage, useBytes = TRUE)
  html_tx <- begin_replace(html_stage, html_target); version_tx <- NULL; rollback_armed <- TRUE
  on.exit(if (rollback_armed) { if (!is.null(version_tx)) try(version_tx$rollback(), silent = TRUE); try(html_tx$rollback(), silent = TRUE) }, add = TRUE)
  version_tx <- begin_replace(version_stage, version_target)
  html_tx$commit(); version_tx$commit(); rollback_armed <- FALSE
  invisible(rendered$token)
}

main <- function(root = NULL) {
  if (is.null(root)) root <- introstat_root(); root <- normalizePath(root, mustWork = TRUE)
  core <- new.env(parent = environment())
  sys.source(file.path(root, "R", "workspace_lock.R"), envir = core); sys.source(file.path(root, "R", "analysis_board.R"), envir = core)
  outline_path <- file.path(root, "report_outline.yaml")
  core$introstat_with_workspace_lock(root, function() { board <- core$introstat_sync_analysis_board_unlocked(root, outline_path = outline_path); layout <- core$introstat_analysis_board_layout(board, root); rendered <- render_page(layout, root); publish(rendered, root, core$introstat_begin_replace_file); cat("Rendered generated/analysis.html\n"); invisible(list(operation = "refresh_gallery", artifact_count = sum(vapply(rendered$projection$sections, function(section) length(section$assets), integer(1))), token = rendered$token)) })
}

args <- commandArgs(trailingOnly = TRUE); root_hit <- which(args == "--root"); root_arg <- if (length(root_hit) && root_hit[[1]] < length(args)) args[[root_hit[[1]] + 1L]] else getwd(); log_root <- normalizePath(root_arg, mustWork = TRUE)
source(file.path(log_root, "R", "harness_io.R"), local = globalenv()); source(file.path(log_root, "R", "harness_log.R"), local = globalenv()); introstat_run_workflow(log_root, "analysis_page_render", main(log_root))
