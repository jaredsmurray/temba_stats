#!/usr/bin/env Rscript

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  value_after <- function(flag, default = NULL) {
    hit <- which(args == flag)
    if (!length(hit)) return(default)
    if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
    args[[hit[[1]] + 1L]]
  }

  root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
  source(file.path(root, "R", "harness_utils.R"))
  source(file.path(root, "R", "harness_io.R"))
  source(file.path(root, "R", "workspace_lock.R"))
  source(file.path(root, "R", "analysis_board.R"))
  source(file.path(root, "R", "report_runtime.R"))
  source(file.path(root, "R", "report_snapshots.R"))

  query <- value_after("--analysis")
  if (is.null(query) || !nzchar(trimws(query))) {
    stop("Use --analysis <visible ID, slug, or title>.", call. = FALSE)
  }
  number <- function(flag) {
    value <- value_after(flag)
    if (is.null(value)) return(NULL)
    value <- suppressWarnings(as.numeric(value))
    if (length(value) != 1L || is.na(value) || !is.finite(value) || value <= 0) {
      stop(flag, " must be a finite positive number.", call. = FALSE)
    }
    value
  }
  tag_value <- value_after("--tags")
  tags <- if (is.null(tag_value)) NULL else trimws(strsplit(tag_value, ",", fixed = TRUE)[[1]])
  if (!is.null(tags)) tags <- as.list(tags[nzchar(tags)])
  metadata <- list(
    title = value_after("--title"),
    problem = value_after("--problem"),
    question = value_after("--question"),
    section_id = value_after("--section"),
    tags = tags,
    width = number("--width"),
    height = number("--height"),
    report_order = number("--order")
  )
  metadata <- metadata[!vapply(metadata, is.null, logical(1))]
  replace <- "--replace" %in% args
  stage <- NULL
  transaction <- NULL
  slug <- NULL

  introstat_with_workspace_lock(root, function() {
    on.exit({
      if (!is.null(transaction)) try(transaction$rollback(), silent = TRUE)
      if (!is.null(stage) && dir.exists(stage)) unlink(stage, recursive = TRUE, force = TRUE)
    }, add = TRUE)
    report_ready_root <- file.path(root, "report_ready")
    if (introstat_is_symlink(report_ready_root)) stop("The report-ready store cannot be a symbolic link.", call. = FALSE)
    dir.create(report_ready_root, recursive = TRUE, showWarnings = FALSE)
    board <- introstat_sync_analysis_board_unlocked(root)
    slug <<- introstat_board_resolve(board, query)
    target <- file.path(report_ready_root, slug)
    if ((dir.exists(target) || introstat_is_symlink(target)) && !replace) {
      stop("A report-ready snapshot already exists; use --replace after reviewing it.", call. = FALSE)
    }
    metadata$existing <- if (dir.exists(target) && file.exists(file.path(target, "manifest.yaml"))) {
      yaml::read_yaml(file.path(target, "manifest.yaml"))
    } else {
      list()
    }
    stage <<- introstat_snapshot_stage(root, board, slug, metadata)
    transaction <<- introstat_begin_replace_dir(stage, target)
    transaction$commit()
    stage <<- NULL
    transaction <<- NULL
  })

  render_error <- tryCatch({
    source(file.path(root, "scripts", "render_analysis.R"), local = new.env(parent = globalenv()))
    NULL
  }, error = identity)
  if (!is.null(render_error)) warning("saved; page refresh failed: ", conditionMessage(render_error), call. = FALSE)
  final <- yaml::read_yaml(file.path(root, "report_ready", slug, "manifest.yaml"))
  cat("Marked report ready: ", final$title, "\n", sep = "")
  cat("Artifact: ", file.path("report_ready", slug, final$artifacts[[1]]), "\n", sep = "")
  cat("Reproduction script: ", file.path("report_ready", slug, "reproduce.R"), "\n", sep = "")
  invisible(list(
    artifact_id = final$display_id,
    artifact_type = final$artifact_type,
    operation = if (replace) "replace" else "create"
  ))
}

log_args <- commandArgs(trailingOnly = TRUE)
root_hit <- which(log_args == "--root")
log_root <- if (length(root_hit) && root_hit[[1]] < length(log_args)) log_args[[root_hit[[1]] + 1L]] else getwd()
log_root <- normalizePath(log_root, mustWork = TRUE)
source(file.path(log_root, "R", "harness_log.R"))
introstat_run_workflow(log_root, "report_ready", main())
