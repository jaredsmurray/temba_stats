#!/usr/bin/env Rscript

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  value_after <- function(flag, default = NULL) {
    hit <- which(args == flag)
    if (!length(hit)) return(default)
    if (hit[[1]] == length(args)) stop("Missing value after ", flag, call. = FALSE)
    args[[hit[[1]] + 1L]]
  }
  if (!"--apply" %in% args) stop("Compilation requires --apply and --render-token.", call. = FALSE)
  token <- value_after("--render-token")
  if (is.null(token) || !grepl("^[0-9a-f]{32}$", token, perl = TRUE)) {
    stop("--render-token must be a lowercase 32-character MD5 token.", call. = FALSE)
  }

  root <- normalizePath(value_after("--root", getwd()), mustWork = TRUE)
  output <- value_after("--output", file.path(root, "reports", "report_skeleton.docx"))
  plan_path <- file.path(root, "generated", "report_plan.yaml")
  source(file.path(root, "R", "workspace_lock.R"))
  source(file.path(root, "R", "analysis_board.R"))
  source(file.path(root, "R", "report_store.R"))
  source(file.path(root, "R", "report_runtime.R"))

  result <- introstat_with_workspace_lock(root, function() {
    analysis_root <- introstat_validate_analysis_root(root, create = FALSE)
    board_path <- file.path(analysis_root, "board.yaml")
    if (!file.exists(board_path) || dir.exists(board_path) || introstat_is_symlink(board_path)) {
      stop("Missing or linked analysis board.", call. = FALSE)
    }
    if (!file.exists(plan_path) || dir.exists(plan_path) || introstat_is_symlink(plan_path) || introstat_is_symlink(dirname(plan_path))) {
      stop("Missing or linked prepared report plan.", call. = FALSE)
    }
    if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
    board <- yaml::read_yaml(board_path)
    introstat_board_validate(board)
    plan <- yaml::read_yaml(plan_path)
    checked <- introstat_validate_prepared_plan(plan, root, board)
    plan <- checked$plan
    if (!identical(token, plan$render_token)) stop("--render-token does not match the prepared plan.", call. = FALSE)

    records <- checked$records
    by_id <- stats::setNames(records, vapply(records, `[[`, character(1), "display_id"))
    specs <- lapply(plan$snapshots, function(snapshot) {
      record <- by_id[[snapshot$display_id]]
      data <- record$manifest_data
      list(
        display_id = snapshot$display_id,
        slug = snapshot$slug,
        object_data = record$object_data,
        title = data$title,
        artifact_type = data$artifact_type,
        width = data$width %||% NULL,
        height = data$height %||% NULL,
        problem = data$problem %||% NULL,
        question = data$question %||% NULL
      )
    })
    for (section in plan$sections) {
      for (display_id in section$artifacts) {
        hit <- which(vapply(specs, function(spec) identical(spec$display_id, display_id), logical(1)))
        specs[[hit]]$section_id <- section$section_id
        specs[[hit]]$section_title <- section$title
      }
    }
    sections <- lapply(plan$sections, function(section) list(
      id = section$section_id,
      title = section$title,
      include_if_empty = section$include_if_empty
    ))

    if (file.exists(output) || dir.exists(output) || introstat_is_symlink(output)) {
      stop("Report already exists; it will not be overwritten: ", output, call. = FALSE)
    }
    output_parent <- dirname(output)
    if (introstat_is_symlink(output_parent)) stop("The report output directory cannot be a symbolic link.", call. = FALSE)
    dir.create(output_parent, recursive = TRUE, showWarnings = FALSE)
    stage_output <- tempfile(".compiled-report-", tmpdir = output_parent, fileext = ".docx")
    on.exit(unlink(stage_output, force = TRUE), add = TRUE)
    items <- lapply(specs, introstat_load_frozen_report_artifact)
    introstat_write_compiled_report(
      items,
      output = stage_output,
      title = plan$title,
      subtitle = plan$subtitle,
      sections = sections,
      frozen = TRUE
    )
    introstat_install_file_noclobber(stage_output, output)
    list(output = normalizePath(output, mustWork = TRUE), artifact_count = length(specs))
  })

  cat("Built ", result$output, "\n", sep = "")
  invisible(list(operation = "compile", artifact_count = result$artifact_count))
}

log_args <- commandArgs(trailingOnly = TRUE)
root_hit <- which(log_args == "--root")
log_root <- if (length(root_hit) && root_hit[[1]] < length(log_args)) log_args[[root_hit[[1]] + 1L]] else getwd()
log_root <- normalizePath(log_root, mustWork = TRUE)
source(file.path(log_root, "R", "harness_log.R"))
introstat_run_workflow(log_root, "report_compile", main())
