# TEMBA 2026 in-class demo

This private instructor demo workspace uses IntroStatGPT source
`9c594e7e8f975fb7b585240b5a6e596bd2e77504`.

It contains seven canonical datasets selected for the currently rendered
course material:

- full Austin housing listings;
- asset price history;
- full 2023 CPS ASEC earnings extract;
- full LendingClub teaching extract; and
- full 2025 SHED extract;
- Bloom, Han, and Liang employee attrition data; and
- Bloom, Han, and Liang productivity-perceptions data.

`R/problem_setup.R` loads these as `austin_houses`, `returns_prices`,
`cps_earnings`, `lending_club`, `shed`, `bloom_attrition`, and
`bloom_perceptions`. It also derives `returns` from the adjusted price columns.
Arithmetic returns are expressed in percentage points, so a value of `1` means
a 1% return. The perceptions file contains nine ordered response categories;
analyses that plot them should supply the intended order explicitly.

Open this folder as a Codex project. Ask for an analysis, then ask to open the
analysis gallery or organizer.

This package is for the private in-class demonstration. Austin housing,
LendingClub, and returns data do not have clearly established unrestricted
redistribution rights.
