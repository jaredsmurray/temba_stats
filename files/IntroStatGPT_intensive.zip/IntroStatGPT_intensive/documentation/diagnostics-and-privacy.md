# Diagnostics and privacy

The student diagnostic profile records the duration and success or failure of
harness operations such as creating an analysis, refreshing the analysis page,
marking output report ready, compiling a report, and exporting R code. These
entries identify the artifact type and use broad error categories without
storing source code, commands, paths, or raw error messages.

It does not record prompts, assistant responses, internal reasoning, tool
payloads, shell commands, patches, attached data, generated figures or tables,
or absolute account paths.

Diagnostics remain under `generated/diagnostics/` on your computer. Nothing is
uploaded automatically. Delete the `.intro-stat-gpt-diagnostics` marker to stop
new records, or delete the diagnostics directory to remove existing records.

If you choose to share diagnostics, ask Codex to prepare them. It creates a
local review folder and zip. Inspect every file before sending it. R source is
excluded unless you explicitly approve a particular script.
