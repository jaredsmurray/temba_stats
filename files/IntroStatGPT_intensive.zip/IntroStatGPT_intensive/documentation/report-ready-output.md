# Report-ready output

Report preparation preserves the selected current versions for compilation. It
is not Codex’s judgment that an analysis is correct.

Identify output by its visible title. The harness stores the rendered figure or
table, its canonical R object, metadata, and a standalone `reproduce.R` script.
Working output can continue to change without silently replacing a frozen
snapshot. The reproduction script is provided for download and later
reproduction; it is not run during report preparation or compilation.

Use the organizer to place outputs in report sections and select them for the
report. Preparation freezes all selected active outputs together and gives you
one render token to approve before compilation. An included output in
**Unassigned** must be placed in a report section first.

Figures use consistent, readable dimensions. Regression tables use the course
modelsummary-based format and avoid scientific notation. Tables and figures are
numbered separately when a Word skeleton is compiled.
