# Compiling and exporting

Ask Codex to prepare your report after you have created the analyses you want
to preserve. The organizer shows the live gallery and report headings. Arrange
outputs by their visible labels, choose which ones to include, and apply the
complete arrangement through the conversation. The agent validates the change
and updates the board as one revision.

Preparation then freezes every selected active output, checks the arrangement,
and prints a reader-centered section summary with one render token. Selected
outputs left in **Unassigned** must be placed in a report section before
preparation can finish. A headings-only report is valid when an ordinary heading
is configured to remain when empty.

Review the summary and explicitly approve its render token. Compilation begins
only after that approval. If the board or a frozen output changes later, prepare
the report again and approve its new token.

The generated Word document contains only frozen statistical output and blank
space for your writing. It does not include R code or AI-written interpretation
and it never overwrites an existing report.

To obtain code, ask for the R script reproducing a visible output. Ask for
“detailed teaching comments” if you want function arguments explained.
