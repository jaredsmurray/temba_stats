# Prompting for data analysis

Good prompts specify the mechanical analysis while leaving the interpretation
to you. Include the variables, population or filter, calculation or model,
grouping, and desired display when they matter.

Examples:

- “Fit hourly wage on years of education and experience.”
- “Compare these two named regression models in one table.”
- “Make side-by-side boxplots of home age by ZIP code.”
- “Calculate median price by number of bedrooms and return a table.”
- “Plot residuals against fitted values for the current model.”
- “Change the horizontal axis label to Home age (years).”

You may explore freely. The analysis does not need to correspond to a named
assignment part. If you mention only “problem 2e,” Codex may ask what analysis
you want rather than choosing it for you.

Codex will decline requests such as “What does this mean?”, “What should I
conclude?”, or “Write my answer.” You may instead ask it to calculate or display
the quantities you need for your own reasoning.

Keep requests for output separate from interpretation or report writing. If a
fully specified prompt combines them, IntroStatGPT can create the requested
output but will leave its interpretation and the writing to you. If the output
itself is not specific enough to create, it will ask what your course requires.

## If an allowable request is refused

Some words have both mechanical and interpretive meanings. For example,
“interpret ZIP code as categorical” asks for a data-type operation, while
“interpret these regression results” asks for a substantive explanation.

First, replace the ambiguous word when a direct mechanical term works: “Treat
ZIP code as categorical and plot price by ZIP code.” You can also challenge an
apparent false positive:

> I am asking for a mechanical data operation, not interpretation of results.
> Identify the ambiguous wording and restate or confirm the same operation
> without choosing an analysis for me.

This clarification can repair wording, but it cannot turn a request for an
analysis choice, interpretation, conclusion, or report prose into an allowable
request.

If regression output appears as raw console text, say: “Recreate that as the
standardized regression table.”
