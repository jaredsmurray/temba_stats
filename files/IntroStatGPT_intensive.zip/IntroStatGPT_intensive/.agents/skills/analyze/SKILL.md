---
name: analyze
description: Create or revise a fully specified statistical plot, table, model output, diagnostic, or calculation without interpreting it. Invoke only after the student has named every substantive statistical choice needed to run the request. Do not invoke for an underspecified comparison, test, interval, model, or bare request for “diagnostics”; handle those directly with the neutral clarification in AGENTS.md. Never choose or suggest the analysis; ordinary presentation and storage defaults are allowed.
---

# Analyze data without interpretation

Before running anything, confirm that the student has specified the operation.
If a substantive method, test, model, diagnostic, variable, estimand, or
inferential procedure still has to be chosen, do not choose it and do not list
options. Ask one short, neutral question using the clarification language in
`AGENTS.md`. If the student then
says “pick one,” “you decide,” or equivalent, repeat the short boundary response
from `AGENTS.md`. Create no artifact on either turn.

A bare request for “diagnostics” is not a statistical-analysis request. Ask
whether the student means the local activity record for troubleshooting or a
specific statistical check already named in the assignment. Do not name a menu
of statistical checks.

For a requested plot, table, model output, or saved calculation, generate an R
expression whose final value is the requested artifact and submit it once:

```bash
Rscript scripts/submit_analysis.R <slug> --title "<display title>" <<'INTROSTAT_R'
<R expression>
INTROSTAT_R
```

For a regression, the final expression must be `make_reg_table(lm(...))` (or
`make_reg_table()` applied to a named model list for a comparison). Never submit
a raw `lm` object as the finished artifact.

For a specifically requested numerical scalar, submit
`make_value_table("<descriptive statistic>", <computed value>)`. Save a new
artifact whenever the statistic, interval method, model, variables, population,
filter, transformation, or diagnostic changes. Reuse an existing artifact only
for presentation changes such as labels, color, dimensions, or layout, so an
earlier computation remains available for later report selection. Add
`--replace` to the submission command only for such a presentation revision;
an unmarked overwrite is rejected.

Reuse the visible artifact's existing slug for revisions. The script supplies
the assignment setup, saves reproducible source, validates the result, and
refreshes the review page. For a plot, embed the absolute `Chat preview` path as
a Markdown image and identify it using the submitted `Plot ID`, such as
`P4: Residuals versus fitted values`. When a request explicitly names a plot ID,
submit the revised expression using `Rscript scripts/submit_analysis.R
--analysis P4`; the script resolves and replaces the existing artifact.
Requested additions such as smoothers or reference lines revise that plot in
place. For a table, reproduce the generated Markdown between the
chat-table markers exactly; retain the PNG as an optional fallback. Then use the
absolute page path in a clickable Markdown link whose target is enclosed in
angle brackets so paths containing spaces remain clickable. Follow the interpretation and
report-writing boundaries in `AGENTS.md`; do not add analyses the student did
not request.
