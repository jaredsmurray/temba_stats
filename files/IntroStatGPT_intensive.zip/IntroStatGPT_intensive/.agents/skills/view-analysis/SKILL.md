---
name: view-analysis
description: Open or reopen the live static HTML analysis gallery after analysis, board, or report changes. Use for student requests such as “show me the analysis view,” “show me the html gallery,” “open the gallery,” “reopen the gallery,” or “in the sidebar.”
---

# View the analysis gallery

From the assignment root, refresh the static gallery:

```sh
Rscript scripts/render_analysis.R --root "$(pwd)"
```

Treat a nonzero renderer exit as a failure. After a successful exit, require
`generated/analysis.html` to exist, then compute and verify its absolute path:

```sh
gallery_path="$(cd generated && pwd -P)/analysis.html"
test -f "$gallery_path"
```

Do not claim to have opened or displayed the page if either check fails.

Return one short operational sentence with the actual absolute path as a
clickable Markdown link, using this exact link label:

> The analysis page is ready. [Open the analysis page](</absolute/path/to/generated/analysis.html>).

Replace the placeholder target with the verified absolute path. Always enclose
the link target in angle brackets so paths containing spaces remain clickable,
for example `[Open the analysis page](</absolute/path/with spaces/generated/analysis.html>)`.
Keep the link as Markdown; do not put the path in inline code. This workflow opens the
existing read-only gallery only. Do not create an analysis, use a browser,
conversation visualizer, editor, right pane, raw source, local server, or
another display workaround. Preserve visible artifact titles and the
no-interpretation boundary.
