#!/usr/bin/env python3
"""Create a reviewable diagnostics bundle only after an explicit request."""

import argparse
from datetime import datetime, timezone
from pathlib import Path
import shutil
import zipfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--include-r-source", action="append", default=[])
    args = parser.parse_args()
    root = Path.cwd()
    source = root / "generated" / "diagnostics"
    workflow_log = source / "workflow.jsonl"
    logs = [workflow_log] if workflow_log.is_file() else []
    if not logs:
        raise SystemExit("No local workflow diagnostics are available.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    review = root / "generated" / f"diagnostics-review-{stamp}"
    review.mkdir(parents=True, exist_ok=False)
    for log in logs:
        shutil.copy2(log, review / log.name)
    included = []
    for raw in args.include_r_source:
        path = (root / raw).resolve()
        if root.resolve() not in path.parents or path.suffix.lower() != ".r" or not path.is_file():
            raise SystemExit(f"R source must be an existing .R file inside the assignment: {raw}")
        target = review / "optional-r-source" / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        included.append(str(path.relative_to(root.resolve())))
    (review / "REVIEW_BEFORE_SHARING.txt").write_text(
        "This bundle was created only because diagnostics sharing was requested.\n"
        "Review every file before sending it. Nothing has been uploaded.\n"
        "The workflow log contains timing, status, broad error categories, and limited\n"
        "artifact metadata. It omits prompts, responses, commands, paths, and raw errors.\n"
        + ("Included R source: " + ", ".join(included) + "\n" if included else "No R source was included.\n"),
        encoding="utf-8",
    )
    archive = review.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(review.rglob("*")):
            if path.is_file():
                bundle.write(path, path.relative_to(review.parent))
    print(archive)


if __name__ == "__main__":
    main()
