---
name: share-diagnostics
description: Review and prepare the locally stored statistical-harness activity record for optional sharing. Use only when the student explicitly asks for a local activity, usage, task, harness, troubleshooting, or sharing record or bundle. A bare request for “diagnostics” is ambiguous and must not invoke this skill. Do not use for model, residual, regression, or other statistical diagnostics. Never upload or transmit the result automatically.
---

# Share diagnostics

This workflow concerns local activity and troubleshooting records, not
statistical model checks. If “diagnostics” is ambiguous, use the one-question
clarification in `AGENTS.md` before running this workflow.

1. Explain that the bundle contains workflow timing, success or failure status,
   broad error categories, and artifact metadata, and remains local. It does not
   contain prompts or assistant responses.
2. Ask whether the student wants to include a specific malformed R analysis source. Default to no R source.
3. Run `python3 .agents/skills/share-diagnostics/scripts/bundle_diagnostics.py`. Add one `--include-r-source <path>` only for each source file the student explicitly approves.
4. Report the review-directory and zip paths. Tell the student to inspect them before sharing.
5. Do not send, upload, email, or otherwise transmit the bundle.
