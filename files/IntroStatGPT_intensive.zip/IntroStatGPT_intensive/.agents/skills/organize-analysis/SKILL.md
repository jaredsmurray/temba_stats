---
name: organize-analysis
description: Organize saved analysis outputs into report sections and send one revision-bound placement request to Codex through the conversation visualizer.
---

# Organize analysis outputs

Run the deterministic organizer renderer from the assignment root:

```bash
Rscript scripts/render_analysis_organizer.R --root "$(pwd)"
```

The renderer prints the generated file's absolute path to stdout after a
successful run. Capture stdout, take its final non-empty line as the
`organizer_path`, and verify that it is an absolute path ending in
`generated/analysis-organizer.html` and that the file exists.

On success, make the final response exactly one host content reference on its
own line, outside any code fence. Replace the placeholder with the actual
absolute path captured from stdout:

visualize{"path":"<absolute stdout path>"}

The host reference is the display action. Do not open the HTML in an editor,
right pane, or browser; do not return a Markdown file link; and do not treat a
file-open action as display. If rendering, path validation, or host-reference
emission fails, report the failure and do not claim that the organizer opened
or was displayed.

The organizer keeps changes in browser state until the student selects Apply.
Apply sends one `INTROSTAT_ANALYSIS_ORGANIZER_PAYLOAD_V1` JSON payload containing
the board revision, sections, included visible IDs, and archived visible IDs.

When a follow-up message contains that marker, treat the student's Apply click
as authorization to update the board. Extract the single JSON block unchanged
to a temporary file outside the assignment, then run:

```bash
Rscript scripts/update_analysis_board.R --payload <temporary-json-path> --root "$(pwd)"
```

The script validates the complete payload and current revision before writing.
Do not edit `analysis/board.yaml` directly. Remove the temporary payload after
the command, and surface stale-revision or validation errors without retrying
or partially applying the request. On success, read the saved revision from
the update output (`Updated analysis board to revision N.`), rerun the static
gallery renderer:

```bash
Rscript scripts/render_analysis.R --root "$(pwd)"
```

Require `generated/analysis.html` to exist, then compute and verify its absolute
path:

```bash
gallery_path="$(cd generated && pwd -P)/analysis.html"
test -f "$gallery_path"
```

Then report the saved revision with the same clickable gallery link used after analysis:

> Saved analysis organization at board revision N. [Open the analysis page](</absolute/path/to/generated/analysis.html>).

Replace both placeholders with the actual revision and verified absolute
path. Always enclose the link target in angle brackets so assignment paths
containing spaces remain clickable. If the rerender or path check fails, report the saved revision and the
refresh failure without claiming that the gallery opened or emitting a broken
link. The initial organizer opening above remains the host content reference;
the post-Apply response is the static gallery Markdown link.

If the host bridge is unavailable, tell the student exactly:

> The organizer is ready. Please send the payload shown below to Codex if Apply cannot reach the chat bridge.
