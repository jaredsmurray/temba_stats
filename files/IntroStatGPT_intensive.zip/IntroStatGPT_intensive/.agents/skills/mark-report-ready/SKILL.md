---
name: mark-report-ready
description: Preserve one saved statistical figure or table as a frozen report-ready snapshot when a student explicitly asks for that individual operation. Match the output by its visible title; never require a backend slug.
---

# Preserve one report-ready output

Identify the saved output from its visible title in `analysis/*/manifest.yaml`.
If the request is ambiguous, show only the matching visible titles and ask which
one the student means. Do not ask for or expose its internal slug.

This command preserves one current output for download or later use. The normal
report workflow uses the organizer and `prepare_report.R`, which freezes every
selected active output together and emits the approval token for compilation.

Run this command only when the student explicitly asks to preserve one output:

```sh
Rscript scripts/mark_report_ready.R --analysis "<visible title>"
```

Pass optional problem, question, section, tag, order, width, or height metadata
only when supplied by the assignment context or student. Do not invent a
substantive caption or interpretation.

The script validates the current saved object, copies its exact bytes into an
atomic `report_ready/<slug>/` snapshot, and writes `manifest.yaml`, the rendered
file, and `reproduce.R`. It does not execute the reproduction script. The live
copy under `analysis/` remains available. This is a mechanical preservation
operation, not a judgment that the analysis is correct.

If a snapshot already exists, do not replace it automatically. Use `--replace`
only after the student explicitly asks to update that preserved version.

After success, report the visible title plus the rendered artifact and
reproduction-script paths. Do not add interpretation.
