---
name: export-r-script
description: Export a saved statistical figure or table as a clean, runnable, commented R reproduction script. Use when a student asks to see, save, download, study, learn from, or reproduce the R code for a visible analysis output. Match outputs by visible title rather than backend ID. Support optional detailed teaching comments that explain functions and their supplied arguments.
---

# Export a reproducibility script

Identify the saved output by its visible title. If multiple titles match, show
only those titles and ask which one the student means. Do not require a backend
slug.

For a concise commented script, run:

```sh
Rscript scripts/export_analysis.R --analysis "<visible title>"
```

If a report-ready snapshot exists, export that frozen version by default. If the
student explicitly requests the current working version, add `--working`.

When the student requests teaching comments or argument explanations, add:

```sh
--detailed-comments
```

The exporter writes under `exports/`, never edits the analysis or report-ready
snapshot, and does not overwrite an existing export. Use `--overwrite` only
when the student explicitly asks to replace the corresponding exported script.

Report only the exported path and whether concise or detailed comments were
used. Do not paste the source into chat unless the student asks to see it there.
Do not interpret the statistical output or add conceptual conclusions.
