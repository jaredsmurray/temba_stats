---
name: compile-report
description: Prepare, review, approve, or compile a frozen report plan into a Word report skeleton. Use when a student asks to arrange report outputs, prepare or review the report, approve its render token, or compile the prepared report.
---

# Compile a prepared report

The organizer owns section arrangement. Open the live organizer when the student
wants to add, rename, remove, reorder, include, archive, or move outputs. The
organizer sends one complete payload through the conversation; the agent applies
it against the board revision. Do not edit `analysis/board.yaml` or generated
state directly.

When the student is ready, prepare the report:

```sh
Rscript scripts/prepare_report.R
```

Preparation freezes every selected active artifact, validates the complete
section arrangement, emits every ordinary named section (including empty
sections), and prints the section summary with visible labels and one render
token. A selected artifact in **Unassigned** is a preparation error and must be
placed in an ordinary report section; Unassigned is never a report heading.

After preparation succeeds, require `generated/analysis.html` to exist, compute
and verify its absolute path, and report: `Prepared report review is ready.
[Open the analysis page](</absolute/path/to/generated/analysis.html>).` Replace the
placeholder with that verified path and keep the target angle-bracketed so paths
containing spaces remain clickable. If preparation reports a gallery-refresh
warning or path validation fails, report the preparation result without
claiming the gallery opened or emitting a broken link.

The prepared section summary and render token are the student-facing review
surface. Do not link, open, attach, or expose `generated/report_plan.yaml`, its
internal keys, or its section IDs.

Show the resulting section summary and render token in chat. Ask for explicit
approval of that exact token. Do not treat a request to prepare, a correction,
or a request to inspect the summary as approval.

Only after approval, run:

```sh
Rscript scripts/compile_report.R --apply --render-token "<approved token>"
```

The compiler reads only the frozen snapshots named by the prepared plan. It
never executes `reproduce.R`, pulls in mutable drafts, adds interpretation or
report prose, or overwrites an existing report. If the requested output path
already exists, report that path and ask the student for a new output name.
Report the output path when compilation succeeds. If preparation or compilation
reports a visible title that needs attention, ask before changing the working
analysis or preserving a replacement snapshot.
