# Workspace locking and same-directory replacement helpers.

introstat_workspace_lock_path <- function(root) {
  file.path(introstat_validate_analysis_root(root, create = FALSE), ".introstat-workspace.lock")
}

if (!exists(".introstat_lock_state", inherits = FALSE) || !is.environment(.introstat_lock_state)) {
  .introstat_lock_state <- new.env(parent = emptyenv())
}

introstat_with_workspace_lock <- function(root, code, timeout_ms = 10000, timeout = NULL) {
  if (!is.function(code)) stop("code must be a function.", call. = FALSE)
  root <- normalizePath(root, mustWork = TRUE)
  analysis_root <- introstat_validate_analysis_root(root, create = TRUE)
  key <- normalizePath(analysis_root, mustWork = TRUE)
  if (isTRUE(.introstat_lock_state[[key]])) {
    stop("The analysis workspace lock is non-reentrant.", call. = FALSE)
  }
  if (!is.null(timeout)) {
    if (!is.numeric(timeout) || length(timeout) != 1L || is.na(timeout) || timeout < 0) stop("Lock timeout must be a non-negative number of seconds.", call. = FALSE)
    timeout_ms <- timeout * 1000
  }
  if (!is.numeric(timeout_ms) || length(timeout_ms) != 1L || is.na(timeout_ms) || timeout_ms < 0) {
    stop("Lock timeout must be a non-negative number of milliseconds.", call. = FALSE)
  }
  # Recheck after creating a previously absent directory so a linked parent
  # cannot become the lock target between validation and acquisition.
  analysis_root <- introstat_validate_analysis_root(root, create = FALSE)
  lock <- filelock::lock(file.path(analysis_root, ".introstat-workspace.lock"), timeout = timeout_ms)
  if (is.null(lock)) stop("Timed out waiting for the analysis workspace lock after ", timeout_ms, " ms.", call. = FALSE)
  .introstat_lock_state[[key]] <- TRUE
  on.exit({
    .introstat_lock_state[[key]] <- FALSE
    filelock::unlock(lock)
  }, add = TRUE)
  force(code)()
}

introstat_with_analysis_lock <- introstat_with_workspace_lock

introstat_is_symlink <- function(path) {
  link <- Sys.readlink(path)
  length(link) == 1L && !is.na(link) && nzchar(link)
}

introstat_path_identity <- function(path) {
  value <- gsub("\\\\", "/", as.character(path), fixed = FALSE)
  value <- sub("/+$", "", value)
  if (identical(.Platform$OS.type, "windows")) value <- tolower(value)
  value
}

introstat_validate_analysis_root <- function(root, create = TRUE) {
  root <- normalizePath(root, mustWork = TRUE)
  analysis <- file.path(root, "analysis")
  if (introstat_is_symlink(analysis)) {
    stop("The analysis directory cannot be a symbolic link.", call. = FALSE)
  }
  if (file.exists(analysis) && !dir.exists(analysis)) {
    stop("The analysis path must be a directory.", call. = FALSE)
  }
  if (!dir.exists(analysis) && isTRUE(create)) {
    if (!dir.create(analysis, recursive = TRUE, showWarnings = FALSE) && !dir.exists(analysis)) {
      stop("Could not create the analysis directory.", call. = FALSE)
    }
  }
  if (!dir.exists(analysis)) stop("Missing analysis directory.", call. = FALSE)
  if (introstat_is_symlink(analysis)) {
    stop("The analysis directory cannot be a symbolic link.", call. = FALSE)
  }
  resolved <- normalizePath(analysis, mustWork = TRUE)
  prefix <- paste0(root, .Platform$file.sep)
  if (!startsWith(resolved, prefix)) {
    stop("The analysis directory must remain inside the workspace.", call. = FALSE)
  }
  if (!identical(introstat_path_identity(resolved), introstat_path_identity(analysis))) {
    stop("The analysis directory cannot be redirected through a symbolic link or junction.", call. = FALSE)
  }
  analysis
}

# Install a staged file without replacing a destination that appears after a
# caller's existence check. Hard-link creation is the portable no-clobber
# primitive available through base R; unsupported filesystems fail safely.
introstat_install_file_noclobber <- function(staged, target) {
  if (introstat_is_symlink(staged) || introstat_is_symlink(target)) {
    stop("Cannot install a linked file without overwriting an existing file.", call. = FALSE)
  }
  if (!file.exists(staged) || dir.exists(staged)) stop("Staged file does not exist: ", staged, call. = FALSE)
  parent <- dirname(target)
  if (!dir.exists(parent) || introstat_is_symlink(parent)) stop("The install directory is not a real directory: ", parent, call. = FALSE)
  staged <- normalizePath(staged, mustWork = TRUE)
  if (!identical(normalizePath(dirname(staged), mustWork = TRUE), normalizePath(parent, mustWork = TRUE))) {
    stop("Staged and target files must share a parent filesystem directory.", call. = FALSE)
  }
  if (file.exists(target) || dir.exists(target) || introstat_is_symlink(target)) {
    stop("Could not install the file without overwriting an existing file: ", target, call. = FALSE)
  }
  linked <- suppressWarnings(file.link(staged, target))
  if (!isTRUE(linked)) {
    if (file.exists(target) || dir.exists(target) || introstat_is_symlink(target)) {
      stop("Could not install the file without overwriting an existing file: ", target, call. = FALSE)
    }
    stop("The filesystem cannot install the file safely without overwriting: ", target, call. = FALSE)
  }
  unlink(staged, force = TRUE)
  if (file.exists(staged)) {
    stop("Installed the file but could not remove its staging path: ", staged, call. = FALSE)
  }
  invisible(target)
}

introstat_replace_validate_paths <- function(staged, target, directory = FALSE) {
  if (introstat_is_symlink(staged) || introstat_is_symlink(target)) stop("Replacement does not accept symbolic links.", call. = FALSE)
  staged <- normalizePath(staged, mustWork = TRUE); target <- normalizePath(target, mustWork = FALSE)
  if (identical(staged, target)) stop("Staged and target paths must differ.", call. = FALSE)
  if (!identical(normalizePath(dirname(staged), mustWork = TRUE), normalizePath(dirname(target), mustWork = TRUE))) stop("Replacement paths must share a parent filesystem directory.", call. = FALSE)
  if (directory && !dir.exists(staged)) stop("Staged directory does not exist: ", staged, call. = FALSE)
  if (!directory && (!file.exists(staged) || dir.exists(staged))) stop("Staged file does not exist: ", staged, call. = FALSE)
  invisible(list(staged = staged, target = target))
}

introstat_atomic_replace_file <- function(staged, target, backup = NULL) {
  transaction <- introstat_begin_replace_file(staged, target, backup)
  transaction$commit()
}

introstat_atomic_replace_dir <- function(staged, target, backup = NULL) {
  transaction <- introstat_begin_replace_dir(staged, target, backup)
  transaction$commit()
}

introstat_atomic_replace <- function(staged, target, backup = NULL) {
  if (dir.exists(staged)) introstat_atomic_replace_dir(staged, target, backup) else introstat_atomic_replace_file(staged, target, backup)
}

# Install first and let the caller decide when the old copy can be discarded.
# This is used for the artifact-plus-board commit, where a board failure must
# restore the artifact before the workspace lock is released.
introstat_begin_replace_dir <- function(staged, target, backup = NULL) {
  parent <- dirname(target)
  dir.create(parent, recursive = TRUE, showWarnings = FALSE)
  introstat_replace_validate_paths(staged, target, TRUE)
  if (is.null(backup)) backup <- tempfile(paste0(".", basename(target), "-backup-"), tmpdir = parent)
  if (!identical(normalizePath(dirname(backup), mustWork = TRUE), normalizePath(parent, mustWork = TRUE))) stop("Replacement backup must share the target parent.", call. = FALSE)
  if (file.exists(backup) || dir.exists(backup) || introstat_is_symlink(backup)) stop("Replacement backup path must not already exist.", call. = FALSE)
  had_old <- dir.exists(target)
  if (had_old && !file.rename(target, backup)) stop("Could not stage existing directory: ", target, call. = FALSE)
  if (!file.rename(staged, target)) {
    if (had_old && (!dir.exists(backup) || !file.rename(backup, target) || !dir.exists(target))) stop("Could not install or restore directory: ", target, call. = FALSE)
    stop("Could not install directory: ", target, call. = FALSE)
  }
  committed <- FALSE
  list(
    commit = function() {
      if (committed) return(invisible(target))
      if (dir.exists(backup)) {
        unlink(backup, recursive = TRUE, force = TRUE)
        if (dir.exists(backup)) warning("Installed directory but could not remove backup: ", backup, call. = FALSE)
      }
      committed <<- TRUE
      invisible(target)
    },
    rollback = function() {
      if (committed) return(invisible(target))
      if (dir.exists(target)) {
        unlink(target, recursive = TRUE, force = TRUE)
        if (dir.exists(target)) stop("Could not remove installed directory during rollback: ", target, call. = FALSE)
      }
      if (had_old && (!dir.exists(backup) || !file.rename(backup, target) || !dir.exists(target))) stop("Could not restore directory during rollback: ", target, call. = FALSE)
      committed <<- TRUE
      invisible(target)
    },
    target = target,
    backup = backup
  )
}

introstat_begin_replace_file <- function(staged, target, backup = NULL) {
  parent <- dirname(target); dir.create(parent, recursive = TRUE, showWarnings = FALSE)
  introstat_replace_validate_paths(staged, target, FALSE)
  if (is.null(backup)) backup <- tempfile(paste0(".", basename(target), "-backup-"), tmpdir = parent)
  if (!identical(normalizePath(dirname(backup), mustWork = TRUE), normalizePath(parent, mustWork = TRUE))) stop("Replacement backup must share the target parent.", call. = FALSE)
  if (file.exists(backup) || dir.exists(backup) || introstat_is_symlink(backup)) stop("Replacement backup path must not already exist.", call. = FALSE)
  had_old <- file.exists(target) && !dir.exists(target)
  if (had_old && !file.rename(target, backup)) stop("Could not stage existing file: ", target, call. = FALSE)
  if (!file.rename(staged, target)) {
    if (had_old && (!file.exists(backup) || !file.rename(backup, target) || !file.exists(target))) stop("Could not install or restore file: ", target, call. = FALSE)
    stop("Could not install file: ", target, call. = FALSE)
  }
  committed <- FALSE
  list(
    commit = function() { if (committed) return(invisible(target)); if (file.exists(backup)) { unlink(backup, force = TRUE); if (file.exists(backup)) warning("Installed file but could not remove backup: ", backup, call. = FALSE) }; committed <<- TRUE; invisible(target) },
    rollback = function() { if (committed) return(invisible(target)); if (file.exists(target)) { unlink(target, force = TRUE); if (file.exists(target)) stop("Could not remove installed file during rollback: ", target, call. = FALSE) }; if (had_old && (!file.exists(backup) || !file.rename(backup, target) || !file.exists(target))) stop("Could not restore file during rollback: ", target, call. = FALSE); committed <<- TRUE; invisible(target) },
    target = target,
    backup = backup
  )
}
