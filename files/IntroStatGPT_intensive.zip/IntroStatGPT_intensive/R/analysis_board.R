# Durable analysis gallery state. All mutating entry points expect callers to
# use introstat_sync_analysis_board(), except the *_unlocked variants.

if (!exists("%||%", mode = "function")) `%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x
introstat_board_path <- function(root) file.path(root, "analysis", "board.yaml")
introstat_safe_analysis_slug <- function(x) length(x) == 1L && grepl("^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$", x)
introstat_board_trim <- function(x) trimws(as.character(x), which = "both")
introstat_board_casefold <- function(x) tolower(introstat_board_trim(x))

introstat_board_manifest_paths <- function(root) {
  store <- file.path(root, "analysis")
  if (!dir.exists(store)) return(character())
  if (nzchar(Sys.readlink(store))) stop("The analysis store cannot be a symbolic link.", call. = FALSE)
  store_real <- normalizePath(store, mustWork = TRUE)
  store_prefix <- paste0(store_real, .Platform$file.sep)
  paths <- list.files(store, pattern = "^manifest\\.ya?ml$", recursive = TRUE,
                      full.names = TRUE, ignore.case = TRUE)
  if (!length(paths)) return(character())
  exact <- vapply(paths, function(path) {
    if (nzchar(Sys.readlink(path)) || nzchar(Sys.readlink(dirname(path)))) return(FALSE)
    resolved <- normalizePath(path, mustWork = TRUE)
    if (!startsWith(resolved, store_prefix)) return(FALSE)
    relative <- substring(resolved, nchar(store_prefix) + 1L)
    grepl("^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/manifest\\.ya?ml$", relative, perl = TRUE)
  }, logical(1))
  if (any(!exact)) stop("Analysis manifests must be located at analysis/<slug>/manifest.yaml.", call. = FALSE)
  paths
}

introstat_board_read_manifest <- function(path) {
  if (!exists("read_manifest", mode = "function")) {
    if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
    return(yaml::read_yaml(path))
  }
  read_manifest(path)
}

introstat_board_write_yaml <- function(value, path) {
  if (isTRUE(getOption("introstat.fail_board_write", FALSE)) || identical(Sys.getenv("INTROSTAT_FAIL_BOARD_WRITE", ""), "1")) stop("Injected board write failure.", call. = FALSE)
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  yaml::write_yaml(value, path)
}

introstat_board_manifest_records <- function(root) {
  paths <- introstat_board_manifest_paths(root)
  if (!length(paths)) return(list())
  records <- lapply(paths, function(path) {
    m <- introstat_board_read_manifest(path)
    slug <- as.character(m$slug %||% basename(dirname(path)))
    if (length(slug) != 1L || !introstat_safe_analysis_slug(slug)) stop("Manifest has an unsafe artifact slug: ", slug, call. = FALSE)
    if (!identical(slug, basename(dirname(path)))) stop("Manifest slug does not match its directory: ", path, call. = FALSE)
    artifact_type <- as.character(m$artifact_type %||% "")
    if (length(artifact_type) != 1L || is.na(artifact_type) || !nzchar(artifact_type)) stop("Manifest is missing artifact_type: ", path, call. = FALSE)
    introstat_board_type_prefix(artifact_type)
    display_id <- m$display_id %||% ""
    if (length(display_id) != 1L || is.na(display_id)) stop("Manifest display_id must be a scalar when present: ", path, call. = FALSE)
    title <- m$title %||% tools::toTitleCase(gsub("-", " ", slug))
    if (!is.character(title) || length(title) != 1L || is.na(title) || !identical(title, introstat_board_trim(title)) || !nzchar(title)) stop("Manifest title must be a trimmed non-empty scalar string: ", path, call. = FALSE)
    created_at <- m$created_at %||% m$updated_at %||% ""
    if (length(created_at) != 1L || is.na(created_at)) stop("Manifest timestamps must be scalar when present: ", path, call. = FALSE)
    list(
      key = slug,
      title = as.character(title),
      artifact_type = artifact_type,
      display_id = toupper(as.character(display_id)),
      created_at = as.character(created_at),
      manifest_data = m,
      manifest = path,
      directory = dirname(path),
      artifacts = as.character(unlist(m$artifacts %||% character(), use.names = FALSE))
    )
  })
  keys <- vapply(records, `[[`, character(1), "key")
  if (anyDuplicated(tolower(keys))) stop("Artifact slugs must be unique case-insensitively.", call. = FALSE)
  records
}

introstat_board_type_prefix <- function(type) {
  type <- as.character(type)
  if (length(type) != 1L || is.na(type) || !type %in% c("plot", "regression_table", "table", "summary_table")) stop("Unsupported artifact type: ", paste(type, collapse = ", "), call. = FALSE)
  switch(type, plot = "P", regression_table = "R", table = "T", summary_table = "T")
}

introstat_board_valid_display_id <- function(id, type = NULL) {
  if (is.null(id) || length(id) != 1L || is.na(id) || !nzchar(as.character(id))) return(FALSE)
  prefix <- if (is.null(type)) "PRT" else introstat_board_type_prefix(type)
  grepl(paste0("^[", prefix, "][1-9][0-9]*$"), toupper(as.character(id)))
}

introstat_board_display_ids <- function(records, retained) {
  # Validate all explicit assignments and conflicts before allocating anything.
  explicit <- character()
  for (record in records) {
    old <- retained[[record$key]]
    board_id <- if (!is.null(old)) toupper(as.character(old$display_id %||% "")) else ""
    manifest_id <- toupper(record$display_id)
    if (nzchar(board_id) && !introstat_board_valid_display_id(board_id, old$artifact_type %||% record$artifact_type)) {
      stop("Invalid retained display ID for ", record$key, ": ", board_id, call. = FALSE)
    }
    if (nzchar(manifest_id) && !introstat_board_valid_display_id(manifest_id, record$artifact_type)) {
      stop("Display ID has an incompatible artifact type for ", record$key, ": ", manifest_id, call. = FALSE)
    }
    if (nzchar(board_id) && nzchar(manifest_id) && !identical(board_id, manifest_id)) {
      stop("Manifest and board display IDs conflict for ", record$key, ".", call. = FALSE)
    }
    chosen <- if (nzchar(manifest_id)) manifest_id else board_id
    if (nzchar(chosen)) {
      if (chosen %in% explicit) stop("Duplicate display ID: ", chosen, call. = FALSE)
      explicit <- c(explicit, chosen)
    }
  }
  all_retained <- vapply(retained, function(x) toupper(as.character(x$display_id %||% "")), character(1))
  all_retained <- all_retained[nzchar(all_retained)]
  if (anyDuplicated(all_retained)) stop("Retained display IDs must be unique.", call. = FALSE)
  if (length(intersect(explicit, setdiff(all_retained, explicit))) || any(vapply(records, function(record) {
    id <- toupper(record$display_id); prior_id <- toupper(as.character(retained[[record$key]]$display_id %||% ""))
    nzchar(id) && !identical(id, prior_id) && id %in% all_retained
  }, logical(1)))) stop("Manifest display ID conflicts with a retained board reservation.", call. = FALSE)
  used <- unique(c(explicit, all_retained))
  out <- list()
  for (record in records) {
    old <- retained[[record$key]]
    existing <- if (!is.null(record$display_id) && nzchar(record$display_id)) toupper(record$display_id) else ""
    if (!nzchar(existing) && !is.null(old)) existing <- toupper(as.character(old$display_id %||% ""))
    if (nzchar(existing)) { out[[record$key]] <- existing; next }
    out[[record$key]] <- NA_character_
  }
  prefixes <- unique(vapply(records, function(x) introstat_board_type_prefix(x$artifact_type), character(1)))
  for (prefix in prefixes) {
    missing <- names(out)[vapply(names(out), function(k) is.na(out[[k]]) && introstat_board_type_prefix(records[[match(k, vapply(records, `[[`, character(1), "key"))]]$artifact_type) == prefix, logical(1))]
    if (!length(missing)) next
    # Reservations include missing board records and prevent reuse after a delete.
    reserved <- grep(paste0("^", prefix, "[1-9][0-9]*$"), used, value = TRUE)
    next_number <- if (length(reserved)) max(as.integer(sub(paste0("^", prefix), "", reserved))) + 1L else 1L
    rec_by_key <- stats::setNames(records, vapply(records, `[[`, character(1), "key"))
    missing <- missing[order(vapply(rec_by_key[missing], `[[`, character(1), "created_at"),
                             vapply(rec_by_key[missing], `[[`, character(1), "title"), missing)]
    for (key in missing) {
      candidate <- paste0(prefix, next_number)
      while (candidate %in% used) { next_number <- next_number + 1L; candidate <- paste0(prefix, next_number) }
      out[[key]] <- candidate; used <- c(used, candidate); next_number <- next_number + 1L
    }
  }
  out
}

introstat_board_outline_sections <- function(outline_path) {
  if (!file.exists(outline_path)) return(list())
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  outline <- yaml::read_yaml(outline_path)
  sections <- outline$sections %||% list()
  if (!length(sections)) return(list())
  result <- lapply(sections, function(s) {
    if (!is.list(s)) stop("Report outline sections must be mappings.", call. = FALSE)
    id <- introstat_board_trim(s$id %||% "")
    title <- introstat_board_trim(s$title %||% id)
    if (!nzchar(id) || !nzchar(title) || !introstat_safe_analysis_slug(id)) stop("Outline section ids and titles must be non-empty safe values.", call. = FALSE)
    include <- if (is.null(s$include_if_empty)) TRUE else s$include_if_empty
    if (!is.logical(include) || length(include) != 1L || is.na(include)) stop("include_if_empty must be a single boolean.", call. = FALSE)
    # Retain the legacy field on the wire, but ordinary outline sections are
    # unconditionally part of the report skeleton.  A legacy false value is
    # accepted and normalized at this boundary.
    list(id = id, title = title, role = "report", include_if_empty = TRUE, match = s$match %||% list())
  })
  ids <- introstat_board_casefold(vapply(result, `[[`, character(1), "id")); titles <- introstat_board_casefold(vapply(result, `[[`, character(1), "title"))
  if (anyDuplicated(ids)) stop("Report outline section IDs must be unique.", call. = FALSE)
  if (anyDuplicated(titles)) stop("Report outline section titles must be unique case-insensitively.", call. = FALSE)
  if (any(ids == "unassigned") || any(titles == "unassigned")) stop("Report outline reserves the Unassigned section id and title.", call. = FALSE)
  result
}

introstat_board_match_section <- function(record, sections) {
  if (!length(sections)) return(character())
  m <- record$manifest_data
  candidates <- character()
  hint <- as.character(m$section_id %||% m$section %||% "")
  for (section in sections) {
    rules <- section$match %||% list(); matched <- FALSE
    if (nzchar(hint)) matched <- matched || tolower(hint) %in% tolower(c(section$id, section$title))
    values <- tolower(as.character(unlist(m$tags %||% character(), use.names = FALSE)))
    wanted <- tolower(as.character(unlist(rules$tags %||% character(), use.names = FALSE)))
    if (length(wanted) && any(values %in% wanted)) matched <- TRUE
    p <- tolower(as.character(m$problem %||% m$question_id %||% m$question %||% ""))
    wanted <- tolower(as.character(unlist(rules$problems %||% rules$problem %||% character(), use.names = FALSE)))
    if (nzchar(p) && length(wanted) && p %in% wanted) matched <- TRUE
    wanted <- tolower(as.character(unlist(rules$questions %||% rules$question_ids %||% character(), use.names = FALSE)))
    if (nzchar(p) && length(wanted) && p %in% wanted) matched <- TRUE
    patterns <- as.character(unlist(rules$title_patterns %||% character(), use.names = FALSE))
    if (length(patterns) && any(vapply(patterns, function(x) grepl(x, record$title, ignore.case = TRUE, perl = TRUE), logical(1)))) matched <- TRUE
    if (matched) candidates <- c(candidates, section$id)
  }
  unique(candidates)
}

introstat_board_validate <- function(board) {
  board_names <- names(board) %||% character()
  if (!is.list(board) || length(board_names) != 4L || anyDuplicated(board_names) || !setequal(board_names, c("schema_version", "revision", "artifacts", "sections"))) stop("Analysis board must contain exactly schema_version, revision, artifacts, and sections.", call. = FALSE)
  if (length(board$schema_version) != 1L || !is.numeric(board$schema_version) || !is.finite(board$schema_version) || board$schema_version != 1) stop("Analysis board schema_version must be the finite whole number 1.", call. = FALSE)
  if (length(board$revision) != 1L || !is.numeric(board$revision) || !is.finite(board$revision) || board$revision < 1 || board$revision != floor(board$revision)) stop("Analysis board revision must be a finite whole number at least 1.", call. = FALSE)
  sections <- board$sections %||% list(); if (!length(sections)) stop("Analysis board must contain sections.", call. = FALSE)
  if (!is.list(sections) || any(!vapply(sections, is.list, logical(1)))) stop("Analysis board sections must be mappings.", call. = FALSE)
  required_section_fields <- c("id", "title", "role", "include_if_empty", "artifacts")
  if (any(!vapply(sections, function(x) { fields <- names(x) %||% character(); length(fields) == length(required_section_fields) && !anyDuplicated(fields) && setequal(fields, required_section_fields) }, logical(1)))) stop("Board sections have invalid fields.", call. = FALSE)
  ids <- introstat_board_casefold(vapply(sections, function(x) x$id %||% "", character(1)))
  titles <- introstat_board_casefold(vapply(sections, function(x) x$title %||% "", character(1)))
  if (any(!vapply(sections, function(x) is.character(x$id) && length(x$id) == 1L && !is.na(x$id) && identical(x$id, introstat_board_trim(x$id)) && introstat_safe_analysis_slug(x$id), logical(1)))) stop("Board section ids must be trimmed, non-empty safe slugs.", call. = FALSE)
  if (any(!vapply(sections, function(x) is.character(x$title) && length(x$title) == 1L && !is.na(x$title) && identical(x$title, introstat_board_trim(x$title)) && nzchar(x$title), logical(1)))) stop("Board section titles must be trimmed non-empty strings.", call. = FALSE)
  roles <- vapply(sections, function(x) as.character(x$role %||% ""), character(1))
  if (any(!vapply(sections, function(x) is.character(x$role) && length(x$role) == 1L && !is.na(x$role), logical(1)))) stop("Board section roles must be scalar strings.", call. = FALSE)
  if (any(roles[-length(roles)] != "report")) stop("Ordinary board sections must have role report.", call. = FALSE)
  if (anyDuplicated(ids) || anyDuplicated(titles)) stop("Board section ids and titles must be unique.", call. = FALSE)
  if (!identical(ids[[length(ids)]], "unassigned") || !identical(titles[[length(titles)]], "unassigned")) stop("Unassigned must be the final board section.", call. = FALSE)
  if (!identical(as.character(sections[[length(sections)]]$role), "unassigned") || !identical(sections[[length(sections)]]$id, "unassigned") || !identical(sections[[length(sections)]]$title, "Unassigned") || !identical(sections[[length(sections)]]$include_if_empty, FALSE)) stop("Unassigned has a fixed role and visibility.", call. = FALSE)
  if (any(!vapply(sections, function(x) is.logical(x$include_if_empty) && length(x$include_if_empty) == 1L && !is.na(x$include_if_empty), logical(1)))) stop("Section include_if_empty must be a single boolean.", call. = FALSE)
  artifacts <- board$artifacts %||% list(); if (!is.list(artifacts)) stop("Board artifacts must be a keyed mapping.", call. = FALSE); keys <- names(artifacts) %||% character()
  if (length(artifacts) && (length(keys) != length(artifacts) || anyDuplicated(keys) || any(!vapply(keys, introstat_safe_analysis_slug, logical(1))))) stop("Board artifact keys must be unique safe slugs.", call. = FALSE)
  required_artifact_fields <- c("display_id", "last_known_title", "artifact_type", "include_in_report", "archived")
  if (length(artifacts) && any(!vapply(artifacts, function(x) { fields <- names(x) %||% character(); is.list(x) && length(fields) == length(required_artifact_fields) && !anyDuplicated(fields) && setequal(fields, required_artifact_fields) }, logical(1)))) stop("Board artifact records have invalid fields.", call. = FALSE)
  ids_art <- vapply(artifacts, function(x) toupper(as.character(x$display_id %||% "")), character(1)); ids_art <- ids_art[nzchar(ids_art)]
  if (anyDuplicated(ids_art)) stop("Board display IDs must be unique.", call. = FALSE)
  for (key in names(artifacts)) {
    title <- artifacts[[key]]$last_known_title %||% ""
    if (!is.character(title) || length(title) != 1L || is.na(title) || !identical(title, introstat_board_trim(title)) || !nzchar(title)) stop("Board artifact titles must be trimmed non-empty scalar strings.", call. = FALSE)
    id <- as.character(artifacts[[key]]$display_id %||% "")
    type <- as.character(artifacts[[key]]$artifact_type %||% "")
    if (length(id) != 1L || is.na(id) || !nzchar(id) || !identical(id, toupper(id))) stop("Board artifacts require an uppercase display ID.", call. = FALSE)
    if (length(type) != 1L || is.na(type) || !nzchar(type)) stop("Board artifacts require an artifact type.", call. = FALSE)
    if (nzchar(type)) introstat_board_type_prefix(type)
    if (nzchar(id) && nzchar(type) && !introstat_board_valid_display_id(id, type)) stop("Board display ID has an incompatible artifact type for ", key, ".", call. = FALSE)
    if (!is.logical(artifacts[[key]]$include_in_report) || length(artifacts[[key]]$include_in_report) != 1L || is.na(artifacts[[key]]$include_in_report) || !is.logical(artifacts[[key]]$archived) || length(artifacts[[key]]$archived) != 1L || is.na(artifacts[[key]]$archived)) stop("Board artifact flags must be single booleans.", call. = FALSE)
  }
  if (any(!vapply(sections, function(s) is.character(s$artifacts) || (is.list(s$artifacts) && !length(s$artifacts)), logical(1)))) stop("Section artifact mappings must be character lists.", call. = FALSE)
  locations <- unlist(lapply(sections, function(s) as.character(unlist(s$artifacts %||% character(), use.names = FALSE))), use.names = FALSE)
  if (length(locations) && (anyNA(locations) || any(!nzchar(locations)) || any(!vapply(locations, introstat_safe_analysis_slug, logical(1))))) stop("Section artifact references must be safe slugs.", call. = FALSE)
  if (!setequal(locations, keys) || anyDuplicated(locations)) stop("Every board artifact must occur in exactly one section.", call. = FALSE)
  for (key in keys) if (isTRUE(artifacts[[key]]$archived) && isTRUE(artifacts[[key]]$include_in_report)) stop("Archived artifact is included in report: ", key, call. = FALSE)
  invisible(board)
}

introstat_board_normalize_legacy_sections <- function(board) {
  if (!is.list(board) || !is.list(board$sections)) return(board)
  board$sections <- lapply(board$sections, function(section) {
    if (is.list(section) && !identical(as.character(section$role %||% ""), "unassigned") && identical(section$include_if_empty, FALSE)) {
      section$include_if_empty <- TRUE
    }
    section
  })
  board
}

introstat_board_has_legacy_false_sections <- function(board) {
  is.list(board) && is.list(board$sections) && any(vapply(board$sections, function(section) {
    is.list(section) && !identical(as.character(section$role %||% ""), "unassigned") && identical(section$include_if_empty, FALSE)
  }, logical(1)))
}

introstat_board_semantic <- function(board) {
  board$revision <- NULL
  board$sections <- lapply(board$sections, function(section) {
    section$artifacts <- as.character(unlist(section$artifacts %||% character(), use.names = FALSE))
    section
  })
  board
}

introstat_sync_analysis_board_unlocked <- function(root, outline_path = file.path(root, "report_outline.yaml"), persist = TRUE) {
  root <- normalizePath(root, mustWork = TRUE); dir.create(file.path(root, "analysis"), recursive = TRUE, showWarnings = FALSE)
  path <- introstat_board_path(root); old_raw <- if (file.exists(path)) yaml::read_yaml(path) else NULL
  old <- introstat_board_normalize_legacy_sections(old_raw)
  records <- introstat_board_manifest_records(root)
  if (is.null(old)) {
    outline_sections <- introstat_board_outline_sections(outline_path)
    sections <- lapply(outline_sections, function(s) list(id = s$id, title = s$title, role = s$role, include_if_empty = s$include_if_empty, artifacts = character()))
    sections <- c(sections, list(list(id = "unassigned", title = "Unassigned", role = "unassigned", include_if_empty = FALSE, artifacts = character())))
    retained <- list()
    artifacts <- list(); revision <- 1L
  } else {
    introstat_board_validate(old); sections <- old$sections; retained <- old$artifacts %||% list(); artifacts <- retained; revision <- as.integer(old$revision)
  }
  record_keys <- vapply(records, `[[`, character(1), "key")
  retained_map <- retained
  ids <- introstat_board_display_ids(records, retained_map)
  changed <- is.null(old_raw) || !identical(old_raw, old)
  for (record in records) {
    key <- record$key; prior <- retained[[key]]
    if (is.null(prior)) {
      candidates <- if (is.null(old)) introstat_board_match_section(record, outline_sections) else character()
      section_id <- if (length(candidates) == 1L) candidates else "unassigned"
      prior <- list(display_id = ids[[key]], last_known_title = record$title, artifact_type = record$artifact_type, include_in_report = FALSE, archived = FALSE)
      artifacts[[key]] <- prior; changed <- TRUE
      sections[[which(vapply(sections, function(x) identical(x$id, section_id), logical(1)))]]$artifacts <- c(sections[[which(vapply(sections, function(x) identical(x$id, section_id), logical(1)))]]$artifacts, key)
    } else {
      if (nzchar(as.character(prior$artifact_type %||% "")) && !identical(as.character(prior$artifact_type), record$artifact_type)) stop("Artifact type cannot change for ", key, ".", call. = FALSE)
      if (!identical(as.character(prior$display_id %||% ""), ids[[key]])) { prior$display_id <- ids[[key]] }
      if (!identical(as.character(prior$last_known_title %||% ""), record$title)) { prior$last_known_title <- record$title; changed <- TRUE }
      if (!identical(as.character(prior$artifact_type %||% ""), record$artifact_type)) { prior$artifact_type <- record$artifact_type; changed <- TRUE }
      artifacts[[key]] <- prior
    }
    if (isTRUE(prior$archived)) artifacts[[key]]$include_in_report <- FALSE
    if (is.null(old) || is.null(retained[[key]])) changed <- TRUE
  }
  # Missing artifacts remain in their original section and retain metadata.
  for (i in seq_along(sections)) sections[[i]]$artifacts <- unique(as.character(unlist(sections[[i]]$artifacts %||% character(), use.names = FALSE)))
  if (!is.null(old)) {
    locations <- unlist(lapply(sections, `[[`, "artifacts"), use.names = FALSE)
    for (key in setdiff(names(artifacts), locations)) { sections[[length(sections)]]$artifacts <- c(sections[[length(sections)]]$artifacts, key); changed <- TRUE }
  }
  board <- list(schema_version = 1L, revision = if (changed && !is.null(old)) revision + 1L else revision, artifacts = artifacts, sections = sections)
  introstat_board_validate(board)
  if (persist && (is.null(old) || changed)) {
    staged <- tempfile(".board-stage-", tmpdir = file.path(root, "analysis")); introstat_board_write_yaml(board, staged); introstat_atomic_replace_file(staged, path)
  } else if (!changed && !is.null(old)) board <- old
  board
}

introstat_sync_analysis_board <- function(root, outline_path = file.path(root, "report_outline.yaml"), timeout_ms = 10000, timeout = NULL) {
  if (!exists("introstat_with_workspace_lock", mode = "function")) source(file.path(root, "R", "workspace_lock.R"))
  introstat_with_workspace_lock(root, function() introstat_sync_analysis_board_unlocked(root, outline_path), timeout_ms = timeout_ms, timeout = timeout)
}

introstat_analysis_board_layout <- function(board, root) {
  introstat_board_validate(board)
  sections <- lapply(board$sections, function(section) {
    assets <- lapply(as.character(unlist(section$artifacts %||% character(), use.names = FALSE)), function(key) {
      item <- board$artifacts[[key]]; dir <- file.path(root, "analysis", key); manifest_path <- file.path(dir, "manifest.yaml"); present <- file.exists(manifest_path)
      m <- if (present) introstat_board_read_manifest(manifest_path) else NULL
      list(key = key, display_id = as.character(item$display_id %||% ""), title = as.character(item$last_known_title %||% key), include_in_report = isTRUE(item$include_in_report), archived = isTRUE(item$archived), available = present, artifact_type = if (present) as.character(m$artifact_type %||% item$artifact_type %||% "") else as.character(item$artifact_type %||% ""), record = if (present) list(directory = dir, manifest = manifest_path, artifacts = as.character(unlist(m$artifacts %||% character(), use.names = FALSE)), manifest_data = m) else NULL)
    })
    list(id = section$id, title = section$title, role = section$role, include_if_empty = if (identical(section$role, "unassigned")) FALSE else TRUE, assets = assets)
  })
  list(schema_version = 1L, revision = as.integer(board$revision), sections = sections)
}

introstat_board_resolve <- function(board, reference) {
  keys <- names(board$artifacts) %||% character(); needle <- tolower(trimws(as.character(reference)))
  hits <- keys[vapply(keys, function(k) needle %in% tolower(c(k, board$artifacts[[k]]$display_id %||% "", board$artifacts[[k]]$last_known_title %||% "")), logical(1))]
  if (!length(hits)) stop("No analysis matches ", reference, ". Use a visible ID or slug.", call. = FALSE)
  if (length(hits) > 1L) stop("More than one analysis matches the title ", reference, ". Use its visible ID or slug.", call. = FALSE)
  hits[[1]]
}

introstat_analysis_board_insert_after_unlocked <- function(board, source_key, new_key) {
  for (i in seq_along(board$sections)) {
    values <- as.character(unlist(board$sections[[i]]$artifacts %||% character(), use.names = FALSE))
    board$sections[[i]]$artifacts <- values[values != new_key]
  }
  for (i in seq_along(board$sections)) {
    values <- as.character(unlist(board$sections[[i]]$artifacts %||% character(), use.names = FALSE)); hit <- match(source_key, values)
    if (!is.na(hit)) { board$sections[[i]]$artifacts <- append(values, new_key, after = hit); return(board) }
  }
  stop("Source artifact is not assigned to a board section: ", source_key, call. = FALSE)
}

introstat_board_write_unlocked <- function(board, root, expected_revision = NULL) {
  introstat_board_validate(board)
  path <- introstat_board_path(root)
  current <- if (file.exists(path)) yaml::read_yaml(path) else NULL
  if (!is.null(expected_revision) && !is.null(current) && as.integer(current$revision) != as.integer(expected_revision)) {
    stop("Analysis board changed while the operation was in progress.", call. = FALSE)
  }
  staged <- tempfile(".board-stage-", tmpdir = file.path(root, "analysis")); introstat_board_write_yaml(board, staged)
  introstat_atomic_replace_file(staged, path)
  invisible(board)
}

# Board mutations are expressed as complete client snapshots.  The snapshot is
# validated before it is converted to durable board state, so a partial client
# request cannot leave a section order or artifact membership half-applied.
introstat_mutation_fields <- c("payload_version", "base_revision", "sections", "included", "archived")
introstat_mutation_section_fields <- c("section_id", "client_new_id", "title", "include_if_empty", "artifacts")

introstat_mutation_scalar_string <- function(value, label, allow_null = FALSE) {
  if (allow_null && is.null(value)) return(NULL)
  if (!is.character(value) || length(value) != 1L || is.na(value) || !nzchar(value) || !identical(value, introstat_board_trim(value))) {
    stop(label, " must be a trimmed non-empty string.", call. = FALSE)
  }
  value
}

introstat_mutation_string_set <- function(value, label) {
  if (is.null(value)) return(character())
  if (is.list(value)) value <- unlist(value, recursive = TRUE, use.names = FALSE)
  if (!length(value)) return(character())
  if (!is.character(value) || anyNA(value) || any(!vapply(value, function(x) nzchar(x) && identical(x, introstat_board_trim(x)), logical(1)))) {
    stop(label, " must contain trimmed strings.", call. = FALSE)
  }
  as.character(value)
}

introstat_mutation_integer <- function(value, label, minimum = 0) {
  if (!is.numeric(value) || length(value) != 1L || is.na(value) || !is.finite(value) || value != floor(value) || value < minimum) {
    stop(label, " must be a finite whole number.", call. = FALSE)
  }
  as.integer(value)
}

introstat_mutation_validate_payload <- function(payload, board) {
  if (!is.list(payload) || !setequal(names(payload) %||% character(), introstat_mutation_fields) || anyDuplicated(names(payload) %||% character())) {
    stop("Mutation payload must contain exactly payload_version, base_revision, sections, included, and archived.", call. = FALSE)
  }
  version <- introstat_mutation_integer(payload$payload_version, "payload_version", 1L)
  if (!identical(version, 1L)) stop("Only mutation payload_version 1 is supported.", call. = FALSE)
  base <- introstat_mutation_integer(payload$base_revision, "base_revision", 0L)
  sections <- payload$sections
  if (!is.list(sections) || !length(sections) || any(!vapply(sections, is.list, logical(1)))) stop("Mutation sections must be a non-empty list of mappings.", call. = FALSE)
  parsed <- lapply(sections, function(section) {
    fields <- names(section) %||% character()
    if (length(fields) != length(introstat_mutation_section_fields) || anyDuplicated(fields) || !setequal(fields, introstat_mutation_section_fields)) stop("Each mutation section must contain exactly section_id, client_new_id, title, include_if_empty, and artifacts.", call. = FALSE)
    id <- introstat_mutation_scalar_string(section$section_id, "section_id", allow_null = TRUE)
    client <- introstat_mutation_scalar_string(section$client_new_id, "client_new_id", allow_null = TRUE)
    if (!is.null(id) && !introstat_safe_analysis_slug(id)) stop("Mutation section_id must be a safe stable ID.", call. = FALSE)
    if (!is.null(client) && !nzchar(client)) stop("Mutation client_new_id must be non-empty.", call. = FALSE)
    title <- introstat_mutation_scalar_string(section$title, "section title")
    include <- section$include_if_empty
    if (!is.logical(include) || length(include) != 1L || is.na(include)) stop("Mutation include_if_empty must be a single boolean.", call. = FALSE)
    artifacts <- introstat_mutation_string_set(section$artifacts, "Mutation section artifacts")
    list(section_id = id, client_new_id = client, title = title, include_if_empty = if (is.null(id)) TRUE else if (identical(id, "unassigned")) FALSE else TRUE, artifacts = artifacts)
  })
  if (is.null(parsed[[length(parsed)]]$section_id) || !identical(parsed[[length(parsed)]]$section_id, "unassigned") || !is.null(parsed[[length(parsed)]]$client_new_id) || !identical(parsed[[length(parsed)]]$title, "Unassigned") || !identical(parsed[[length(parsed)]]$include_if_empty, FALSE)) stop("Unassigned must be the final fixed mutation section.", call. = FALSE)
  if (any(vapply(parsed[-length(parsed)], function(x) identical(x$section_id, "unassigned") || identical(x$title, "Unassigned"), logical(1)))) stop("Unassigned cannot be renamed or duplicated.", call. = FALSE)
  section_ids <- vapply(parsed, function(x) x$section_id %||% "", character(1)); client_ids <- vapply(parsed, function(x) x$client_new_id %||% "", character(1)); titles <- vapply(parsed, `[[`, character(1), "title")
  if (any((nzchar(section_ids) & nzchar(client_ids)) | (!nzchar(section_ids) & !nzchar(client_ids)))) stop("Existing sections require null client_new_id; new sections require null section_id and a client_new_id.", call. = FALSE)
  if (anyDuplicated(introstat_board_casefold(titles))) stop("Mutation section titles must be unique case-insensitively.", call. = FALSE)
  if (anyDuplicated(section_ids[nzchar(section_ids)])) stop("Mutation section IDs must be unique.", call. = FALSE)
  if (anyDuplicated(client_ids[nzchar(client_ids)])) stop("Mutation client_new_id values must be unique.", call. = FALSE)
  current_ids <- vapply(board$sections, `[[`, character(1), "id")
  supplied_existing <- section_ids[nzchar(section_ids)]
  if (any(!supplied_existing %in% current_ids)) stop("Mutation payload references an unknown or deleted section ID.", call. = FALSE)
  visible_ids <- toupper(vapply(board$artifacts, `[[`, character(1), "display_id")); section_assets <- unlist(lapply(parsed, `[[`, "artifacts"), use.names = FALSE)
  if (anyDuplicated(toupper(section_assets)) || !setequal(toupper(section_assets), visible_ids)) stop("Mutation sections must contain every current visible artifact ID exactly once.", call. = FALSE)
  included <- toupper(introstat_mutation_string_set(payload$included, "included")); archived <- toupper(introstat_mutation_string_set(payload$archived, "archived"))
  if (anyDuplicated(included) || anyDuplicated(archived) || any(!included %in% visible_ids) || any(!archived %in% visible_ids)) stop("included and archived must be complete sets of current visible IDs.", call. = FALSE)
  if (length(intersect(included, archived))) stop("included and archived sets cannot overlap.", call. = FALSE)
  list(version = version, base_revision = base, sections = parsed, included = included, archived = archived)
}

introstat_mutation_new_section_id <- function(board, used = character()) {
  existing <- c(vapply(board$sections, `[[`, character(1), "id"), used)
  i <- 1L
  candidate <- paste0("section-", i)
  while (candidate %in% existing) { i <- i + 1L; candidate <- paste0("section-", i) }
  candidate
}

introstat_analysis_board_apply_payload_unlocked <- function(board, payload, root = NULL) {
  introstat_board_validate(board)
  checked <- introstat_mutation_validate_payload(payload, board)
  if (!identical(as.integer(board$revision), checked$base_revision)) stop("The mutation payload is stale: expected board revision ", board$revision, ".", call. = FALSE)
  id_to_key <- stats::setNames(names(board$artifacts) %||% character(), toupper(vapply(board$artifacts, `[[`, character(1), "display_id")))
  used_new <- character(); sections <- lapply(checked$sections, function(section) {
    id <- section$section_id
    if (is.null(id)) { id <- introstat_mutation_new_section_id(board, used_new); used_new <<- c(used_new, id) }
    list(id = id, title = section$title, role = if (identical(id, "unassigned")) "unassigned" else "report", include_if_empty = if (identical(id, "unassigned")) FALSE else TRUE, artifacts = unname(id_to_key[toupper(section$artifacts)]))
  })
  artifacts <- board$artifacts
  for (key in names(artifacts)) {
    display_id <- toupper(as.character(artifacts[[key]]$display_id))
    artifacts[[key]]$include_in_report <- display_id %in% checked$included && !(display_id %in% checked$archived)
    artifacts[[key]]$archived <- display_id %in% checked$archived
  }
  candidate <- list(schema_version = 1L, revision = board$revision, artifacts = artifacts, sections = sections)
  introstat_board_validate(candidate)
  changed <- !identical(introstat_board_semantic(candidate), introstat_board_semantic(board))
  candidate$revision <- if (changed) as.integer(board$revision) + 1L else as.integer(board$revision)
  attr(candidate, "changed") <- changed
  attr(candidate, "new_section_ids") <- stats::setNames(used_new, vapply(checked$sections[vapply(checked$sections, function(x) is.null(x$section_id), logical(1))], `[[`, character(1), "client_new_id"))
  candidate
}

introstat_analysis_board_apply_payload <- function(root, payload, outline_path = file.path(root, "report_outline.yaml"), timeout_ms = 10000, timeout = NULL) {
  if (!exists("introstat_with_workspace_lock", mode = "function")) source(file.path(root, "R", "workspace_lock.R"))
  result <- NULL
  introstat_with_workspace_lock(root, function() {
    path <- introstat_board_path(root)
    persisted <- if (file.exists(path)) yaml::read_yaml(path) else NULL
    synced <- introstat_sync_analysis_board_unlocked(root, outline_path, persist = FALSE)
    actual_revision <- if (is.null(persisted)) 0L else introstat_mutation_integer(persisted$revision, "board revision", 1L)
    if (is.null(persisted)) {
      if (!identical(introstat_mutation_integer(payload$base_revision, "base_revision", 0L), 0L)) stop("A boardless workspace requires base_revision 0.", call. = FALSE)
      synced$revision <- 1L
      payload$base_revision <- 1L
    }
    if (!is.null(persisted) && !identical(as.integer(synced$revision), actual_revision)) synced$revision <- actual_revision
    needs_normalization <- introstat_board_has_legacy_false_sections(persisted)
    candidate <- introstat_analysis_board_apply_payload_unlocked(synced, payload, root)
    if (is.null(persisted)) candidate$revision <- 1L
    changed <- isTRUE(attr(candidate, "changed")) || is.null(persisted) || needs_normalization
    if (needs_normalization && !isTRUE(attr(candidate, "changed"))) candidate$revision <- actual_revision + 1L
    if (needs_normalization) attr(candidate, "changed") <- TRUE
    result <<- candidate
    if (changed) introstat_board_write_unlocked(result, root, expected_revision = if (is.null(persisted)) NULL else actual_revision)
  }, timeout_ms = timeout_ms, timeout = timeout)
  result
}

introstat_analysis_board_mutate <- introstat_analysis_board_apply_payload
introstat_update_analysis_board <- introstat_analysis_board_apply_payload

introstat_mutation_payload_from_board <- function(board) {
  list(payload_version = 1L, base_revision = as.integer(board$revision), sections = lapply(board$sections, function(section) list(section_id = section$id, client_new_id = NULL, title = section$title, include_if_empty = if (identical(section$role, "unassigned")) FALSE else TRUE, artifacts = vapply(section$artifacts %||% character(), function(key) board$artifacts[[key]]$display_id, character(1)))), included = vapply(board$artifacts[ vapply(board$artifacts, function(x) isTRUE(x$include_in_report), logical(1))], `[[`, character(1), "display_id"), archived = vapply(board$artifacts[ vapply(board$artifacts, function(x) isTRUE(x$archived), logical(1))], `[[`, character(1), "display_id"))
}

introstat_mutation_resolve_section <- function(board, reference) {
  needle <- introstat_board_casefold(reference)
  hits <- vapply(board$sections, function(x) needle %in% introstat_board_casefold(c(x$id, x$title)), logical(1))
  found <- which(hits)
  if (!length(found)) stop("No section matches ", reference, ".", call. = FALSE)
  if (length(found) > 1L) stop("More than one section matches ", reference, ".", call. = FALSE)
  board$sections[[found]]$id
}

introstat_mutation_move <- function(values, item, position = "end", anchor = NULL) {
  values <- values[values != item]
  if (position %in% c("start", "end")) return(if (position == "start") c(item, values) else c(values, item))
  if (is.null(anchor) || !anchor %in% values) stop("A move anchor is required and must exist in the same list.", call. = FALSE)
  at <- match(anchor, values) + if (position == "after") 1L else 0L
  append(values, item, after = at - 1L)
}

introstat_analysis_board_operation_payload <- function(board, operation, reference = NULL, title = NULL, section = NULL, position = "end", anchor = NULL, include_if_empty = TRUE, confirm = FALSE) {
  payload <- introstat_mutation_payload_from_board(board)
  if (operation %in% c("include", "exclude", "archive", "restore")) {
    key <- introstat_board_resolve(board, reference); id <- board$artifacts[[key]]$display_id
    if (operation == "archive" && !isTRUE(confirm) && isTRUE(board$artifacts[[key]]$include_in_report)) stop("Archiving a selected artifact requires explicit confirmation.", call. = FALSE)
    payload$included <- setdiff(payload$included, id); payload$archived <- setdiff(payload$archived, id)
    if (operation == "include") payload$included <- c(payload$included, id)
    if (operation == "archive") payload$archived <- c(payload$archived, id)
    return(payload)
  }
  if (operation == "add-section") {
    if (is.null(title)) stop("A new section title is required.", call. = FALSE)
    payload$sections <- append(payload$sections, list(list(section_id = NULL, client_new_id = paste0("client-", as.integer(Sys.time())), title = title, include_if_empty = TRUE, artifacts = character())), after = length(payload$sections) - 1L)
    return(payload)
  }
  if (operation == "rename-section") {
    id <- introstat_mutation_resolve_section(board, reference); if (identical(id, "unassigned")) stop("Unassigned cannot be renamed.", call. = FALSE)
    payload$sections[[match(id, vapply(payload$sections, `[[`, character(1), "section_id"))]]$title <- title %||% stop("A replacement section title is required.", call. = FALSE); return(payload)
  }
  if (operation == "remove-section") {
    id <- introstat_mutation_resolve_section(board, reference); if (identical(id, "unassigned")) stop("Unassigned cannot be removed.", call. = FALSE)
    from <- match(id, vapply(payload$sections, `[[`, character(1), "section_id")); unassigned <- length(payload$sections); payload$sections[[unassigned]]$artifacts <- c(payload$sections[[unassigned]]$artifacts, payload$sections[[from]]$artifacts); payload$sections <- payload$sections[-from]; return(payload)
  }
  if (operation == "move-section") {
    id <- introstat_mutation_resolve_section(board, reference); if (identical(id, "unassigned")) stop("Unassigned must remain final.", call. = FALSE)
    values <- vapply(payload$sections[-length(payload$sections)], `[[`, character(1), "section_id"); anchor_id <- if (!is.null(anchor)) introstat_mutation_resolve_section(board, anchor) else NULL; values <- introstat_mutation_move(values, id, position, anchor_id); ordered <- lapply(values, function(x) payload$sections[[match(x, vapply(payload$sections, `[[`, character(1), "section_id"))]]); payload$sections <- c(ordered, list(payload$sections[[length(payload$sections)]])); return(payload)
  }
  if (operation == "move-artifact") {
    key <- introstat_board_resolve(board, reference); id <- board$artifacts[[key]]$display_id; target <- introstat_mutation_resolve_section(board, section); if (identical(target, "unassigned") && position %in% c("before", "after")) stop("Unassigned has no section anchor.", call. = FALSE)
    for (i in seq_along(payload$sections)) payload$sections[[i]]$artifacts <- payload$sections[[i]]$artifacts[payload$sections[[i]]$artifacts != id]
    dest <- match(target, vapply(payload$sections, `[[`, character(1), "section_id")); values <- payload$sections[[dest]]$artifacts
    anchor_id <- if (position %in% c("before", "after")) { anchor_key <- introstat_board_resolve(board, anchor); board$artifacts[[anchor_key]]$display_id } else NULL
    payload$sections[[dest]]$artifacts <- introstat_mutation_move(values, id, position, anchor_id); return(payload)
  }
  stop("Unknown board mutation operation: ", operation, call. = FALSE)
}

introstat_analysis_board_operation <- function(root, operation, reference = NULL, title = NULL, section = NULL, position = "end", anchor = NULL, include_if_empty = TRUE, confirm = FALSE, timeout_ms = 10000, timeout = NULL) {
  if (!exists("introstat_with_workspace_lock", mode = "function")) source(file.path(root, "R", "workspace_lock.R"))
  result <- NULL
  introstat_with_workspace_lock(root, function() {
    persisted_path <- introstat_board_path(root)
    persisted <- if (file.exists(persisted_path)) yaml::read_yaml(persisted_path) else NULL
    board <- introstat_sync_analysis_board_unlocked(root, persist = FALSE)
    if (!is.null(persisted)) board$revision <- introstat_mutation_integer(persisted$revision, "board revision", 1L)
    payload <- introstat_analysis_board_operation_payload(board, operation, reference, title, section, position, anchor, include_if_empty, confirm)
    result <<- introstat_analysis_board_apply_payload_unlocked(board, payload, root)
    if (isTRUE(attr(result, "changed"))) introstat_board_write_unlocked(result, root, expected_revision = board$revision)
  }, timeout_ms = timeout_ms, timeout = timeout)
  result
}
