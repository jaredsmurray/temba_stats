# Frozen report-ready snapshots and preparation-plan primitives.

if (!exists("%||%", mode = "function")) `%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x

introstat_snapshot_safe_slug <- function(value) is.character(value) && length(value) == 1L && grepl("^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$", value, perl = TRUE)
introstat_snapshot_hash <- function(path) {
  if (!file.exists(path) || dir.exists(path) || introstat_is_symlink(path)) stop("Missing or linked snapshot file: ", path, call. = FALSE)
  hash <- unname(tools::md5sum(path))
  if (!is.character(hash) || length(hash) != 1L || !grepl("^[0-9a-f]{32}$", hash)) stop("Could not compute a lowercase MD5 hash for ", path, call. = FALSE)
  hash
}
introstat_snapshot_relpath <- function(path, root) {
  resolved <- normalizePath(path, mustWork = TRUE); base <- normalizePath(root, mustWork = TRUE); prefix <- paste0(base, .Platform$file.sep)
  if (!startsWith(resolved, prefix)) stop("Snapshot path escapes its workspace.", call. = FALSE)
  substring(resolved, nchar(prefix) + 1L)
}
introstat_snapshot_exact_fields <- function(value, required, optional = character(), label = "snapshot") {
  if (!is.list(value)) stop(label, " manifest must be a mapping.", call. = FALSE)
  fields <- names(value) %||% character(); allowed <- c(required, optional)
  if (anyDuplicated(fields) || any(!fields %in% allowed) || any(!required %in% fields)) stop(label, " manifest has invalid fields.", call. = FALSE)
  invisible(value)
}
introstat_snapshot_scalar <- function(value, label, allow_null = FALSE) {
  if (allow_null && is.null(value)) return(NULL)
  if (!is.character(value) || length(value) != 1L || is.na(value) || !nzchar(value) || !identical(value, trimws(value))) stop(label, " must be a trimmed non-empty string.", call. = FALSE)
  value
}

introstat_snapshot_render <- function(object, type, output_dir) {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  validate_artifact(object, type)
  if (identical(type, "plot")) return(render_artifact(object, type, output_dir, stem = "artifact"))
  if (!requireNamespace("flextable", quietly = TRUE) || !requireNamespace("htmltools", quietly = TRUE)) {
    stop("Packages flextable and htmltools are required for table snapshots.", call. = FALSE)
  }
  rendered <- htmltools::renderTags(flextable::htmltools_value(object))
  dependency_text <- function(dependency, field) {
    files <- as.character(dependency[[field]] %||% character())
    if (!length(files)) return(character())
    base <- as.character(dependency$src$file %||% "")
    paths <- file.path(base, files)
    if (!nzchar(base) || any(!file.exists(paths)) || any(dir.exists(paths))) stop("Could not inline a table preview dependency.", call. = FALSE)
    unlist(lapply(paths, readLines, warn = FALSE), use.names = FALSE)
  }
  styles <- unlist(lapply(rendered$dependencies, dependency_text, field = "stylesheet"), use.names = FALSE)
  scripts <- unlist(lapply(rendered$dependencies, dependency_text, field = "script"), use.names = FALSE)
  if (length(scripts)) scripts <- gsub("</script", "<\\/script", scripts, fixed = TRUE)
  path <- file.path(output_dir, "artifact.html")
  writeLines(c(
    "<!doctype html>",
    "<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">",
    "<style>.introstat-table-scroll{max-width:100%;overflow-x:auto;padding:2px;}", styles, "</style>",
    if (length(scripts)) c("<script>", scripts, "</script>") else character(),
    "</head><body><div class=\"introstat-table-scroll\">", as.character(rendered$html), "</div></body></html>"
  ), path, useBytes = TRUE)
  path
}

introstat_report_ready_manifest_validate <- function(manifest, directory = NULL) {
  required <- c("schema_version", "status", "slug", "display_id", "title", "artifact_type", "object", "artifacts", "reproduction_source", "source_analysis", "source_object_hash", "object_hash", "artifact_hash", "report_ready_at")
  optional <- c("width", "height", "problem", "question", "section_id", "tags", "report_order")
  introstat_snapshot_exact_fields(manifest, required, optional, "Report-ready")
  if (!is.numeric(manifest$schema_version) || length(manifest$schema_version) != 1L || is.na(manifest$schema_version) || manifest$schema_version != 1) stop("Report-ready schema_version must be 1.", call. = FALSE)
  if (!identical(manifest$status, "report_ready")) stop("Report-ready status must be report_ready.", call. = FALSE)
  slug <- introstat_snapshot_scalar(manifest$slug, "Report-ready slug"); if (!introstat_snapshot_safe_slug(slug)) stop("Report-ready slug is unsafe.", call. = FALSE)
  display_id <- introstat_snapshot_scalar(manifest$display_id, "Report-ready display_id")
  introstat_snapshot_scalar(manifest$title, "Report-ready title")
  type <- introstat_snapshot_scalar(manifest$artifact_type, "Report-ready artifact_type"); if (!type %in% c("plot", "table", "regression_table", "summary_table")) stop("Unsupported report-ready artifact_type: ", type, call. = FALSE)
  if (!introstat_board_valid_display_id(display_id, type)) stop("Report-ready display_id does not match artifact_type.", call. = FALSE)
  if (!identical(manifest$object, "object.rds") || !identical(manifest$reproduction_source, "reproduce.R")) stop("Report-ready object and reproduction paths are fixed.", call. = FALSE)
  artifacts <- manifest$artifacts; if (is.character(artifacts) && length(artifacts) == 1L) artifacts <- list(artifacts); valid_artifacts <- is.list(artifacts) && length(artifacts) == 1L && is.character(artifacts[[1]]) && isTRUE(grepl("^files/artifact[.](png|html)$", artifacts[[1]], perl = TRUE)); if (!isTRUE(valid_artifacts)) stop("Report-ready artifacts must contain exactly files/artifact.png or files/artifact.html.", call. = FALSE)
  expected_artifact <- if (identical(type, "plot")) "files/artifact.png" else "files/artifact.html"
  if (!identical(artifacts[[1]], expected_artifact)) stop("Report-ready artifact file does not match artifact_type.", call. = FALSE)
  for (name in c("source_analysis", "source_object_hash", "object_hash", "artifact_hash", "report_ready_at")) introstat_snapshot_scalar(manifest[[name]], paste0("Report-ready ", name))
  if (!identical(manifest$source_analysis, paste("analysis", slug, "analysis.R", sep = "/"))) stop("Report-ready source_analysis must point to the matching analysis.R.", call. = FALSE)
  for (name in c("width", "height", "report_order")) if (!is.null(manifest[[name]]) && (!is.numeric(manifest[[name]]) || length(manifest[[name]]) != 1L || is.na(manifest[[name]]) || !is.finite(manifest[[name]]) || manifest[[name]] <= 0)) stop("Report-ready ", name, " must be a positive scalar.", call. = FALSE)
  for (name in c("problem", "question", "section_id")) if (!is.null(manifest[[name]])) introstat_snapshot_scalar(manifest[[name]], paste0("Report-ready ", name))
  if (!is.null(manifest$tags)) { tags <- if (is.list(manifest$tags)) unlist(manifest$tags, use.names = FALSE) else manifest$tags; if (!is.character(tags) || any(!vapply(tags, function(x) length(x) == 1L && nzchar(x) && identical(x, trimws(x)), logical(1)))) stop("Report-ready tags must be trimmed strings.", call. = FALSE) }
  for (name in c("source_object_hash", "object_hash", "artifact_hash")) if (!grepl("^[0-9a-f]{32}$", manifest[[name]])) stop("Report-ready ", name, " must be a lowercase MD5.", call. = FALSE)
  if (!identical(manifest$source_object_hash, manifest$object_hash)) stop("The frozen object must be an exact copy of the validated analysis object.", call. = FALSE)
  if (!is.null(directory)) {
    if (!identical(slug, basename(normalizePath(directory, mustWork = TRUE)))) stop("Report-ready slug must match its directory.", call. = FALSE)
    reproduce_path <- file.path(directory, manifest$reproduction_source); object_path <- file.path(directory, manifest$object); artifact_path <- file.path(directory, manifest$artifacts[[1]])
    if (introstat_is_symlink(directory) || introstat_is_symlink(reproduce_path) || introstat_is_symlink(object_path) || introstat_is_symlink(artifact_path) || !file.exists(reproduce_path) || dir.exists(reproduce_path) || !file.exists(object_path) || dir.exists(object_path) || !file.exists(artifact_path) || dir.exists(artifact_path)) stop("Report-ready snapshot has missing or linked files.", call. = FALSE)
    if (!identical(introstat_snapshot_hash(object_path), manifest$object_hash) || !identical(introstat_snapshot_hash(artifact_path), manifest$artifact_hash)) stop("Report-ready snapshot hashes do not match its manifest.", call. = FALSE)
  }
  invisible(manifest)
}

introstat_report_ready_discover <- function(root) {
  store <- file.path(root, "report_ready"); if (!dir.exists(store) || introstat_is_symlink(store)) stop("Missing or linked report_ready directory.", call. = FALSE)
  store_entries <- list.files(store, all.files = TRUE, no.. = TRUE)
  if (any(vapply(store_entries, function(entry) !introstat_snapshot_safe_slug(entry) || !dir.exists(file.path(store, entry)) || introstat_is_symlink(file.path(store, entry)), logical(1)))) stop("Report-ready store entries must be non-linked safe-slug directories.", call. = FALSE)
  paths <- list.files(store, pattern = "^manifest\\.ya?ml$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  all_manifests <- list.files(store, pattern = "^manifest\\.(?:yaml|yml|json)$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  rel <- function(x) substring(normalizePath(x, mustWork = FALSE), nchar(paste0(normalizePath(store, mustWork = TRUE), .Platform$file.sep)) + 1L)
  if (length(all_manifests) != length(paths) || any(vapply(all_manifests, function(x) { bits <- strsplit(rel(x), .Platform$file.sep, fixed = TRUE)[[1]]; length(bits) != 2L || !identical(bits[[2]], "manifest.yaml") || !introstat_snapshot_safe_slug(bits[[1]]) }, logical(1)))) stop("Report-ready manifests must be exactly report_ready/<slug>/manifest.yaml.", call. = FALSE)
  if (!length(paths)) return(list())
  records <- lapply(paths, function(path) {
    if (introstat_is_symlink(path) || introstat_is_symlink(dirname(path))) stop("Report-ready paths cannot be symbolic links.", call. = FALSE)
    directory <- dirname(path); entries <- list.files(directory, all.files = TRUE, no.. = TRUE); expected <- c("manifest.yaml", "object.rds", "reproduce.R", "files"); if (!setequal(entries, expected) || !dir.exists(file.path(directory, "files")) || introstat_is_symlink(file.path(directory, "files"))) stop("Report-ready snapshots must contain exactly manifest.yaml, object.rds, reproduce.R, and files/.", call. = FALSE); file_entries <- list.files(file.path(directory, "files"), all.files = TRUE, no.. = TRUE); if (length(file_entries) != 1L || !grepl("^artifact[.](png|html)$", file_entries[[1]], perl = TRUE)) stop("Report-ready files/ must contain exactly one artifact.", call. = FALSE)
    manifest <- yaml::read_yaml(path); introstat_report_ready_manifest_validate(manifest, directory)
    list(slug = manifest$slug, display_id = manifest$display_id, title = manifest$title, artifact_type = manifest$artifact_type, manifest = path, manifest_data = manifest, directory = dirname(path), object = file.path(dirname(path), "object.rds"), object_hash = manifest$object_hash, artifact_hash = manifest$artifact_hash, section_id = manifest$section_id %||% NULL)
  })
  keys <- vapply(records, `[[`, character(1), "slug"); if (anyDuplicated(keys) || anyDuplicated(toupper(vapply(records, `[[`, character(1), "display_id")))) stop("Report-ready slugs and display IDs must be unique.", call. = FALSE)
  records
}

introstat_snapshot_stage <- function(root, board, slug, metadata = list()) {
  if (!slug %in% names(board$artifacts)) stop("Unknown analysis slug: ", slug, call. = FALSE)
  item <- board$artifacts[[slug]]; type <- as.character(item$artifact_type %||% ""); if (!type %in% c("plot", "table", "regression_table", "summary_table") || !introstat_board_valid_display_id(item$display_id, type)) stop("Board artifact has an unsupported type or incompatible display ID.", call. = FALSE)
  analysis_dir <- file.path(root, "analysis", slug); manifest_path <- file.path(analysis_dir, "manifest.yaml"); object_path <- file.path(analysis_dir, "object.rds")
  if (!dir.exists(analysis_dir) || introstat_is_symlink(analysis_dir) || !file.exists(manifest_path) || introstat_is_symlink(manifest_path) || !file.exists(object_path) || introstat_is_symlink(object_path)) stop("Analysis has no validated object: ", slug, call. = FALSE)
  manifest <- yaml::read_yaml(manifest_path); required <- c("slug", "title", "artifact_type", "object", "source", "artifacts"); if (!is.list(manifest) || any(!required %in% (names(manifest) %||% character())) || !identical(as.character(manifest$slug), slug) || !identical(as.character(manifest$artifact_type), type) || !identical(as.character(manifest$object), "object.rds") || !identical(as.character(manifest$source), "analysis.R")) stop("Analysis manifest is malformed or does not match the board.", call. = FALSE)
  source_name <- "analysis.R"; source_path <- file.path(analysis_dir, source_name); if (!file.exists(source_path) || introstat_is_symlink(source_path)) stop("Missing analysis source: ", source_path, call. = FALSE)
  stage <- tempfile(paste0(".", slug, "-snapshot-"), tmpdir = file.path(root, "report_ready")); dir.create(file.path(stage, "files"), recursive = TRUE)
  if (!file.copy(object_path, file.path(stage, "object.rds"), overwrite = TRUE)) stop("Could not freeze the analysis object.", call. = FALSE)
  frozen_object <- readRDS(file.path(stage, "object.rds")); validate_artifact(frozen_object, type)
  type_for_file <- if (identical(type, "plot")) "png" else "html"; artifact_path <- introstat_snapshot_render(frozen_object, type, file.path(stage, "files"))
  if (!identical(type_for_file, tools::file_ext(artifact_path))) { target_artifact <- file.path(stage, "files", paste0("artifact.", type_for_file)); file.rename(artifact_path, target_artifact); artifact_path <- target_artifact }
  writeLines(c("if (!exists(\"introstat_report_header_loaded\")) source(\"R/analysis_header.R\")", "", readLines(source_path, warn = FALSE)), file.path(stage, "reproduce.R"), useBytes = TRUE)
  title <- metadata$title %||% manifest$title %||% item$last_known_title; old <- metadata$existing %||% list()
  fields <- c("problem", "question", "section_id", "tags", "report_order", "width", "height"); values <- list(schema_version = 1L, status = "report_ready", slug = slug, display_id = item$display_id, title = title, artifact_type = type, object = "object.rds", artifacts = list(paste0("files/", basename(artifact_path))), reproduction_source = "reproduce.R", source_analysis = paste("analysis", slug, source_name, sep = "/"), source_object_hash = introstat_snapshot_hash(object_path), object_hash = introstat_snapshot_hash(file.path(stage, "object.rds")), artifact_hash = introstat_snapshot_hash(artifact_path), report_ready_at = format(Sys.time(), tz = "UTC", usetz = TRUE))
  for (field in fields) { value <- metadata[[field]] %||% old[[field]]; if (!is.null(value)) values[[field]] <- value }
  yaml::write_yaml(values, file.path(stage, "manifest.yaml")); introstat_report_ready_manifest_validate(values)
  attr(stage, "manifest") <- values; stage
}

introstat_report_plan_hash <- function(binding) {
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("Package jsonlite is required for report tokens.", call. = FALSE)
  stage <- tempfile("report-token-"); on.exit(unlink(stage, force = TRUE), add = TRUE)
  bytes <- charToRaw(jsonlite::toJSON(binding, auto_unbox = TRUE, null = "null", digits = NA, pretty = FALSE))
  writeBin(bytes, stage); introstat_snapshot_hash(stage)
}
