# Shared setup for standalone and compiled analysis scripts.
# Assignment distributions may extend this file with package calls and data loads.

source("R/harness_utils.R")

if (file.exists("R/problem_setup.R")) {
  source("R/problem_setup.R")
}

source("R/report_runtime.R")

introstat_report_header_loaded <- TRUE
