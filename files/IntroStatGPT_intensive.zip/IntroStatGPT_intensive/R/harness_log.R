`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x

introstat_logging_enabled <- function(root) {
  any(file.exists(file.path(root, c(
    ".intro-stat-gpt-diagnostics",
    ".intro-stat-gpt-instructor-pilot"
  ))))
}

introstat_log_version <- function(root) {
  for (name in c("HARNESS_VERSION.txt", "VERSION")) {
    path <- file.path(root, name)
    if (file.exists(path)) {
      first <- readLines(path, warn = FALSE, n = 1L)
      if (length(first)) return(trimws(sub("^Harness-Version:", "", first)))
    }
  }
  "unknown"
}

introstat_error_category <- function(error) {
  message <- tolower(conditionMessage(error))
  if (grepl("missing|required.*package|could not find function|there is no package", message)) return("missing_input_or_dependency")
  if (grepl("valid|unsupported|must be|wrong object|cannot|unsafe|forbidden", message)) return("validation_error")
  if (grepl("exists|replace|unique|more than one|no analysis matches", message)) return("state_conflict")
  if (grepl("render|quarto|pandoc|docx|png|html", message)) return("render_error")
  "execution_error"
}

introstat_append_jsonl <- function(path, record) {
  if (!requireNamespace("jsonlite", quietly = TRUE)) return(invisible(NULL))
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  cat(
    jsonlite::toJSON(record, auto_unbox = TRUE, null = "null"),
    "\n", file = path, append = TRUE, sep = ""
  )
  invisible(NULL)
}

introstat_run_workflow <- function(root, event, code) {
  root <- normalizePath(root, mustWork = TRUE)
  started <- Sys.time()
  finish <- function(status, context = list(), error = NULL) {
    if (!introstat_logging_enabled(root)) return(invisible(NULL))
    allowed <- c("artifact_id", "artifact_type", "operation", "artifact_count")
    context <- context[intersect(names(context), allowed)]
    record <- c(list(
      recorded_at = format(Sys.time(), tz = "UTC", usetz = TRUE),
      event = event,
      status = status,
      duration_ms = as.integer(round(as.numeric(difftime(Sys.time(), started, units = "secs")) * 1000)),
      error_category = if (is.null(error)) NULL else introstat_error_category(error),
      harness_version = introstat_log_version(root)
    ), context)
    introstat_append_jsonl(file.path(root, "generated", "diagnostics", "workflow.jsonl"), record)
    if (file.exists(file.path(root, ".intro-stat-gpt-instructor-pilot"))) {
      rich <- c(record, list(
        command = commandArgs(trailingOnly = TRUE),
        error_message = if (is.null(error)) NULL else conditionMessage(error)
      ))
      introstat_append_jsonl(file.path(root, "generated", "pilot_debug", "workflow_trace.jsonl"), rich)
    }
    invisible(NULL)
  }
  tryCatch({
    context <- force(code)
    if (!is.list(context)) context <- list()
    finish("success", context)
    invisible(context)
  }, error = function(error) {
    finish("error", error = error)
    stop(error)
  })
}
