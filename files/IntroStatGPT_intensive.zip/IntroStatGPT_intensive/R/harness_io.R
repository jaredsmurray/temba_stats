introstat_root <- function(start = getwd()) {
  current <- normalizePath(start, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "AGENTS.md")) && dir.exists(file.path(current, "R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate the assignment root.", call. = FALSE)
    current <- parent
  }
}

`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x

write_manifest <- function(path, values) {
  if (isTRUE(getOption("introstat.fail_manifest_write", FALSE)) || identical(Sys.getenv("INTROSTAT_FAIL_MANIFEST_WRITE", ""), "1")) stop("Injected manifest write failure.", call. = FALSE)
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  yaml::write_yaml(values, path)
}

read_manifest <- function(path) {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  yaml::read_yaml(path)
}

artifact_visible_title <- function(manifest) {
  title <- as.character(manifest$title %||% "Untitled analysis")
  display_id <- toupper(as.character(manifest$display_id %||% ""))
  if (!nzchar(display_id)) return(title)
  if (startsWith(toupper(title), paste0(display_id, ":"))) return(title)
  paste0(display_id, ": ", title)
}

# Compatibility hook for renderer-era callers; the board owns allocation.
ensure_analysis_display_ids <- function(root) invisible(NULL)
