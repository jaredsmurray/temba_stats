introstat_read_report_manifest <- function(path) {
  extension <- tolower(tools::file_ext(path))
  if (extension %in% c("yaml", "yml")) {
    if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
    return(yaml::read_yaml(path))
  }
  if (identical(extension, "json")) {
    if (!requireNamespace("jsonlite", quietly = TRUE)) stop("Package jsonlite is required.", call. = FALSE)
    return(jsonlite::fromJSON(path, simplifyVector = TRUE))
  }
  stop("Unsupported report manifest: ", path, call. = FALSE)
}

introstat_first_nonempty <- function(...) {
  values <- list(...)
  for (value in values) {
    if (!is.null(value) && length(value) == 1L && !is.na(value) && nzchar(as.character(value))) {
      return(as.character(value))
    }
  }
  NULL
}

introstat_problem_id <- function(value) {
  if (is.null(value) || !length(value) || is.na(value) || !nzchar(as.character(value))) return(NULL)
  match <- regmatches(as.character(value), regexpr("(?:^|[^[:alnum:]])(?:problem[ _-]*|p)([0-9]+)(?:[^0-9]|$)", tolower(as.character(value)), perl = TRUE))
  if (!length(match) || !nzchar(match)) {
    if (grepl("^[0-9]+$", as.character(value))) return(paste0("p", as.integer(value)))
    return(NULL)
  }
  number <- regmatches(match, regexpr("[0-9]+", match))
  if (length(number) && nzchar(number)) paste0("p", as.integer(number)) else NULL
}

introstat_script_problem_hint <- function(path) {
  if (!file.exists(path)) return(NULL)
  lines <- readLines(path, warn = FALSE, n = 30L)
  marker <- grep("^#[[:space:]]*(problem|question)[[:space:]]*:", lines, ignore.case = TRUE, value = TRUE)
  if (!length(marker)) return(NULL)
  sub("^#[[:space:]]*(problem|question)[[:space:]]*:[[:space:]]*", "", marker[[1]], ignore.case = TRUE)
}

introstat_infer_problem <- function(manifest, manifest_path, source_path) {
  explicit <- introstat_first_nonempty(manifest$problem, manifest$question_id, manifest$question)
  explicit_id <- introstat_problem_id(explicit)
  if (!is.null(explicit_id)) return(list(problem = explicit_id, method = "manifest"))

  path_id <- introstat_problem_id(gsub("\\\\", "/", dirname(manifest_path)))
  if (!is.null(path_id)) return(list(problem = path_id, method = "path"))

  script_id <- introstat_problem_id(introstat_script_problem_hint(source_path))
  if (!is.null(script_id)) return(list(problem = script_id, method = "script-comment"))

  name_hint <- paste(basename(dirname(manifest_path)), basename(source_path), manifest$title %||% "")
  name_id <- introstat_problem_id(name_hint)
  if (!is.null(name_id)) return(list(problem = name_id, method = "name"))

  list(problem = NULL, method = "unassigned")
}

`%||%` <- function(x, y) if (is.null(x)) y else x

introstat_report_source_path <- function(manifest, directory) {
  candidates <- c(
    manifest$reproduction_source,
    manifest$source,
    "reproduce.R",
    "artifact.R"
  )
  candidates <- unique(candidates[!is.na(candidates) & nzchar(candidates)])
  paths <- file.path(directory, candidates)
  hits <- paths[file.exists(paths)]
  if (!length(hits)) {
    stop("Report-ready item has no reproduction R script: ", directory, call. = FALSE)
  }
  normalizePath(hits[[1]], mustWork = TRUE)
}

introstat_discover_report_ready <- function(root = getwd()) {
  store <- file.path(root, "report_ready")
  if (!dir.exists(store)) stop("Missing report_ready/ directory.", call. = FALSE)
  manifests <- list.files(
    store,
    pattern = "^manifest\\.(?:yaml|yml|json)$",
    recursive = TRUE,
    full.names = TRUE,
    ignore.case = TRUE
  )
  if (!length(manifests)) stop("No report-ready manifests were found.", call. = FALSE)

  specs <- lapply(manifests, function(path) {
    manifest <- introstat_read_report_manifest(path)
    status <- tolower(as.character(manifest$status %||% "report_ready"))
    if (!status %in% c("report_ready", "report-ready", "locked")) return(NULL)
    directory <- dirname(path)
    source <- introstat_report_source_path(manifest, directory)
    problem <- introstat_infer_problem(manifest, path, source)
    artifact_type <- as.character(manifest$artifact_type %||% manifest$type %||% "")
    if (!artifact_type %in% c("plot", "table", "regression_table", "summary_table")) {
      stop("Unknown artifact_type in ", path, ": ", artifact_type, call. = FALSE)
    }
    list(
      key = basename(directory),
      title = as.character(manifest$title %||% basename(directory)),
      problem = problem$problem,
      problem_inference = problem$method,
      question = introstat_first_nonempty(manifest$question_id, manifest$question),
      section_hint = introstat_first_nonempty(manifest$section_id, manifest$section),
      tags = as.character(unlist(manifest$tags %||% character(), use.names = FALSE)),
      artifact_type = artifact_type,
      width = manifest$width,
      height = manifest$height,
      order = suppressWarnings(as.numeric(manifest$report_order %||% manifest$order %||% Inf)),
      ready_at = as.character(manifest$report_ready_at %||% manifest$locked_at %||% ""),
      source = source,
      manifest = normalizePath(path, mustWork = TRUE)
    )
  })
  specs <- Filter(Negate(is.null), specs)
  if (!length(specs)) stop("No manifests have report-ready status.", call. = FALSE)

  problem_number <- vapply(specs, function(x) {
    if (is.null(x$problem)) return(Inf)
    as.numeric(sub("^p", "", x$problem))
  }, numeric(1))
  report_order <- vapply(specs, function(x) x$order, numeric(1))
  ready_at <- vapply(specs, function(x) x$ready_at, character(1))
  title <- vapply(specs, function(x) x$title, character(1))
  specs[order(problem_number, report_order, ready_at, title, na.last = TRUE)]
}

introstat_relative_path <- function(path, root) {
  normalized_path <- normalizePath(path, mustWork = FALSE)
  normalized_root <- normalizePath(root, mustWork = TRUE)
  prefix <- paste0(normalized_root, .Platform$file.sep)
  if (startsWith(normalized_path, prefix)) substring(normalized_path, nchar(prefix) + 1L) else normalized_path
}

introstat_slug <- function(value) {
  slug <- gsub("[^a-z0-9]+", "-", tolower(trimws(as.character(value))))
  slug <- gsub("^-|-$", "", slug)
  if (nzchar(slug)) slug else "section"
}

introstat_character_values <- function(value) {
  if (is.null(value)) return(character())
  as.character(unlist(value, use.names = FALSE))
}

introstat_read_report_outline <- function(path) {
  if (!file.exists(path)) stop("Missing student-editable report scaffold: ", path, call. = FALSE)
  outline <- introstat_read_report_manifest(path)
  if (is.null(outline$sections) || !length(outline$sections)) {
    stop("Report scaffold must define at least one section.", call. = FALSE)
  }
  sections <- lapply(seq_along(outline$sections), function(i) {
    section <- outline$sections[[i]]
    title <- introstat_first_nonempty(section$title, section$id)
    if (is.null(title)) stop("Every report section needs an id or title.", call. = FALSE)
    list(
      id = introstat_first_nonempty(section$id, introstat_slug(title)),
      title = title,
      include_if_empty = TRUE,
      default = isTRUE(section$default),
      match = section$match %||% list()
    )
  })
  ids <- vapply(sections, function(x) x$id, character(1))
  if (anyDuplicated(ids)) stop("Report scaffold section ids must be unique.", call. = FALSE)
  if (sum(vapply(sections, function(x) x$default, logical(1))) > 1L) {
    stop("At most one report scaffold section may be marked default.", call. = FALSE)
  }
  structure(
    list(
      version = outline$version %||% 1,
      title = outline$title %||% "Statistical analysis report skeleton",
      subtitle = outline$subtitle %||% NULL,
      sections = sections
    ),
    class = "introstat_report_outline"
  )
}

introstat_match_outline_section <- function(outline, spec) {
  if (!is.null(spec$section_hint)) {
    hints <- tolower(c(spec$section_hint))
    exact <- which(vapply(outline$sections, function(x) tolower(x$id) %in% hints || tolower(x$title) %in% hints, logical(1)))
    if (length(exact)) return(outline$sections[[exact[[1]]]]$id)
  }

  for (section in outline$sections) {
    rules <- section$match %||% list()
    problems <- tolower(introstat_character_values(rules$problems %||% rules$problem))
    questions <- tolower(introstat_character_values(rules$questions %||% rules$question_ids))
    tags <- tolower(introstat_character_values(rules$tags))
    patterns <- introstat_character_values(rules$title_patterns)
    matched <- FALSE
    if (length(problems) && !is.null(spec$problem)) matched <- matched || tolower(spec$problem) %in% problems
    if (length(questions) && !is.null(spec$question)) matched <- matched || tolower(spec$question) %in% questions
    if (length(tags) && length(spec$tags)) matched <- matched || any(tolower(spec$tags) %in% tags)
    if (length(patterns)) {
      matched <- matched || any(vapply(patterns, function(pattern) {
        tryCatch(grepl(pattern, spec$title, ignore.case = TRUE, perl = TRUE), error = function(e) FALSE)
      }, logical(1)))
    }
    if (matched) return(section$id)
  }

  default <- Filter(function(x) isTRUE(x$default), outline$sections)
  if (length(default)) return(default[[1]]$id)
  "unassigned-outputs"
}

introstat_suggest_report_plan <- function(specs, outline) {
  sections <- lapply(outline$sections, function(x) {
    list(id = x$id, title = x$title, include_if_empty = TRUE, origin = "scaffold")
  })
  section_ids <- vapply(sections, function(x) x$id, character(1))
  items <- vector("list", length(specs))
  for (i in seq_along(specs)) {
    spec <- specs[[i]]
    section_id <- introstat_match_outline_section(outline, spec)
    if (!section_id %in% section_ids) {
      sections[[length(sections) + 1L]] <- list(
        id = section_id,
        title = "Unassigned outputs",
        include_if_empty = FALSE,
        origin = "generated"
      )
      section_ids <- c(section_ids, section_id)
    }
    items[[i]] <- list(key = spec$key, title = spec$title, section_id = section_id, artifact_type = spec$artifact_type)
  }
  structure(
    list(title = outline$title, subtitle = outline$subtitle, sections = sections, items = items),
    class = "introstat_report_plan"
  )
}

introstat_write_report_plan <- function(plan, path) {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  yaml::write_yaml(unclass(plan), path)
  invisible(normalizePath(path, mustWork = TRUE))
}

introstat_read_report_plan <- function(path) {
  if (!file.exists(path)) stop("Missing report plan: ", path, call. = FALSE)
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  plan <- yaml::read_yaml(path)
  if (is.null(plan$sections) || !length(plan$sections)) stop("Report plan contains no sections.", call. = FALSE)
  if (is.null(plan$items)) plan$items <- list()
  structure(plan, class = "introstat_report_plan")
}

introstat_sync_report_plan <- function(plan, specs, outline) {
  suggested <- introstat_suggest_report_plan(specs, outline)
  old_section_ids <- vapply(plan$sections, function(x) x$id, character(1))
  new_section_ids <- vapply(suggested$sections, function(x) x$id, character(1))
  custom <- plan$sections[
    !old_section_ids %in% new_section_ids &
      vapply(plan$sections, function(x) is.null(x$origin) || identical(x$origin, "custom"), logical(1))
  ]
  if (length(custom)) suggested$sections <- c(suggested$sections, custom)
  old_keys <- vapply(plan$items, function(x) x$key, character(1))
  valid_sections <- vapply(suggested$sections, function(x) x$id, character(1))
  suggested$sections <- lapply(suggested$sections, function(section) {
    section$include_if_empty <- if (identical(section$id, "unassigned-outputs")) FALSE else TRUE
    section
  })
  for (i in seq_along(suggested$items)) {
    match_index <- match(suggested$items[[i]]$key, old_keys)
    if (!is.na(match_index) && plan$items[[match_index]]$section_id %in% valid_sections) {
      suggested$items[[i]]$section_id <- plan$items[[match_index]]$section_id
    }
  }
  suggested
}

introstat_match_plan_item <- function(plan, query) {
  query <- trimws(tolower(query))
  keys <- vapply(plan$items, function(x) tolower(x$key), character(1))
  titles <- vapply(plan$items, function(x) tolower(x$title), character(1))
  exact <- which(keys == query | titles == query)
  if (length(exact) == 1L) return(exact)
  partial <- which(grepl(query, keys, fixed = TRUE) | grepl(query, titles, fixed = TRUE))
  if (length(partial) == 1L) return(partial)
  if (!length(c(exact, partial))) stop("No report-ready item matches: ", query, call. = FALSE)
  stop("More than one report-ready item matches: ", query, call. = FALSE)
}

introstat_match_plan_section <- function(plan, query) {
  query <- trimws(tolower(query))
  ids <- vapply(plan$sections, function(x) tolower(x$id), character(1))
  titles <- vapply(plan$sections, function(x) tolower(x$title), character(1))
  exact <- which(ids == query | titles == query)
  if (length(exact) == 1L) return(exact)
  partial <- which(grepl(query, ids, fixed = TRUE) | grepl(query, titles, fixed = TRUE))
  if (length(partial) == 1L) return(partial)
  integer()
}

introstat_move_report_item <- function(plan, item, section) {
  item_index <- introstat_match_plan_item(plan, item)
  section_index <- introstat_match_plan_section(plan, section)
  if (!length(section_index)) {
    base_id <- introstat_slug(section)
    ids <- vapply(plan$sections, function(x) x$id, character(1))
    section_id <- base_id
    suffix <- 2L
    while (section_id %in% ids) {
      section_id <- paste0(base_id, "-", suffix)
      suffix <- suffix + 1L
    }
    plan$sections[[length(plan$sections) + 1L]] <- list(
      id = section_id,
      title = as.character(section),
      include_if_empty = TRUE,
      origin = "custom"
    )
  } else {
    section_id <- plan$sections[[section_index[[1]]]]$id
  }
  plan$items[[item_index]]$section_id <- section_id
  plan
}

introstat_print_report_plan <- function(plan) {
  cat(plan$title, "\n")
  for (section in plan$sections) {
    cat("\n", section$title, "\n", sep = "")
    section_items <- Filter(function(x) identical(x$section_id, section$id), plan$items)
    if (!length(section_items)) cat("  (no report-ready artifacts)\n")
    for (item in section_items) {
      kind <- if (identical(item$artifact_type, "plot")) "Figure" else "Table"
      cat("  - ", item$title, " [", kind, "]\n", sep = "")
    }
  }
  invisible(plan)
}

introstat_apply_report_plan <- function(specs, plan) {
  spec_keys <- vapply(specs, function(x) x$key, character(1))
  plan_keys <- vapply(plan$items, function(x) x$key, character(1))
  if (anyDuplicated(spec_keys) || anyDuplicated(plan_keys)) stop("Report-ready keys must be unique.", call. = FALSE)
  missing <- setdiff(plan_keys, spec_keys)
  extra <- setdiff(spec_keys, plan_keys)
  if (length(missing)) stop("Report plan refers to missing item(s): ", paste(missing, collapse = ", "), call. = FALSE)
  if (length(extra)) stop("Report-ready item(s) are absent from the plan: ", paste(extra, collapse = ", "), call. = FALSE)

  section_ids <- vapply(plan$sections, function(x) x$id, character(1))
  item_section_ids <- vapply(plan$items, function(x) x$section_id, character(1))
  unknown_sections <- setdiff(item_section_ids, section_ids)
  if (length(unknown_sections)) {
    stop("Report plan item(s) refer to unknown section(s): ", paste(unknown_sections, collapse = ", "), call. = FALSE)
  }
  grouped_items <- unlist(
    lapply(section_ids, function(section_id) Filter(function(x) identical(x$section_id, section_id), plan$items)),
    recursive = FALSE
  )
  ordered <- lapply(grouped_items, function(item) {
    spec <- specs[[match(item$key, spec_keys)]]
    section <- plan$sections[[match(item$section_id, section_ids)]]
    spec$section_id <- section$id
    spec$section_title <- section$title
    spec$title <- item$title
    spec
  })
  list(specs = ordered, sections = plan$sections)
}

# Frozen-plan compiler contract.  Prepared plans are immutable inputs: the
# compiler validates their board binding and snapshot bytes, then reads only
# the preserved object.rds files.
introstat_frozen_plan_fields <- c("schema_version", "board_revision", "render_token", "title", "subtitle", "sections", "snapshots")
introstat_frozen_section_fields <- c("section_id", "title", "include_if_empty", "artifacts")
introstat_frozen_snapshot_fields <- c("display_id", "slug", "manifest", "manifest_hash", "object", "object_hash")
introstat_frozen_manifest_required <- c("schema_version", "status", "slug", "display_id", "title", "artifact_type", "object", "artifacts", "reproduction_source", "source_analysis", "source_object_hash", "object_hash", "artifact_hash", "report_ready_at")
introstat_frozen_manifest_optional <- c("width", "height", "problem", "question", "section_id", "tags", "report_order")

introstat_frozen_scalar <- function(value, label, allow_null = FALSE, allow_empty = FALSE) {
  if (allow_null && is.null(value)) return(NULL)
  if (!is.character(value) || length(value) != 1L || is.na(value) || (!allow_empty && !nzchar(value)) || !identical(value, trimws(value))) {
    stop(label, " must be a trimmed scalar string.", call. = FALSE)
  }
  value
}

introstat_frozen_bool <- function(value, label) {
  if (!is.logical(value) || length(value) != 1L || is.na(value)) stop(label, " must be a single boolean.", call. = FALSE)
  isTRUE(value)
}

introstat_frozen_integer <- function(value, label, minimum = 1L) {
  if (!is.numeric(value) || length(value) != 1L || is.na(value) || !is.finite(value) || value != floor(value) || value < minimum) {
    stop(label, " must be a finite whole number.", call. = FALSE)
  }
  as.integer(value)
}

introstat_frozen_md5 <- function(value, label) {
  value <- introstat_frozen_scalar(value, label)
  if (!grepl("^[0-9a-f]{32}$", value, perl = TRUE)) stop(label, " must be a lowercase md5 hash.", call. = FALSE)
  value
}

introstat_frozen_safe_slug <- function(value, label) {
  value <- introstat_frozen_scalar(value, label)
  if (!grepl("^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$", value, perl = TRUE)) stop(label, " must be a safe slug.", call. = FALSE)
  value
}

introstat_frozen_path <- function(root, relative, expected, must_work = TRUE) {
  relative <- introstat_frozen_scalar(relative, "snapshot path")
  if (!identical(relative, expected)) stop("Snapshot path must be exactly ", expected, ".", call. = FALSE)
  store <- file.path(root, "report_ready")
  if (!dir.exists(store) || nzchar(Sys.readlink(store))) stop("The report-ready store cannot be a symbolic link.", call. = FALSE)
  path <- file.path(root, relative)
  parent <- dirname(path)
  if (nzchar(Sys.readlink(parent)) || nzchar(Sys.readlink(path))) stop("Snapshot paths cannot traverse symbolic links.", call. = FALSE)
  resolved_root <- normalizePath(store, mustWork = TRUE)
  resolved <- normalizePath(path, mustWork = must_work)
  prefix <- paste0(resolved_root, .Platform$file.sep)
  if (!startsWith(resolved, prefix)) stop("Snapshot path escapes the report-ready store.", call. = FALSE)
  resolved
}

introstat_frozen_read_bytes <- function(path, label = "frozen snapshot file") {
  if (!file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path))) {
    stop("Missing or linked ", label, ": ", path, call. = FALSE)
  }
  size <- file.info(path)$size
  if (is.na(size) || !is.finite(size) || size < 0) stop("Could not determine the size of ", label, ": ", path, call. = FALSE)
  connection <- file(path, open = "rb")
  on.exit(close(connection), add = TRUE)
  bytes <- readBin(connection, what = "raw", n = size)
  if (length(bytes) != size) stop("Could not read the complete ", label, ": ", path, call. = FALSE)
  bytes
}

introstat_frozen_bytes_md5 <- function(bytes, label = "frozen snapshot") {
  if (!is.raw(bytes)) stop("Expected raw bytes for ", label, ".", call. = FALSE)
  staged <- tempfile(".frozen-bytes-")
  on.exit(unlink(staged, force = TRUE), add = TRUE)
  writeBin(bytes, staged)
  hash <- unname(tolower(as.character(tools::md5sum(staged))))
  if (length(hash) != 1L || is.na(hash) || !grepl("^[0-9a-f]{32}$", hash, perl = TRUE)) {
    stop("Could not compute a lowercase MD5 hash for ", label, ".", call. = FALSE)
  }
  hash
}

introstat_frozen_parse_manifest <- function(bytes) {
  if (!requireNamespace("yaml", quietly = TRUE)) stop("Package yaml is required.", call. = FALSE)
  yaml::yaml.load(rawToChar(bytes))
}

introstat_frozen_deserialize_object <- function(bytes) {
  connection <- rawConnection(bytes, open = "rb")
  on.exit(close(connection), add = TRUE)
  # saveRDS() commonly uses gzip compression. Decode that stream directly
  # from the preserved bytes; uncompressed RDS bytes use the raw connection.
  if (length(bytes) >= 2L && identical(bytes[1:2], as.raw(c(0x1f, 0x8b)))) {
    connection <- gzcon(connection)
  }
  readRDS(connection)
}

introstat_frozen_file_md5 <- function(path) {
  introstat_frozen_bytes_md5(introstat_frozen_read_bytes(path), path)
}

introstat_frozen_manifest_record <- function(snapshot, root) {
  slug <- introstat_frozen_safe_slug(snapshot$slug, "snapshot slug")
  manifest_path <- introstat_frozen_path(root, snapshot$manifest, file.path("report_ready", slug, "manifest.yaml"))
  object_path <- introstat_frozen_path(root, snapshot$object, file.path("report_ready", slug, "object.rds"))
  snapshot_directory <- dirname(manifest_path)
  manifest_bytes <- introstat_frozen_read_bytes(manifest_path, "frozen manifest")
  object_bytes <- introstat_frozen_read_bytes(object_path, "frozen object")
  actual_manifest_hash <- introstat_frozen_bytes_md5(manifest_bytes, "frozen manifest")
  actual_object_hash <- introstat_frozen_bytes_md5(object_bytes, "frozen object")
  if (!identical(introstat_frozen_md5(snapshot$manifest_hash, "manifest_hash"), actual_manifest_hash)) stop("Frozen manifest hash does not match the prepared plan.", call. = FALSE)
  if (!identical(introstat_frozen_md5(snapshot$object_hash, "object_hash"), actual_object_hash)) stop("Frozen object hash does not match the prepared plan.", call. = FALSE)
  # Parse and deserialize the exact bytes that were hashed.  The compiler
  # receives these preserved values and never reopens the source paths.
  manifest <- introstat_frozen_parse_manifest(manifest_bytes)
  object <- introstat_frozen_deserialize_object(object_bytes)
  fields <- names(manifest) %||% character()
  allowed <- c(introstat_frozen_manifest_required, introstat_frozen_manifest_optional)
  if (!setequal(fields, intersect(fields, allowed)) || anyDuplicated(fields) || any(!fields %in% allowed)) stop("Frozen snapshot manifest has unknown fields.", call. = FALSE)
  if (!all(introstat_frozen_manifest_required %in% fields)) stop("Frozen snapshot manifest is missing required fields.", call. = FALSE)
  if (introstat_frozen_integer(manifest$schema_version, "manifest schema_version") != 1L) stop("Frozen snapshot manifest schema_version must be 1.", call. = FALSE)
  if (!identical(as.character(manifest$status), "report_ready")) stop("Frozen snapshot manifest status must be report_ready.", call. = FALSE)
  if (!identical(introstat_frozen_safe_slug(manifest$slug, "manifest slug"), slug)) stop("Frozen snapshot manifest slug does not match its directory.", call. = FALSE)
  display_id <- introstat_frozen_scalar(manifest$display_id, "manifest display_id")
  title <- introstat_frozen_scalar(manifest$title, "manifest title")
  artifact_type <- introstat_frozen_scalar(manifest$artifact_type, "manifest artifact_type")
  if (!artifact_type %in% c("plot", "table", "summary_table", "regression_table")) stop("Unsupported frozen artifact type: ", artifact_type, call. = FALSE)
  prefix <- switch(artifact_type, plot = "P", table = "T", summary_table = "T", regression_table = "R")
  if (!grepl(paste0("^", prefix, "[1-9][0-9]*$"), display_id)) stop("Frozen display_id does not match artifact_type.", call. = FALSE)
  if (!identical(as.character(manifest$object), "object.rds")) stop("Frozen manifest object must be object.rds.", call. = FALSE)
  snapshot_entries <- list.files(snapshot_directory, all.files = TRUE, no.. = TRUE)
  if (!setequal(snapshot_entries, c("manifest.yaml", "object.rds", "reproduce.R", "files"))) stop("Frozen snapshot directory has unexpected files.", call. = FALSE)
  artifact_paths <- manifest$artifacts
  if (!is.character(artifact_paths) || length(artifact_paths) != 1L) stop("Frozen manifest artifacts must name one preview file.", call. = FALSE)
  if (!grepl("^files/artifact\\.(?:png|html)$", artifact_paths, perl = TRUE)) stop("Frozen manifest artifacts must be files/artifact.png or files/artifact.html.", call. = FALSE)
  expected_artifact <- if (identical(artifact_type, "plot")) "files/artifact.png" else "files/artifact.html"
  if (!identical(artifact_paths, expected_artifact)) stop("Frozen preview file does not match artifact_type.", call. = FALSE)
  for (artifact in artifact_paths) {
    artifact_path <- file.path(snapshot_directory, artifact)
    resolved_artifact <- normalizePath(artifact_path, mustWork = FALSE)
    if (nzchar(Sys.readlink(dirname(artifact_path))) || (file.exists(artifact_path) && nzchar(Sys.readlink(artifact_path)))) stop("Frozen manifest artifact path is not confined.", call. = FALSE)
    if (!startsWith(resolved_artifact, paste0(normalizePath(dirname(manifest_path), mustWork = TRUE), .Platform$file.sep))) stop("Frozen manifest artifact path escapes its snapshot.", call. = FALSE)
    if (!file.exists(artifact_path) || dir.exists(artifact_path)) stop("Frozen manifest preview file is missing.", call. = FALSE)
  }
  preview_path <- file.path(snapshot_directory, artifact_paths[[1]])
  preview_bytes <- introstat_frozen_read_bytes(preview_path, "frozen preview")
  actual_preview_hash <- introstat_frozen_bytes_md5(preview_bytes, "frozen preview")
  preview_entries <- list.files(file.path(snapshot_directory, "files"), all.files = TRUE, no.. = TRUE)
  if (!identical(preview_entries, basename(artifact_paths))) stop("Frozen snapshot preview directory has unexpected files.", call. = FALSE)
  if (!identical(as.character(manifest$reproduction_source), "reproduce.R")) stop("Frozen reproduction_source must be reproduce.R.", call. = FALSE)
  reproduce_path <- file.path(snapshot_directory, "reproduce.R")
  if (!file.exists(reproduce_path) || dir.exists(reproduce_path) || nzchar(Sys.readlink(reproduce_path))) stop("Frozen reproduction script is missing or linked.", call. = FALSE)
  if (!identical(as.character(manifest$source_analysis), paste("analysis", slug, "analysis.R", sep = "/"))) stop("Frozen source_analysis must point to the saved analysis script.", call. = FALSE)
  introstat_frozen_scalar(manifest$report_ready_at, "manifest report_ready_at")
  for (field in c("source_object_hash", "object_hash", "artifact_hash")) introstat_frozen_md5(manifest[[field]], paste0("manifest ", field))
  if (!identical(as.character(manifest$object_hash), actual_object_hash)) stop("Frozen manifest object_hash does not match object.rds.", call. = FALSE)
  if (!identical(as.character(manifest$source_object_hash), actual_object_hash)) stop("Frozen object is not an exact copy of the validated analysis object.", call. = FALSE)
  if (!identical(as.character(manifest$artifact_hash), actual_preview_hash)) stop("Frozen manifest artifact_hash does not match the preview file.", call. = FALSE)
  if (!is.null(manifest$width)) { if (!is.numeric(manifest$width) || length(manifest$width) != 1L || !is.finite(manifest$width) || manifest$width <= 0) stop("Manifest width must be positive.", call. = FALSE) }
  if (!is.null(manifest$height)) { if (!is.numeric(manifest$height) || length(manifest$height) != 1L || !is.finite(manifest$height) || manifest$height <= 0) stop("Manifest height must be positive.", call. = FALSE) }
  if (!is.null(manifest$report_order)) { if (!is.numeric(manifest$report_order) || length(manifest$report_order) != 1L || !is.finite(manifest$report_order) || manifest$report_order <= 0) stop("Manifest report_order must be positive.", call. = FALSE) }
  for (field in c("problem", "question", "section_id")) if (!is.null(manifest[[field]])) introstat_frozen_scalar(manifest[[field]], paste0("manifest ", field))
  if (!is.null(manifest$tags) && (!is.character(manifest$tags) || !length(manifest$tags) || anyNA(manifest$tags) || any(!nzchar(manifest$tags)) || any(manifest$tags != trimws(manifest$tags)))) stop("Manifest tags must be trimmed non-empty strings.", call. = FALSE)
  list(display_id = display_id, slug = slug, manifest = snapshot$manifest, manifest_hash = snapshot$manifest_hash, object = snapshot$object, object_hash = snapshot$object_hash, manifest_data = manifest, object_path = object_path, object_data = object, object_bytes = object_bytes, preview_bytes = preview_bytes, manifest_bytes = manifest_bytes)
}

introstat_prepared_render_token <- function(plan) {
  binding <- list(schema_version = 1L, board_revision = as.integer(plan$board_revision), title = plan$title, subtitle = plan$subtitle, sections = plan$sections, snapshots = plan$snapshots)
  encoded <- jsonlite::toJSON(binding, auto_unbox = TRUE, null = "null", digits = NA, pretty = FALSE)
  staged <- tempfile(".render-token-")
  on.exit(unlink(staged, force = TRUE), add = TRUE)
  writeBin(charToRaw(enc2utf8(encoded)), staged)
  unname(tolower(as.character(tools::md5sum(staged))))
}

introstat_validate_prepared_plan <- function(plan, root, board = NULL) {
  if (!is.list(plan) || !setequal(names(plan) %||% character(), introstat_frozen_plan_fields) || anyDuplicated(names(plan) %||% character())) stop("Prepared plan has invalid top-level fields.", call. = FALSE)
  if (introstat_frozen_integer(plan$schema_version, "schema_version") != 1L) stop("Prepared plan schema_version must be 1.", call. = FALSE)
  plan$board_revision <- introstat_frozen_integer(plan$board_revision, "board_revision")
  plan$title <- introstat_frozen_scalar(plan$title, "title")
  plan$subtitle <- introstat_frozen_scalar(plan$subtitle, "subtitle", allow_null = TRUE, allow_empty = TRUE)
  plan$render_token <- introstat_frozen_md5(plan$render_token, "render_token")
  if (!identical(plan$render_token, introstat_prepared_render_token(plan))) stop("Prepared plan render_token does not match its content.", call. = FALSE)
  sections <- plan$sections %||% list(); snapshots <- plan$snapshots %||% list()
  if (!is.list(sections) || !is.list(snapshots) || !length(sections)) stop("Prepared plan must contain at least one section.", call. = FALSE)
  clean_sections <- lapply(sections, function(section) {
    if (!is.list(section) || !setequal(names(section) %||% character(), introstat_frozen_section_fields) || anyDuplicated(names(section) %||% character())) stop("Prepared section has invalid fields.", call. = FALSE)
    artifact_values <- section$artifacts
    if (is.null(artifact_values)) artifact_values <- character()
    if (is.list(artifact_values) && !length(artifact_values)) artifact_values <- character()
    if (!is.character(artifact_values)) stop("Prepared section artifacts must be a character list.", call. = FALSE)
    introstat_frozen_bool(section$include_if_empty, "include_if_empty")
    list(section_id = introstat_frozen_safe_slug(section$section_id, "section_id"), title = introstat_frozen_scalar(section$title, "section title"), include_if_empty = TRUE, artifacts = unname(artifact_values))
  })
  section_ids <- vapply(clean_sections, `[[`, character(1), "section_id"); section_titles <- vapply(clean_sections, `[[`, character(1), "title")
  if (anyDuplicated(tolower(section_ids)) || anyDuplicated(tolower(section_titles))) stop("Prepared section IDs and titles must be unique.", call. = FALSE)
  if (any(tolower(section_ids) == "unassigned") || any(tolower(section_titles) == "unassigned")) stop("Unassigned is not a report heading.", call. = FALSE)
  if (length(snapshots)) {
    clean_snapshots <- lapply(snapshots, function(snapshot) {
      if (!is.list(snapshot) || !setequal(names(snapshot) %||% character(), introstat_frozen_snapshot_fields) || anyDuplicated(names(snapshot) %||% character())) stop("Prepared snapshot has invalid fields.", call. = FALSE)
      list(display_id = introstat_frozen_scalar(snapshot$display_id, "snapshot display_id"), slug = introstat_frozen_safe_slug(snapshot$slug, "snapshot slug"), manifest = introstat_frozen_scalar(snapshot$manifest, "snapshot manifest"), manifest_hash = introstat_frozen_md5(snapshot$manifest_hash, "manifest_hash"), object = introstat_frozen_scalar(snapshot$object, "snapshot object"), object_hash = introstat_frozen_md5(snapshot$object_hash, "object_hash"))
    })
  } else clean_snapshots <- list()
  snapshot_ids <- vapply(clean_snapshots, `[[`, character(1), "display_id")
  if (anyDuplicated(snapshot_ids)) stop("Prepared snapshot display IDs must be unique.", call. = FALSE)
  all_section_ids <- unlist(lapply(clean_sections, `[[`, "artifacts"), use.names = FALSE)
  if (length(all_section_ids) && (anyNA(all_section_ids) || any(!nzchar(all_section_ids)) || anyDuplicated(all_section_ids))) stop("Prepared section artifact lists must contain unique visible IDs.", call. = FALSE)
  if (!identical(all_section_ids, snapshot_ids)) stop("Prepared section artifacts and snapshots must contain the same visible IDs and order.", call. = FALSE)
  records <- lapply(clean_snapshots, introstat_frozen_manifest_record, root = root)
  if (length(records) && !identical(vapply(records, `[[`, character(1), "display_id"), snapshot_ids)) stop("Prepared snapshot IDs do not match frozen manifests.", call. = FALSE)
  plan$sections <- clean_sections; plan$snapshots <- clean_snapshots
  if (!is.null(board)) introstat_validate_prepared_board(plan, board)
  invisible(list(plan = plan, records = records))
}

introstat_validate_prepared_board <- function(plan, board) {
  if (exists("introstat_board_validate", mode = "function")) introstat_board_validate(board)
  if (!identical(as.integer(board$revision), as.integer(plan$board_revision))) stop("Analysis board revision does not match the prepared plan.", call. = FALSE)
  ordinary <- board$sections[-length(board$sections)]
  unassigned <- board$sections[[length(board$sections)]]
  board_ids <- vapply(board$artifacts, function(x) as.character(x$display_id), character(1))
  selected_for <- lapply(ordinary, function(section) {
    keys <- as.character(unlist(section$artifacts %||% character(), use.names = FALSE)); keys[vapply(keys, function(key) isTRUE(board$artifacts[[key]]$include_in_report) && !isTRUE(board$artifacts[[key]]$archived), logical(1))]
  })
  unassigned_keys <- as.character(unlist(unassigned$artifacts %||% character(), use.names = FALSE)); if (any(vapply(unassigned_keys, function(key) isTRUE(board$artifacts[[key]]$include_in_report) && !isTRUE(board$artifacts[[key]]$archived), logical(1)))) stop("Selected Unassigned artifacts cannot be compiled.", call. = FALSE)
  expected <- ordinary
  if (length(expected) != length(plan$sections)) stop("Prepared sections do not match the current board structure.", call. = FALSE)
  for (i in seq_along(expected)) {
    section <- expected[[i]]; target <- plan$sections[[i]]
    if (!identical(section$id, target$section_id) || !identical(section$title, target$title) || !identical(TRUE, target$include_if_empty)) stop("Prepared section differs from the current board.", call. = FALSE)
    expected_ids <- unname(vapply(selected_for[[which(vapply(ordinary, function(x) identical(x$id, section$id), logical(1)))]], function(key) as.character(board$artifacts[[key]]$display_id), character(1)))
    if (!identical(expected_ids, target$artifacts)) stop("Prepared artifact order differs from the current board.", call. = FALSE)
  }
  invisible(TRUE)
}
