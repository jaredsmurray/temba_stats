# Homework 3 workspace

Keep this folder and its contents together. Follow the course setup instructions
at https://jaredsmurray.github.io/temba_stats/introstatgpt.html and open the
unzipped `TEMBA-2026-homework-03-codex` folder in Codex. Ask:
“Set up this IntroStatGPT workspace and verify that it is ready. Do not begin
an analysis yet.”

Read `ASSIGNMENT.pdf`. Generate the requested tables, plots, and software checks.
For hand calculations, show formulas, substituted values, and units. Write your
own interpretations and recommendation. Problems 2–4 supply their numerical inputs.
For the survey mean check, use the printed sample size, mean, and SD.

Ask for a Word report in assignment order, including headings for parts with no
saved output. Review its outline and approve the build. Add your calculations and
written answers, then export to PDF. You may submit one or more PDFs; label every
part clearly. The assignment is graded credit/no credit.

The course page provides an optional reference chat and report skeleton. All
portfolio calculations use monthly decimal returns. In the hybrid-work study,
use the observed count for each outcome, including blank values when counting
missing outcomes.
