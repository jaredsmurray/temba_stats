# The operations dataset is a synthetic instructional construction.
fulfillment_shifts <- readr::read_csv("data/fulfillment_shifts.csv", show_col_types = FALSE)
fulfillment_shifts$shift_date <- as.Date(fulfillment_shifts$shift_date)
