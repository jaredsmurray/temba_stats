# Homework 2 workspace

Keep this folder and its contents together. Open the ChatGPT desktop app, choose
**File → Open Folder**, and select this `TEMBA-2026-homework-02-codex` folder.
Do not upload or drag the ZIP file into a chat. In the task that opens, ask:
"Set up this IntroStatGPT workspace and verify that it is ready. Do not begin
an analysis yet."

Read ASSIGNMENT.pdf. For each Generate output panel, request the named output, inspect its variables and units, and request any
needed correction. Use the output identifiers to ask for a Word report in
assignment order. Review and approve its outline, then add your numbered answers in Word. Place the three Problem 2 sketches
under parts 1–2 and its two harness tables under parts 3 and 5. Export the completed
report to PDF. You may instead submit multiple PDF files if every answer is clearly
labeled with its problem and part number. Legible scans or photographs of handwritten
pages are acceptable once converted to PDF.

Use the harness to generate outputs. Write interpretations yourself. For hand calculations, show arithmetic and units. Follow Problem 2's instructions about when to use the harness.

The assignment covers Chapters 6--10 and 12--14. No Chapter 11 method is required. The fraud problem uses the printed count table
and Chapter 10 conditional probabilities.

The `fulfillment_shifts` object contains an explicitly synthetic operations
example. Its columns and units are defined in the assignment. Use the file as
supplied and perform the requested comparison; the example is not evidence
about an actual organization.

Problem 3 uses the supplied counts and requires no harness output. Problem 5 supplies its figure and correlation; Output A is the grouped table. Reproducing the figure is optional practice and is not required for submission.
